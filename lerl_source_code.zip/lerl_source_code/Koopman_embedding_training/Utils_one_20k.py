#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import socket

hostname = socket.gethostname()
GPUS = '0'
if 'buduo' in hostname.lower() or 'shaw' in hostname:
    GPUS = '0'
elif 'nudt302' in hostname.lower():
    GPUS = '3'
elif 't640' in hostname.lower():
    GPUS = '2'
import os

os.environ['CUDA_VISIBLE_DEVICES'] = GPUS
print("---------------- GPUS: ", GPUS)
import argparse
import numpy as np
import os
import time
import sys
import torch
from torch import nn
import pytorch_lightning as pl

np.set_printoptions(suppress=True)
code_name = os.path.basename(sys.argv[0])


def loss_weight(a, b, c, steps):
    """
        Calculates the weight coefficients for multi-step prediction loss.

        Args:
            a (float): Scaling factor for the weight calculation.
            b (float): Additional scaling factor.
            c (float): Coefficient for the final weight adjustment.
            steps (int): Number of steps (multi-step loss).

        Returns:
            list: A list of weights for each step.
    """
    reced_w = [(1 + np.tanh(a * w) * b) * c for w in np.arange(steps + 1)]
    return reced_w


def get_softrobot_args(is_debug=False, is_mkdir=True):
    """
    Defines and returns command line arguments for the SoftRobot model.

    Args:
        is_debug (bool): Flag to indicate if the model is in debug mode.
        is_mkdir (bool): Flag to determine if directories should be created.

    Returns:
        argparse.Namespace: Parsed arguments object containing model parameters.
    """
    parser = argparse.ArgumentParser()  # args = parser.parse_args()

    # ------------------------------ environment --------------------
    sys_interval = 50 # The Sampling frequency during controlling
    version = 'soft_robot'
    domain_name = version + '_%d' % sys_interval  # SoftRobot_50
    parser.add_argument('--domain_name', type=str, default=domain_name, help='the name of the system')  # SoftRobot_50
    s_dim, u_dim = 12, 4 # State dimensions and input dimensions
    conca_num = 0
    state_name = ['x', 'y', 'z', 'theta1', 'theta2', 'theta3', 'vx', 'vy', 'vz', 'dtheta1', 'dtheta2', 'dtheta3']
    parser.add_argument('--s_dim', type=int, default=s_dim, help='the dim of the state of the forced dynamics')
    parser.add_argument('--u_dim', type=int, default=u_dim, help='the dim of the action of the forced dynamics')
    parser.add_argument('--state_name', type=list, default=state_name, help='the name of each state')
    action_name = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8']
    parser.add_argument('--action_name', type=list, default=action_name, help='the name of each action')
    # -------------- for data process -------------------------------------------
    parser.add_argument('--conca_num', type=int, default=conca_num,
                        help='concatenate conca_num states to one input') 
    parser.add_argument('--interval', type=int, default=4,
                        help='sample intervals when sampling data from train dataset') 
    parser.add_argument('--train_file_num', type=int, default=561, help='the num of train dataset file')  
    parser.add_argument('--test_file_num', type=int, default=0, help='the num of test dataset file')  
    parser.add_argument('--val_file_num', type=int, default=39, help='the num of val dataset file')  
    ##==========Important setting: the normalization bounds, replace your normalization bounds of your datas==================================
    state_bound = np.array([[-0.00879201412200928,	0.170363464355469,	0.0225633468627930,	-0.738277655808186,	-0.302795423829557,	-1.07303653877796,	-0.298369483947754,	-0.0687980651855469,	-0.234121589660645,	-2.57014003570657,	-0.923538284898784,	-3.65200378836516],
                            [0.124927337646484,	0.237662933349609,	0.141864334106445,	0.995231288845882,	0.279599889946212,	0.761269591026194,	0.334707660675049,	0.103577575683594,	0.263511123657227,	3.19393175849312,	0.960900063114750,	3.14161512401149]])
    parser.add_argument('--state_bound', type=list, default=state_bound, help='the bound of each    states')
    parser.add_argument('--data_len', type=int, default=100, help='param for sampling data from dataset')
    parser.add_argument('--middle_interval', type=int, default=13, help='interval of episodes')

    # ---------------------- construction ------------------------
    # Modes set for debugging
    input_mode = 22
    koopman_mode = 1
    latent_mode = 2
    BMatrix_mode = 1
    parser.add_argument('--input_mode', type=int, default=input_mode,
                        help='the mode decide whether to use image as input')
    lift_dim = 12       # Lifted nums
    # Loss term weights (in equation(5) of the paper):
    koopman_lam = 10  # Weight of linear regression loss
    T_eig_lam = 0.0  # Weight of T regularization loss
    A_eig_lam = 0.003  # Weight of A regularization loss
    recon_lam_C = 1  # Weight of reconstruction loss
    svd_lam = 0.003  # Weight of C regularization loss
    pred_lam_C = 1
    # Number of steps predicted
    num_shifts = 50    # predicted steps p
    num_koopman_shifts = num_shifts
    predicted_step = num_shifts
    parser.add_argument('--latent_mode', type=int, default=latent_mode, help='1:only encoder, 2: resNet style')

    #The layer structure of the koopman embedding network
    if latent_mode == 2:
        encoder_widths = [(conca_num + 1) * s_dim, 64, 128, 64,
                          lift_dim]  # this kind of setting make sure that either latend_mode = 1 or 2, the dimension of lifted state is always as lift_dim + s_dim
    else:
        encoder_widths = [(conca_num + 1) * s_dim, 64, 128, 64, lift_dim + s_dim]  # only encoder case
    eact_type = ['relu', 'relu', 'relu', '']           # Activation functions for encoder
    parser.add_argument('--encoder_widths', default=encoder_widths, help='the fc layers info')
    decoder_widths = [lift_dim + s_dim, 128, 64, 64, s_dim]
    dact_type = ['relu', 'relu', 'relu', '']           # Activation functions for decoder
    parser.add_argument('--decoder_widths', type=list, default=decoder_widths,
                        help='the construction of the auto-encoder')
    is_last_bias = False if len(decoder_widths) == 2 else True
    parser.add_argument('--is_last_bias', type=bool, default=is_last_bias, help='decoder is_last bias')  # Bias addition argument for the last layer
    parser.add_argument('--lift_dim', type=int, default=lift_dim, help='the lifted dim')
    parser.add_argument('--scale', type=float, default=0.1, help='scale for initializing weights')# Weight initialization scale argument
    if (not len(eact_type) == len(encoder_widths) - 1) or (not len(dact_type) == len(decoder_widths) - 1):
        raise Exception('the length of eact_type or dact_type is wrong')
    parser.add_argument('--eact_type', type=list, default=eact_type, help='the type of activation') # Encoder activation functions argument
    parser.add_argument('--dact_type', type=list, default=dact_type, help='the type of activation') # Decoder activation functions argument

    # ------------------------ loss function ------------
    #Define the important hyperparameters for the loss function
    is_predict = False  #  True : Testing  #False: Training
    parser.add_argument('--is_predict', type=bool, default=is_predict, help='the flag of running model')
    parser.add_argument('--num_shifts', type=int, default=num_shifts,
                        help='the steps for calculating the predicted loss')
    parser.add_argument('--num_koopman_shifts', type=int, default=num_koopman_shifts,
                        help='the steps for koopman operator')
    # ===========The weight of the loss is calculated for each state, which is set according to the training situation============
    state_weight = np.ones([1, s_dim]) * 1
    parser.add_argument('--state_weight', type=list, default=state_weight,
                        help='the weight of each state to calculate reconstruction loss and multi-steps prediction loss')
    c_linear = [1, 1, 1]
    reced_linear = loss_weight(c_linear[0], c_linear[1], c_linear[2], num_shifts)
    parser.add_argument('--c_linear', type=float, default=c_linear, help='weight for multi-step prediction loss')
    parser.add_argument('--reced_linear', type=float, default=reced_linear,
                        help='coefficients of loss weight for multi-step loss')
    parser.add_argument('--predicted_step', type=int, default=predicted_step, help='the num of the predicted step')
    parser.add_argument('--koopman_lam', type=float, default=koopman_lam,
                        help='the coefficient of koopman linear loss')  # important hyperparameter for the linear regression loss
    parser.add_argument('--T_eig_lam', type=float, default=T_eig_lam,
                        help='weight of eigenvalues of T matrix')  # important hyperparameter for the T regularization loss
    parser.add_argument('--A_eig_lam', type=float, default=A_eig_lam,
                        help='weight of eigenvalues of A matrix')  # important hyperparameter for the A regularization loss
    parser.add_argument('--svd_lam', type=float, default=svd_lam,
                        help='weight of singular value of controllability matrix')  # important hyperparameter for the C regularization loss
    parser.add_argument('--opt_alg', type=str, default='adam', help='optimizer')
    parser.add_argument('--batch_size', type=int, default=4096, help='the size of each batch')  # 2048
    parser.add_argument('--learning_rate', type=float, default=0.0003, help='learning rate')
    parser.add_argument('--dropout_rate', type=float, default=1., help='keep prob')
    parser.add_argument('--recon_lam_C', type=float, default=recon_lam_C,
                        help='the coefficient of reconstruction loss')  # important hyperparameter for the reconstruction loss
    parser.add_argument('--pred_lam_C', type=float, default=pred_lam_C,
                        help='weight of multi-step reconstruction')  # important hyperparameter for prediction loss
    # ==============Following codes =====================
    parser.add_argument('--koopman_mode', type=int, default=koopman_mode,
                        help="1: time-invariant-eigenvalues, 2: transition matrix, "
                             "3: time-variant-eigenvalues(each complex conjugate pair has a NN), "
                             "4: time-variant-eigenvalues based on whole NN, ")
    parser.add_argument('--num_real', type=int, default=int(np.mod(lift_dim + s_dim, 2)),
                        help='num of real eigenvalues')
    parser.add_argument('--num_complex_pair', type=int, default=int((lift_dim + s_dim) / 2),
                        help='num of complex conjugate pairs')

    parser.add_argument('--BMatrix_mode', type=int, default=BMatrix_mode,
                        help='The way to construct the input matrix:'
                             '1: LTI dynamics with a constant B;'
                             '2: Bilinear dynamics with u_dim constant B(space_dim, u_dim x space_dim);')
    parser.add_argument('--code_name', type=str, default=code_name, help='the file name of the main .py')

    #################################### -------------- path ---------------------###########################################
    """
        This part is important, you can replace the paths according to your file environment.
    """
    cur_path = os.path.split(os.getcwd())[0]
    base_path = cur_path
    date = time.strftime("%Y_%m_%d_%H_%M", time.localtime())
    debug_str = "_Debug" if is_debug else ""
    path = base_path +'/' + os.path.split(os.getcwd())[1]+'\SoftRobot_' + str(date) + debug_str #The path where the trainned models are stored.
    # # Home/leac/SoftRobot/SoftRobot/1_model_50/SoftRobot_2023_9_20_9_33
    parser.add_argument('--path', type=str, default=path)
    if (not os.path.exists(path)) and (not is_predict) and not is_debug:
        os.makedirs(path)
    parser.add_argument('--log_dir', type=str, default=os.path.join(path, 'logdir'), help='for saving tensorboard log')
    parser.add_argument('--image_path', type=str, default=path + '/logdir/train/%s_%d_psteps_%d_gstep.png',
                        help='the path for saving the predicted picture result')
    data_path = base_path + '/' + os.path.split(os.getcwd())[1]+'\data_dyn/'  #The path where datas are stored,
    parser.add_argument('--train_data_path', type=str,
                        default=data_path + 'soft_robot' + '_%d.mat', help='the path of the training data')
    parser.add_argument('--test_data_path', type=str,
                        default=data_path + 'soft_robot' + '_test_%d.mat', help='the path of testing data')
    parser.add_argument('--val_data_path', type=str, default=data_path + 'soft_robot' + '_test_%d.mat',
                        help=' use test data for validation')
    parser.add_argument('--host_device', type=str, default=hostname + ":%s" % GPUS, help='host and gpu')

    if is_predict:  # if true, then conduct testing, then load the trained model for testing.
        restore_model_path = base_path + '%d_model_%d/' % (
            koopman_mode, sys_interval) + 'SoftRobot_2024_07_12_13_06/logdir/epoch=1619-train_loss=0.44099.ckpt' #Replace the path using your trained model, then you can test the model
        model_path = path
    else:
        restore_model_path = base_path + '%d_model_%d/' % (
            koopman_mode, sys_interval) + 'SoftRobot_2024_07_12_08_40/logdir/last.ckpt'
        model_path = path

        print(
            'If you want to use the previously trained modle as training starting, please change the restore_model_path')

    args_file_path = model_path + '/args.pkl' 
    test_image_path = model_path + '/logdir/test/'
    matlab_file_path = model_path + '/params_for_matlab.mat'
    if not os.path.exists(test_image_path) and is_mkdir:
        os.makedirs(test_image_path)
    parser.add_argument('--restore_model_path', type=str, default=restore_model_path, help='the path of trained model')
    parser.add_argument('--args_file_path', type=str, default=args_file_path, help='save dict args for restore')
    parser.add_argument('--matlab_file_path', type=str, default=matlab_file_path, help='for matlab prediction')
    parser.add_argument('--test_image_path', type=str, default=test_image_path + str(date) + '_bIdx_%d_%d.png',
                        help='the path for saving the testing images')
    args = parser.parse_args()
    return args

# Initialize Policy weights
def weights_init_(m):
    """
        Initializes the weights of a neural network layer.

        Args:
            m (nn.Module): The module (layer) to initialize.
    """
    if isinstance(m,
                  nn.Linear):  # if the module m is an instance of nn.Linear, the weight and bias of this module are initialized.
        # torch.nn.init.xavier_uniform_(m.weight, gain=1)
        torch.nn.init.normal_(m.weight, 0., 0.1)  # a mean of 0 and a standard deviation of 0.1
        if m.bias is True:
            torch.nn.init.constant_(m.bias, 0)

class MLP(pl.LightningModule):
    """
        Multi-layer perceptron (MLP) class for building a fully connected neural network.
    """
    def __init__(self, widths, act_type, is_variational=False,
                 is_last_bias=True):  # we use a variational NN that includes elements for modeling uncertainity.
        """
        :param widths:
        :param act_type:
        :param is_variational:
        :param is_last_bias:  bias for last layer or not
        """
        super(MLP, self).__init__()
        self.is_variational = is_variational
        if self.is_variational:
            # mean and std
            widths[-1] = widths[
                             -1] * 2  # the last layer's width is doubled, typically to accommodate both mean and standard deviation values.
        self.act_type = act_type
        self.widths = widths
        fc_layers = []  # a list containing the layers that we want to stack in the NN.
        # Iterate over layers and create the corresponding layer with activation functions
        for i in np.arange(len(self.widths) - 1):
            is_bias = True if i < len(self.widths) - 2 else is_last_bias
            # Create a linear layer with optional bias
            linear_layer = nn.Linear(self.widths[i], self.widths[i + 1], bias=is_bias)
            linear_layer.weight.requires_grad = True  # Set requires_grad to False for weight no updata
            linear_layer.bias.requires_grad = True  # Set requires_grad to False for bias no updata
            # fc_layers.append(linear_layer)
            fc_layers.append(nn.utils.spectral_norm(linear_layer))

            act_op = activation(self.act_type[i])# Get activation function
            if act_op is not None:
                fc_layers.append(act_op)
        self.fc_net = nn.Sequential(*fc_layers)  # creating a fully connected NN; * unpack the element of fc_layer
        self.apply(weights_init_) # Initialize weights

    def reparameterize(self, mu, std):
        """
        Reparameterization trick for variational layers.

        Args:
            mu (tensor): The mean values.
            std (tensor): The standard deviation values.

        Returns:
            tensor: The reparameterized tensor.
        """
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x, use_repa=False):
        x = self.fc_net(x)
        if self.is_variational:
            x, log_std = torch.chunk(x, 2,
                                     dim=-1)  # split a tensor x into two equal parts along a specified dimension (dim=-1).
            std = torch.minimum(log_std.exp(), torch.ones_like(log_std) * 10)
            if use_repa:
                x = self.reparameterize(x, std)
        return x


class KoopmanNet(pl.LightningModule):
    """
        Koopman operator network for learning dynamic systems (Construction of matrix A,B,T).
    """

    def __init__(self, input_mode, lift_dim, u_dim, s_dim=None, koopman_mode=1, num_real=0, num_complex_pair=0,
                 args=None):
        super(KoopmanNet, self).__init__()
        if input_mode > 20 and s_dim is None:
            raise Exception("When the input is not images, the s_dim (dim of the state) should be given !!!")
        self.s_dim = s_dim                     # state dimension
        self.input_mode = input_mode
        self.koopman_mode = koopman_mode       # state dimension
        self.lift_dim = lift_dim               # lifted dimension
        self.u_dim = u_dim                     # control input dimension
        self.num_real = num_real               # the number of real eigenvalues of controllability matrix C
        self.num_complex_pair = num_complex_pair       # state dimension
        if input_mode < 20:
            self.space_dim = self.lift_dim
        else:
            self.space_dim = self.lift_dim + self.s_dim
        # learn time-invariant-eigenvalues, it just has self.space_dim  eigenvalues:
        if koopman_mode == 1:
            init_A = torch.squeeze(torch.normal(0., 0.01, size=(1, self.space_dim)))
            self.A = nn.Parameter(init_A,
                                  requires_grad=True)  # initialize the weight matrix self.A as a trainable parameter
        elif koopman_mode == 2:
            w = torch.Tensor(self.space_dim, self.space_dim)
            w = torch.nn.init.normal_(w, 0, 0.01)
            self.A = nn.Parameter(w, requires_grad=True)
        # matrix B
        if np.mod(self.input_mode, 2) == 0 or u_dim is not None:
            wb = torch.Tensor(u_dim, self.space_dim)
            wb = torch.nn.init.normal_(wb, 0, 0.1)
            self.B = nn.Parameter(wb, requires_grad=True)
        # matrix T
        self.T = torch.diag(torch.ones(s_dim))


    def form_A_from_eigenvalues(self):
        """
            Form matrix A using parameterized eigenvalues.

            return: Block diagonal matrix A_temp
        """
        assert self.space_dim == self.num_real + 2 * self.num_complex_pair, "the sum of all eigenvalues must equal the space_dim"
        idx = 0
        temp_A = torch.zeros([self.space_dim, self.space_dim])
        for i in range(self.num_complex_pair):
            idx = 2 * i
            temp_A[idx:idx + 2, idx:idx + 2] = form_complex_conjugate_block(self.A[idx],
                                                                            self.A[idx + 1])  # temp_A[0:2, 0:2]
        for i in range(self.num_real):
            idx = 2 * self.num_complex_pair + i
            temp_A[idx, idx] = self.A[idx]
        return temp_A.to(self.device)  # move the tensor temp_A to a specific device,

    def forward(self, phi: torch.Tensor, u=None, is_restruct_A=False):
        """
                    Calculate the predicted state (See equation (1) in the paper).
                    s+ = As + Bu

                    return: The next lifted state s+
        """
        batch_size = list(phi.size())[0]
        if self.koopman_mode == 1:
            phi = torch.matmul(phi, self.form_A_from_eigenvalues())
        elif self.koopman_mode == 2:
            phi = torch.mm(phi, self.A)
        if np.mod(self.input_mode, 2) == 0 or u is not None:
            Bu = torch.mm(u, self.B)
            phi = phi + Bu           # Equation s+ = As + Bu
        return phi


def form_complex_conjugate_block(real, imaginary):
    """
    structure the block for system: x(k+1) = Ax(k)
    :param real:
    :param imaginary:
    :return:
    """
    if real.size() == torch.Size([]):  # for time-invariant cases
        block = torch.zeros([2, 2])
        block[0, 0] = real
        block[0, 1] = imaginary
        block[1, 0] = -imaginary
        block[1, 1] = real
    elif list(real.size())[0] >= 1:  # for time-variant situations
        batch_size = list(real.size())[0]
        block = torch.zeros([batch_size, 2, 2])
        # print(block[:, 0, 0].size())
        block[:, 0, 0] = real
        block[:, 0, 1] = imaginary
        block[:, 1, 0] = -imaginary
        block[:, 1, 1] = real
    return block


def activation(act=''):
    if act.lower() == 'sigmoid':
        return nn.Sigmoid()
    elif act.lower() == 'relu':
        return nn.ReLU()
    elif act.lower() == 'elu':
        return nn.ELU()
    elif act.lower() == 'tanh':
        return nn.Tanh()
    elif act.lower() == 'lrelu' or act.lower() == 'leaky_relu':
        return nn.LeakyReLU()
    elif act.lower() == 'sin':
        return Sin()
    elif act.lower() == 'cos':
        return Cos()
    elif act.lower() == 'softmax':
        return nn.Softmax()
    elif act == '' or act == 'None' or act is None:
        return None


class Sin(nn.Module):
    """
    Customize sin activation
    """

    def forward(self, input):
        return torch.sin(input)


class Cos(nn.Module):
    """
    Customize cos activation
    """

    def forward(self, input):
        return torch.cos(input)
