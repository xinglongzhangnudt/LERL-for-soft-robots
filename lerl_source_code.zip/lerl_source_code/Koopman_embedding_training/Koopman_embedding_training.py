#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import Utils_one_20k as config
import socket
import os
import CommonUtils 
from Utils_one_20k import MLP, KoopmanNet
import VisualizeUtils
import pytorch_lightning as pl
import torch
import copy
import numpy as np
from torch import optim
import torch.nn.functional as F
import time
from DataModule import SoftRobotDataModule
from pytorch_lightning.callbacks import ModelCheckpoint
from pytorch_lightning.callbacks import LearningRateMonitor
from pytorch_lightning.loggers import TensorBoardLogger


class DeepEDMD(pl.LightningModule):
    """
        Deep learning model for training and evaluating Koopman operator-based models.
    """
    def __init__(self, args, save_params=False): # Hyperparameter initialization
        super().__init__()
        self.hparams.update(args) 
        self.domain_name = args['domain_name']
        self.s_dim, self.u_dim, self.lift_dim = args['s_dim'], args['u_dim'], args['lift_dim']
        self.save_now = False
        self.args = args
        self.state_name, self.action_name = args['state_name'], args['action_name']
        self.is_predict = args['is_predict']
        self.state_bound = np.array(args['state_bound'])[:, np.newaxis]
        self.conca, self.interval = args['conca_num'], args['interval']
        self.predicted_step = args['predicted_step']
        self.num_shifts = args['num_shifts']
        self.koopman_lam = args['koopman_lam']
        self.T_eig_lam = args['T_eig_lam']
        self.A_eig_lam = args['A_eig_lam']
        self.svd_lam = args['svd_lam']
        self.recon_lam_C = args['recon_lam_C']
        self.pred_lam_C= args['pred_lam_C']
        self.input_mode = self.hparams['input_mode']
        self.koopman_mode = self.hparams['koopman_mode']
        self.latent_mode = CommonUtils.getValueIfExistElseDefault(args, 'latent_mode', 2)
        self.num_real = self.hparams['num_real']
        self.num_complex_pair = self.hparams['num_complex_pair']
        self.batch_size = self.hparams['batch_size']
        self.lr = self.hparams['learning_rate']
        self.encoder_widths, self.decoder_widths = self.hparams['encoder_widths'], self.hparams['decoder_widths']
        self.eact_type, self.dact_type = self.hparams['eact_type'], self.hparams['dact_type']
        self.is_last_bias = CommonUtils.getValueIfExistElseDefault(args, 'is_last_bias', True)
        # --------------------- auxiliary flags ---------------------------
        self.print_log = True
        self.start = time.time()
        self.val_count = 0
        self.best_val_error = 10000.
        self.train_count = 0
        self.best_train_error = 10000.
        self.epochs = 500
        # --------------------- establish network -------------------------------
        self.encoder_net = MLP(self.encoder_widths, self.eact_type) # encodere NN
        self.decoder_net = MLP(self.decoder_widths, self.dact_type, is_last_bias=self.is_last_bias) # decoder NN 
        self.koopman_net = KoopmanNet(self.input_mode, self.lift_dim, self.u_dim, self.s_dim, koopman_mode=self.koopman_mode,
                                      num_real=self.num_real, num_complex_pair=self.num_complex_pair, args=args)  # Koopman NN for A and B
        # print('self.u_dim',self.u_dim)
        self.latent_dim = self.lift_dim + self.s_dim
        if save_params:
            CommonUtils.save_args_as_json(args, self.hparams['args_file_path'])
            #CommonUtils.save_args_as_pkl(args, self.hparams['args_file_path'])

        self.is_init = False

    def configure_optimizers(self):
        """
                Configures the optimizer for training the neural networks. Supports both Adam and SGD optimizers.

                Returns:
                    dict: A dictionary containing the optimizer for the model's parameters.
        """
        weight_decay = 1e-6 
        if self.hparams['opt_alg'] == 'adam':
            self.optimizer = optim.Adam([{'params': self.encoder_net.parameters()},
                                          {'params': self.decoder_net.parameters()},
                                         {'params': self.koopman_net.parameters()}],
                                           lr=self.lr,
                                           weight_decay=weight_decay)
            
        elif self.hparams['opt_alg'].lower() == 'sgd':
            self.optimizer = optim.SGD([{'params': self.encoder_net.parameters()},
                                         {'params': self.decoder_net.parameters()},
                                        {'params': self.koopman_net.parameters(), 
                                         'lr': self.lr / 2}], 
                                         lr=self.lr,
                                       weight_decay=weight_decay)
        return {'optimizer': self.optimizer}

    def on_train_epoch_start(self) -> None:
        """
                Called at the start of each training epoch. Logs the beginning of training.
        """
        if self.print_log:
            print("===============training starts =====================")
            self.print_log = False

    def training_step(self, batch, batch_idx):
        """
                Performs one step of training, calculates the loss, and logs various loss components.

                Args:
                    batch (tensor): The batch of data to process.
                    batch_idx (int): The index of the current batch.

                Returns:
                    tensor: The total loss for the training step.
        """
        # print("===============training runs =====================")
        state_tensor, u_tensor = batch
        tensorboard = self.logger.experiment
        loss, linear_loss, T_eig_loss,A_eig_loss,recon_loss_C,pred_loss_C,svd_loss= self.define_loss(state_tensor, u_tensor, stage='train') # loss for the construction of the cost function
        self.log('train_loss', loss, prog_bar=False, logger=True)
        self.log('train/loss', loss, prog_bar=True, logger=True)
        self.log('train/linear_loss', linear_loss, prog_bar=True, logger=True)
        self.log('train/A_eig_loss', A_eig_loss, prog_bar=True, logger=True)
        self.log('train/T_eig_loss', T_eig_loss, prog_bar=True, logger=True)
        self.log('train/recon_loss_C', recon_loss_C, prog_bar=True, logger=True)
        self.log('train/pred_loss_C', pred_loss_C, prog_bar=True, logger=True)
        self.log('train/svd_loss_', svd_loss, prog_bar=True, logger=True)

        if loss < self.best_train_error:
            self.best_train_error = loss
            self.train_count = 0
        else:
            self.train_count += 1 
        self.log('train/bad_count', self.train_count, prog_bar=True, logger=True)
        if np.mod(self.global_step, 400) == 0 and self.global_step > 1:
            self.save_AB_to_file() # save  A and B every 400 steps
        del state_tensor, u_tensor 
        torch.cuda.empty_cache()
        return loss
    
    def validation_step(self, batch, batch_idx):
        """
                Executes one step of validation, calculating and logging loss metrics.

                Args:
                    batch (tensor): The batch of data to process.
                    batch_idx (int): The index of the current batch.
        """
        print("===============validation runs =====================")
        state_tensor, u_tensor = batch
        loss, linear_loss, T_eig_loss,A_eig_loss,recon_loss_C,pred_loss_C,svd_loss= self.define_loss(state_tensor, u_tensor, stage='val', batch_idx=batch_idx)
        self.log('val/loss', loss, prog_bar=True, logger=True)
        self.log('val/linear_loss', linear_loss, prog_bar=True, logger=True)
        self.log('val/A_eig_loss', A_eig_loss, logger=True)
        self.log('val/svd_loss', svd_loss, logger=True)
        self.log('val/T_eig_loss ', T_eig_loss , logger=True)
        self.log('val/recon_loss_C', recon_loss_C, prog_bar=True, logger=True)
        self.log('val/pred_loss_C', pred_loss_C, prog_bar=True, logger=True)        
        if loss < self.best_val_error:
            self.best_val_error = loss
            self.val_count = 0
        else:
            self.val_count += 1 # if the error does not continuous to decrease, 
        self.log('val/bad_count', self.val_count, prog_bar=True, logger=True)
        del state_tensor, u_tensor
        torch.cuda.empty_cache()

    def on_validation_epoch_end(self) -> None:
        """
                Called at the end of the validation epoch. Logs validation progress and results.
        """
        print("===============validation ends =====================")
        self.print_log = True

    def on_test_start(self) -> None:
        """
                Initializes testing, saving necessary parameters for later analysis and clearing previous results.
        """
        self.save_parameters_for_matlab()
        self.save_logger_scalers()
        self.test_error = []
        self.rmse_list = []
        self.mse_list = []
        self.is_init = True
        if self.print_log:
            print("===============testing starts =====================")
            self.print_log = False

    def test_step(self, batch, batch_idx):
        """
                Performs one step of testing, calculating and logging errors, such as RMSE and MSE.

                Args:
                    batch (tensor): The batch of data to process.
                    batch_idx (int): The index of the current batch.
        """
        # print("===============testing runs =====================")
        tensorboard = self.logger.experiment
        state_tensor, u_tensor = batch

        if not self.is_init:
            self.on_test_start()
        loss, linear_loss,recon_loss_C,pred_loss_C,svd_loss= self.define_loss(state_tensor, u_tensor, stage='test',batch_idx=batch_idx)
        self.test_error.append(np.array([self.to_numpy(loss), self.to_numpy(linear_loss),self.to_numpy(recon_loss_C),self.to_numpy(pred_loss_C),self.to_numpy(svd_loss)]))
    
    def on_test_end(self) -> None:
        """
                Called at the end of testing. Saves results and visualizes errors, such as RMSE, and saves Koopman operator matrices to files.
        """
        print("===============testing ends =====================")
        self.test_error = CommonUtils.list2array(self.test_error, -1, add_dim=True)
        error_dict = dict()
        error_dict['test_error'] = self.test_error
        error_dict['max_error'] = np.max(self.test_error, 1)
        error_dict['mean_error'] = np.mean(self.test_error, 1)
        save_path = self.hparams['restore_model_path']
        base_path = CommonUtils.get_upLevel_dir(save_path)
        latent_error_path = os.path.join(base_path, "latent_error.png")
        VisualizeUtils.draw_latent_error(None, [error_dict['mean_latent_error'], error_dict['max_latent_error']],
                                        label=["mean_err", "max_err"], is_save=True, save_dir=latent_error_path, figsize=(10, 10))
        if self.koopman_mode == 1:
            A = self.koopman_net.form_A_from_eigenvalues().cpu().data.numpy()
        else:
            A = self.koopman_net.A.cpu().data.numpy()
        B = self.koopman_net.B.cpu().data.numpy() 
        T = self.koopman_net.T.cpu().data.numpy() 
        error_dict['A'] = A
        error_dict['B'] = B
        error_dict['T'] = T
        save_path = os.path.join(base_path, 'test_error.mat')
        CommonUtils.save_dict_as_txt(error_dict, save_path.replace('.mat', '.txt'))
        CommonUtils.save_dict_as_mat(error_dict, save_path)
        # -------- MSE AND RMSE
        self.RMSE_result = CommonUtils.list2array(self.rmse_list, dim=0, add_dim=True)
        self.MSE_result = CommonUtils.list2array(self.mse_list, dim=0, add_dim=True)
        error_dict = dict()
        error_dict['RMSE'] = np.mean(self.RMSE_result, axis=0)
        error_dict['MSE'] = np.mean(self.MSE_result, axis=0)
        CommonUtils.save_dict_as_mat(error_dict, os.path.join(base_path, "kmode_%d_rmse.mat" % self.koopman_mode))
        CommonUtils.save_dict_as_txt(error_dict, os.path.join(base_path, "kmode_%d_rmse.txt" % self.koopman_mode))

    def define_loss(self, state_tensor, u_tensor, stage='train', batch_idx=None):
        """
        Defines the loss function used during training, validation, and testing,
        including five loss terms as described in the paper (equation (5)):
        L = α1 * Le + α2 * Lr + α3 * LT + α4 * LA + α5 * LC

        Args:
            state_tensor (tensor): The batch of state data.
            u_tensor (tensor): The batch of input control data.
            stage (str): The current stage (train, val, or test).
            batch_idx (int): The batch index (used for visualizing).

        Returns:
            tuple: A tuple of loss terms for various components .
        """
        multi_steps = state_tensor.shape[1] - 1
        batch_size = state_tensor.shape[0]
        # Initialize loss terms
        linear_loss = 0.
        A_eig_loss = 0.
        svd_loss = 0.
        T_eig_loss = 0.
        recon_loss_C = 0.
        pred_loss_C = 0.
        # ---------------------- regression loss,reconstruction loss CONTROLLABILITY CONSTRAINT-------------------------------
        # Initialize arrays for storing predicted values and true values
        koopman_x = np.zeros([batch_size, multi_steps + 1, self.s_dim]) # Predicted Koopman states
        temp_koopman_s = np.zeros([batch_size, multi_steps + 1, self.s_dim]) # Temporary storage for Koopman states
        true_latent_s = np.zeros([batch_size, multi_steps - 1, self.latent_dim]) # True latent states for comparison
        pred_latent_s = np.zeros([batch_size, multi_steps - 1, self.latent_dim]) # Predicted latent states for comparison

        # State weight from hyperparameters (for weighted loss calculation)
        state_weight = self.hparams['state_weight']

        # Coefficients for the linear and reconstruction loss (used in multi-step predictions)
        c_linear = self.args ['reced_linear']
        c_recon = self.args ['reced_linear']

        # If in prediction mode (testing), use a uniform weight for all steps
        if self.is_predict: # when testing run this code, the trainint procss skip this part.
            c_linear = [1 for i in range(multi_steps + 1)] 
            c_recon = [1 for i in range(multi_steps + 1)]

        # Loop through each prediction step (for each step in the future)
        for i in range(multi_steps):
            # Get the current state and next state for prediction
            x = self.to_device(state_tensor[:, i, :]) # Current state
            x_ = self.to_device(state_tensor[:, i + 1, :])  # Next state (future step)
            u = self.to_device(u_tensor[:, i, :]) # Control input for the current step
            T =  self.to_device(self.koopman_net.T )# Matrix T for transformation
            latent_s = self.encoder_net(torch.mm(x,T))
            if self.latent_mode == 2: 
                T =  self.to_device(self.koopman_net.T )
                latent_s = torch.cat([torch.mm(x[:, -self.s_dim:],T), latent_s], dim=1)

            # =================Calculate the regularization loss (equation (s1) in the supplementary section 1, Le = (1 / p) * Σ (from i=1 to p) || s(k+i) - ŝ(k+i) ||^2)=====================
            if i > 0:
                if self.latent_mode == 2 and not (state_weight == np.ones([1, self.s_dim])).all(): # if state_weight is not equal to an array of ones
                    if (state_weight == np.ones([1, self.s_dim]) * state_weight[0, 0]).all():
                        linear_loss += c_linear[i] * F.mse_loss(latent_s[:, :self.s_dim], koopman_s[:, :self.s_dim]) * state_weight[0, 0]
                    else:
                        for k in np.arange(self.s_dim):
                            linear_loss += c_linear[i] * F.mse_loss(latent_s[:, k], koopman_s[:, k]) * state_weight[0, k]
                    linear_loss += c_linear[i] * F.mse_loss(latent_s[:, self.s_dim:], koopman_s[:, self.s_dim:])
                else:
                    linear_loss += F.mse_loss(latent_s, koopman_s)
                true_latent_s[:, i - 1, :] = self.to_numpy(latent_s)
                pred_latent_s[:, i - 1, :] = self.to_numpy(koopman_s)
            else: # for i = 0
                koopman_s = latent_s # torch.Size([2048, 24])
                temp_koopman_s[:, i, :] = koopman_s[:,  0*self.s_dim: self.s_dim].data.cpu().numpy()  # the x value extracted from the latent_s
            T =  self.to_device(self.koopman_net.T )
            TT=T.T

            #=================== Calculate the reconstruction loss (equation (s2) in the supplementary section 1, Lr = (1 / p) * Σ (from i=1 to p) || x(k+i) - x̂(k+i) ||^2)=====================
            C = torch.hstack((TT.inverse(),self.to_device(torch.zeros(self.s_dim,self.lift_dim))))
            recon_x_C =torch.mm(C,torch.transpose(latent_s,0,1))
            recon_x_C = torch.transpose(recon_x_C,0,1)
            #if i == 0:
            recon_loss_C += F.mse_loss(x[:, -self.s_dim:], recon_x_C)
            if i == 0:
                koopman_x[:, i, :] = recon_x_C.data.cpu().numpy()
            koopman_recon_x_C = torch.mm(C,torch.transpose(koopman_s,0,1))
            koopman_recon_x_C = torch.transpose(koopman_recon_x_C,0,1)
            pred_loss_C += c_recon[i] * F.mse_loss(x[:, -self.s_dim:], koopman_recon_x_C)
            is_restruct_A = True if i == 0 else False
            koopman_s = self.koopman_net(koopman_s, u, is_restruct_A=is_restruct_A)
            temp_koopman_s[:, i, :] = koopman_s[:,0 * self.s_dim: self.s_dim].data.cpu().numpy()  #  the x value extracted from the latent_s
            koopman_x[:, i + 1, :] = koopman_recon_x_C.data.cpu().numpy()

        if stage == "test":
            self.calc_RMSE(copy.copy(state_tensor), copy.copy(koopman_x))

        # ====================Code fowlling is for validation and chart drawing which is not important============================================
        # is_draw_path = True if self.pos_mode == 1 and "cartpole" not in self.domain_name.lower() else False # original
        is_draw_path = True
        # Code for chart validation
        if (stage == 'train' and np.mod(self.global_step, 200) == 0) or stage == 'val':
            vis_num = np.random.randint(0, batch_size, 1)   # a random integer within the range [0, batch_size)
            save_dir = self.hparams['image_path'] % (stage, multi_steps, self.global_step)
            prefix, suffix = os.path.split(save_dir)
            if stage == 'val':
                prefix = prefix.replace('train', 'val')
            if not os.path.exists(prefix):
                os.makedirs(prefix)
            true_state = self.anti_normalization(self.to_numpy(state_tensor[vis_num, :, -self.s_dim:]))
            if self.latent_mode == 1:
                save_dir = os.path.join(prefix, os.path.splitext(suffix)[0] + 'AE' + os.path.splitext(suffix)[-1])
                AE = self.anti_normalization(koopman_x[vis_num, :, :])
                VisualizeUtils.plot_multi_X_and_Y(self.args, true_state, [AE], self.to_numpy(u_tensor[vis_num, :, :]),
                                                  self.state_name, self.action_name, title=self.domain_name, label=["AE"],
                                                  is_save=True, save_dir=save_dir.replace(".png", "_visnum_%d.png" % vis_num),
                                                  draw_path=is_draw_path)
            elif self.latent_mode == 2: # this case for this project
                save_dir = os.path.join(prefix, os.path.splitext(suffix)[0] + 'Direct' + os.path.splitext(suffix)[-1])
                AE = self.anti_normalization(koopman_x[vis_num, :, :]) # the x value after the decoder
                Direct = self.anti_normalization(temp_koopman_s[vis_num, :, :]) # the x value extracted from koopman_s
                VisualizeUtils.plot_multi_X_and_Y(args, true_state, [AE, Direct], self.to_numpy(u_tensor[vis_num, :, :]),
                                                  self.state_name, self.action_name, title=self.domain_name, label=["AE", "Direct"],
                                                  is_save=True, save_dir=save_dir.replace(".png", "_visnum_%d.png" % vis_num),
                                                  draw_path=is_draw_path)
            VisualizeUtils.draw_latent_error(true_latent_s[vis_num],
                                             [pred_latent_s[vis_num, :, :], 
                                              np.zeros_like(true_latent_s[vis_num, :, :]),
                                              -pred_latent_s[vis_num, :, :] + true_latent_s[vis_num, :, :]],
                                             ['error', 'true', 'pred'], 
                                             is_save=True,
                                             save_dir=save_dir.replace(".png", "_latent_visnum_%d.png" % vis_num), figsize=(10, 10))
        elif stage == 'test':
            base_path = self.hparams['test_image_path']
            img_nums = np.arange(5)
            for vis_num in img_nums:
                save_dir = base_path % (batch_idx, vis_num)
                true_state = self.anti_normalization(self.to_numpy(state_tensor[vis_num, :, -self.s_dim:]))
                if self.latent_mode == 1:
                    AE = self.anti_normalization(koopman_x[vis_num, :, :])
                    VisualizeUtils.plot_multi_X_and_Y(self.args, true_state, [AE], self.to_numpy(u_tensor[vis_num, :, :]),
                                                      self.state_name, self.action_name, title=self.domain_name, label=["AE"],
                                                      is_save=True, save_dir=save_dir, draw_path=True)
                elif self.latent_mode == 2:
                    save_dir = base_path % (batch_idx, vis_num)
                    AE = self.anti_normalization(koopman_x[vis_num, :, :])
                    Direct = self.anti_normalization(temp_koopman_s[vis_num, :, :])
                    VisualizeUtils.plot_multi_X_and_Y(self.args, true_state, [AE, Direct], self.to_numpy(u_tensor[vis_num, :, :]),
                                                      self.state_name, self.action_name, title=self.domain_name, label=["AE", "Direct"],
                                                      is_save=True, save_dir=save_dir, draw_path=True)
                error_save_dir = base_path % (batch_idx, vis_num)
                VisualizeUtils.draw_latent_error(true_latent_s[vis_num, :, :],
                                                 [pred_latent_s[vis_num, :, :], np.zeros_like(true_latent_s[vis_num, :, :]),
                                                  -pred_latent_s[vis_num, :, :] + true_latent_s[vis_num, :, :]], is_show=False,
                                                 label=['error', 'true', 'pred'], is_save=True, save_dir=error_save_dir, figsize=(10, 10))

        # Average the losses over multiple steps (for linear, reconstruction, and prediction)
        linear_loss = linear_loss / multi_steps
        recon_loss_C = recon_loss_C / multi_steps
        pred_loss_C = pred_loss_C / multi_steps

        # ---------------------- A regularization loss, and C regularization loss CONTROLLABILITY CONSTRAINT-------------------------------
        # Form the controllability matrix and calculate the singular value decomposition loss (SVD)
        Am = self.koopman_net.form_A_from_eigenvalues().T
        A_dim = self.s_dim + self.lift_dim
        temp = self.koopman_net.B.T

        # Build the controllability matrix
        controllability_matrix = torch.zeros((A_dim, A_dim * self.u_dim))
        for i in range(A_dim):
            controllability_matrix[:, i * self.u_dim:(i + 1) * self.u_dim] = temp
            temp = torch.mm(Am, temp)

        # Perform singular value decomposition
        U, S, Vh = torch.linalg.svd(controllability_matrix)
        c = S.abs() - 0.2 * torch.ones(1)  # 0.992
        mask = c < 0

        # Calculate the A and C regularization loss (equation(3)(4), LA = Σ (for j in A) || λ(A)_j - η1 ||^2, LC = Σ (for j in C) || σ(C)_j - η2 ||^2)
        for item in c[mask]:
            svd_loss += 1*torch.norm(item,p=2)
        for i in range(self.num_complex_pair):
            idx = 2 * i
            c1 = self.koopman_net.A[idx].abs().cpu() - 0.5 * torch.ones(1)
            A_eig_loss += 1*torch.norm(c1, p=2)  #>0.97
            c2 = self.koopman_net.A[idx+1].abs().cpu() - 0 * torch.ones(1)
            A_eig_loss += torch.norm(c2, p=2)
        for i in range(self.num_real):
            idx = 2 * self.num_complex_pair + i
            c = self.koopman_net.A[idx].abs().cpu() - 0.5 * torch.ones(1)
            A_eig_loss += 1*torch.norm(c, p=2)
  #---------------------- T_eig_loss-------------------------------
        # Eigenvalue decomposition of T matrix
        T = self.koopman_net.T.cpu()
        T_eig,_=torch.linalg.eigh(T)  # Compute the eigenvalues of T
        # Calculate the deviation of the eigenvalues from 1 (assuming they should be near 1)
        d = T_eig.abs()-torch.ones(1)
        T_eig_loss = torch.norm(d,p=2) # Equation (S3) in the supplementary section 1: LT = Σ (from i=1 to 12) || λ(T)_i - 1 ||^2

        # Final loss calculation (depending on stage: train/val/test)
        if stage == "test":
            loss =  linear_loss+recon_loss_C + pred_loss_C
            return loss,linear_loss,recon_loss_C,pred_loss_C
        else:
            loss = self.koopman_lam * linear_loss +self.svd_lam*svd_loss+self.A_eig_lam* A_eig_loss + self.T_eig_lam* T_eig_loss+self.recon_lam_C * recon_loss_C+self.pred_lam_C*pred_loss_C
            return loss, linear_loss, T_eig_loss,A_eig_loss,recon_loss_C,pred_loss_C, svd_loss

    def calc_RMSE(self, state_tensor, pred_state_tensor):
        """
                Calculates the RMSE (Root Mean Squared Error) between the true states and predicted states.

                Args:
                    state_tensor (tensor): The true state data.
                    pred_state_tensor (tensor): The predicted state data.
        """
        true_state = self.to_numpy(state_tensor[:, :, -self.s_dim:])
        pred_state = self.to_numpy(pred_state_tensor[:, :, -self.s_dim:])
        s_shape = np.shape(true_state)
        true_state = np.reshape(true_state, (s_shape[0] * s_shape[1], s_shape[-1]))
        pred_state = np.reshape(pred_state, (s_shape[0] * s_shape[1], s_shape[-1]))
        true_state = self.anti_normalization(true_state)
        pred_state = self.anti_normalization(pred_state)
        error = true_state - pred_state
        MSE = np.mean(np.square(error), axis=0)
        RMSE = np.sqrt(MSE)
        self.rmse_list.append(RMSE)
        self.mse_list.append(MSE)

    def save_AB_to_file(self):
        """
                Saves the Koopman operator matrices (A, B, T) to a file for later use.
        """
        data_dict = dict()
        A = self.koopman_net.A.data.cpu().numpy()
        data_dict["A"] = A
        B = self.koopman_net.B.data.cpu().numpy() 
        data_dict["B"] = B
        T =  self.koopman_net.T.data.cpu().numpy()
        data_dict["T"] = T
        save_dir = os.path.split(self.hparams['image_path'])[0] + "/ABT"
        if self.global_step <= 400:
            CommonUtils.make_dirs(save_dir)
        save_dir = save_dir + "/ABT_%d.mat" % self.global_step
        CommonUtils.save_dict_as_mat(data_dict, save_dir)

    def to_device(self, t):
        """
                Moves a tensor or list of tensors to the appropriate device (GPU or CPU).

                Args:
                    t (tensor or list): The tensor (or list of tensors) to move to the device.

                Returns:
                    tensor: The tensor (or list of tensors) on the appropriate device.
        """
        if isinstance(t, list):
            for i in range(len(t)):
                if isinstance(t[i], np.ndarray):
                    if isinstance(t[i], np.ndarray):
                        t[i] = torch.from_numpy(t[i])
                    if isinstance(t[i], torch.Tensor):
                        t[i] = t[i].to(self.device)
        if isinstance(t, np.ndarray):
            t = torch.from_numpy(t)
        if isinstance(t, torch.Tensor):
            t = t.to(self.device, dtype=torch.float32)
        return t

    def to_numpy(self, t):
        """
                Converts a tensor or dictionary of tensors into a numpy array.

                Args:
                    t (tensor or dict): The tensor (or dictionary of tensors) to convert.

                Returns:
                    numpy.ndarray: The numpy array.
        """
        if isinstance(t, np.ndarray):
            return t
        if isinstance(t, torch.Tensor):
            return t.data.cpu().numpy()
        if isinstance(t, dict):
            for key, value in t.items():
                t[key] = self.to_numpy(value)
            return t
    
    def anti_normalization(self, t):   # method 2, recover from [-1,1]
        """
        Converts normalized data back to its original scale based on the provided bounds.

        Args:
            t (numpy.ndarray): The normalized data to revert.

        Returns:
            numpy.ndarray: The denormalized data.
        """
        t = np.squeeze(t) 
        X_min = self.state_bound[0, :]
        X_max = self.state_bound[1, :]
        t = (t+1)*(X_max - X_min)/2 + X_min
        return t  

    def get_model_name(self):
        """
                Retrieves the name of the model or the directory where the model is saved.

                Returns:
                    str: The model name or path.
        """
        if self.is_predict:
            log_dir = os.path.split(self.hparams["restore_model_path"])[0]
            model_name = CommonUtils.get_upLevel_dir(log_dir, 1, True)
        else:
            model_name = os.path.split(self.hparams['path'])
        return model_name

    def save_parameters_for_matlab(self): 
        """
        Saves the model parameters (encoder, decoder, Koopman matrices) to a .mat file for use in MATLAB,
        commonly used for control applications.

        Returns:
            None
        """
        save_path = self.args['matlab_file_path']
        if os.path.exists(save_path):
            print('================= params_for_matlab.mat has existed !!!! ======================')
            return
        print(type(self.encoder_net.named_parameters())) # why we need to print the type?
        nn = dict() # definie a dictionary
        encoder_weights = dict()
        decoder_weights = dict()
        koopman_weights = dict()
        for n, p in self.encoder_net.named_parameters(): # n: the name of the parameter; p: the parameter itself
            encoder_weights[n] = self.to_numpy(p) # converting the pytorch tensor p into a numpy array.
        for n, p in self.decoder_net.named_parameters():
            decoder_weights[n] = self.to_numpy(p)
        for n, p in self.koopman_net.named_parameters():
            if n == "B.weight":
                koopman_weights['B'] = self.to_numpy(p).T
        koopman_weights['num_real'] = self.koopman_net.num_real
        koopman_weights['num_complex_pair'] = self.koopman_net.num_complex_pair
        koopman_weights['A'] = self.koopman_net.A.cpu().data.numpy()
        koopman_weights['B'] = self.koopman_net.B.cpu().data.numpy()
        koopman_weights['T'] = self.koopman_net.T.cpu().data.numpy()
        # koopman_weights['C'] = self.koopman_net.C.cpu().data.numpy()
        nn['koopman_mode'] = self.koopman_mode
        if self.koopman_mode == 3 or self.koopman_mode == 4:
            nn['cev_width'] = self.koopman_net.cev_width
            nn['rev_width'] = self.koopman_net.rev_width
            nn['cact_type'] = self.koopman_net.cact_type
            nn['ract_type'] = self.koopman_net.ract_type
        nn['latent_mode'] = self.latent_mode
        nn['encoder_weights'] = encoder_weights
        nn['decoder_weights'] = decoder_weights
        nn['koopman_weights'] = koopman_weights
        nn['encoder_widths'] = self.encoder_net.widths
        nn['eact_type'] = self.encoder_net.act_type
        nn['decoder_widths'] = self.decoder_net.widths
        nn['dact_type'] = self.decoder_net.act_type
        nn['s_dim'], nn['u_dim'] = self.s_dim, self.u_dim
        nn['conca_num'] = self.conca
        nn['lift_dim'] = self.lift_dim
        nn['state_bound'] = self.state_bound
        # nn['action_bound'] = self.action_bound
        nn['num_shifts'] = self.num_shifts
        nn['num_koopman_shifts'] = self.num_shifts
        # nn['pose_mode'] = self.pos_mode
        nn['domain_name'] = self.domain_name
        CommonUtils.save_dict_as_mat(nn, save_path) 
        CommonUtils.save_dict_as_pkl(nn, save_path.replace('.mat', '.pkl'))
        print('================ parames file for matlab has been saved in %s =============' % save_path)

    def save_logger_scalers(self):
        """
                Saves the logger scalers (training logs) to a .xlsx file for later analysis.

                Returns:
                    None
        """
        log_dir = os.path.split(self.hparams["restore_model_path"])[0]
        event_path = log_dir + '/default/version_0'
        if not os.path.exists(event_path):
            if os.path.exists(event_path.replace('default', 'lightning_logs')):
                event_path = event_path.replace('default', 'lightning_logs')
        excel_path = log_dir + "/loss_excel.xlsx"
        CommonUtils.exportPLModelLog(event_path, excel_path, None)


if __name__ == '__main__':
    hostname = socket.gethostname() # Get the hostname
    print("========== hostname:", hostname, "=============")
    gpu = 1
    args = config.get_softrobot_args()
    args_path = args.args_file_path # the path to save parameter
    restore_model_path = args.restore_model_path
    args = vars(args)
    num_works = 0
    dm = SoftRobotDataModule(args, shuffle=True, num_workers=num_works)
    limit_val_batches = 1  # 0.2

    # For trainning
    if not args['is_predict']:
        # If is_predict is false, run the following code
        # Define a callback for saving the model
        checkpoint_callback = ModelCheckpoint(monitor='train_loss', dirpath=args['log_dir'], filename='{epoch:02d}-{train_loss:.5f}',
                                              save_top_k=2, save_last=True, mode='min')  # save_top_k=2 means save the best two model

        logger = TensorBoardLogger(args['log_dir'])

        if os.path.exists(args['restore_model_path']):
            # Load an already trained model
            dck = DeepEDMD.load_from_checkpoint(checkpoint_path=args['restore_model_path'], save_params=True,args=args)
            dck.hparams['path'] = args['path']
            dck.hparams['image_path'] = args['image_path']
            dck.hparams['args_file_path'] = args['args_file_path']
            dck.hparams['matlab_file_path'] = args['matlab_file_path']
            dck.hparams['test_image_path'] = args['test_image_path']
            dck.hparams['restore_model_path'] = args['restore_model_path']
            print('============ the model exists and trains continuously============')
            CommonUtils.save_dict_as_pkl(args, args_path)

        else:
            # Train a new model
            CommonUtils.save_dict_as_pkl(args, args_path)
            dck = DeepEDMD(args, save_params=True)
            print('the model does not exist ============')

        lr_monitor = LearningRateMonitor(logging_interval='step')

        trainer = pl.Trainer(logger=logger, limit_val_batches=limit_val_batches,
                             # val_check_interval=1.,  # check_val_every_n_epoch=0.5, val_check_interval=1.
                             check_val_every_n_epoch=10,  # 20
                             num_sanity_val_steps=0,
                             precision=32,
                             sync_batchnorm=True,
                             min_epochs=80,
                             max_epochs=4000,            #Set the trainning epochs
                             callbacks=[checkpoint_callback, lr_monitor])
        dm.setup('fit')
        trainer.fit(dck, datamodule=dm)

    else: #For testing
        dm.setup('test')
        checkpoint_callback = ModelCheckpoint(monitor='test_error', dirpath=args['log_dir'], filename='{epoch:02d}-{val_loss:.5f}',
                                              save_top_k=2, save_last=True, mode='min') 
        logger = TensorBoardLogger(args['log_dir'])
        # print('dir',args['log_dir'])
        dck = DeepEDMD.load_from_checkpoint(checkpoint_path=args['restore_model_path'], save_params=False,args=args)
        dck.hparams['is_predict'] = args['is_predict']
        dck.is_predict = args['is_predict']
        dck.predicted_step = args['predicted_step']
        dck.hparams['test_image_path'] = args['test_image_path']
        dck.hparams['restore_model_path'] = args['restore_model_path']
        test_batches = 1.0 if 'low' in args['domain_name'].lower() else 1.0
        trainer = pl.Trainer(gpus=0, precision=32, limit_test_batches=test_batches,
                             callbacks=[checkpoint_callback])
        trainer.test(model=dck, datamodule=dm)


