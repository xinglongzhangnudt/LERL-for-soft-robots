"""
coder: Yongqian Xiao (xiaoyongqian18@nudt.edu.cn)
function: common functions
"""
import copy
import os
import shutil
import math
import scipy.io as scio
import h5py
import pickle as pkl
import json
import numpy as np
import scipy.spatial.distance
import torch
import time
import zipfile
import hashlib
import pandas as pd
import re
import socket
import yaml
from progressbar import ProgressBar
import logging
from torch.utils.tensorboard import SummaryWriter

# ====================== file operator begin ==============================
def save_dict_as_mat(data_dict: dict, save_dir: str, is_print=True) -> None:
    if isinstance(save_dir, dict) and isinstance(data_dict, str):
        scio.savemat(data_dict, save_dir)
    else:
        scio.savemat(save_dir, data_dict)
    if is_print:
        print("======== save dict as .mat file at %s successfully ===" % save_dir)


def save_dict_as_h5(dict, savePath):
    '''
    save the dict data as a .h5 file
    :param dict:
    :param savePath: the saving path
    '''
    with h5py.File(savePath, 'w') as f:
        for key in dict.keys():
            f[key] = dict.get(key)
        f.close()
    print('save the datas as h5 successfully!!!')


def read_h5(savePath, keys=None) -> dict:
    '''
    read h5 file
    savePath: the path of the h5 file
    keys: a list or a numpy string array of keys, such as ['train_x', 'train_y', 'test_x', 'test_y']
    return: return a dictionary format data contains the datas asked by keys
    '''
    if not os.path.exists(savePath):
        raise Exception('The file is not exist!!!')
    dic = {}
    with h5py.File(savePath, 'r') as f:
        for key in f.keys():
            if keys is not None:
                if key in keys:
                    dic[key] = f[key].value
            else:
                dic[key] = f[key].value
        f.close()
    return dic


def save_dict_as_pkl(d, savePath, is_print=True):
    if isinstance(d, str) and isinstance(savePath, dict):
        temp = d
        d = savePath
        savePath = temp
    file = open(savePath, 'wb+')
    pkl.dump(d, file) # save a  dictionary d to a file represented by the file object
    file.close()
    if is_print:
        print('save %s successfully!!!' % savePath)


def read_pkl_as_dict(file_path) -> dict:
    _, suffix = os.path.splitext(file_path)
    assert suffix == ".pkl", "prompt: wrong file type !!!!!!!!!!"
    if not os.path.exists(file_path):
        raise Exception('The .pkl file is not exist!!! ----> %s ' % file_path)
    with open(file_path, 'rb') as f:
        dict = pkl.load(f)
        f.close()
    return dict


def read_mat_as_dict(file_path) -> dict:
    try:
        data = scio.loadmat(file_path)
    except:
        data = h5py.File(file_path)
    return data


def read_yaml_as_dict(file_path) -> dict:
    f = open(file_path, 'r', encoding='utf-8')
    cfg = f.read()
    d = yaml.safe_load(cfg)
    return d


def pkl2mat(pkl_path, mat_path):
    """
    transform a .pkl file to a .mat file for matlab or something else.
    :param pkl_path: The .pkl source file path
    :param mat_path: The .mat file path for saving
    :return:
    """
    data_dict = read_pkl_as_dict(pkl_path)
    scio.savemat(mat_path, data_dict)


def save_dict_as_txt(list_dict, save_dir, is_print=True):
    with open(save_dir, 'w') as fw:
        if isinstance(list_dict, list):
            for dict in list_dict:
                for key in dict.keys():
                    fw.writelines(key + ': \n' + str(dict.get(key)) + '\n')
        else:
            for key in list_dict.keys():
                fw.writelines(key + ': \n' + str(list_dict.get(key)) + '\n')
        fw.close()
    if is_print:
        print("======== save dict as .mat file at %s successfully ===" % save_dir)


def make_dirs(path):
    """
    :param path:
    :return:
    """
    if isinstance(path, str):
        if is_file(path):
            path = os.path.split(path)[0]
        os.makedirs(path, exist_ok=True)
    elif isinstance(path, list):
        path_num = len(path)
        for i in np.arange(path_num):
            temp_path = path[i]
            if not os.path.splitext(path[i]) == '':
                if os.path.isfile(path[i]):
                    temp_path = os.path.split(path[i])[0]
            os.makedirs(temp_path, exist_ok=True)


def is_file(path):
    str = os.path.splitext(path)
    pattern = re.compile('[0-9]+')
    match = pattern.findall(str[-1])
    common = ['.mp3', '.mp4']
    if os.path.isfile(path) or (not str[-1] == '' and not match) or str[-1] in common:
        return True
    return False


def get_upLevel_dir(path, level=1, is_only_dir=False):
    assert level >= 1
    str = '../'
    for k in np.arange(level - 1):
        str += '../'
    path = os.path.abspath(os.path.join(path, str))
    if is_only_dir:
        return os.path.split(path)[-1]
    return path


class NpEncoder(json.JSONEncoder):
    """
        Function: Save a dictionary to a json file.
        Usage:
            with open('json_path', 'w') as f:
                json.dump(dict_obj, f, sort_keys=True, ensure_ascii=False, indent=4, cls=utils.NpEncoder)
    """

    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(NpEncoder, self).default(obj)


def save_args_as_json(args, save_path):
    """
    save 'args' to a local json file
    :param args: argparse.Namespace or dict, 
    :param save_path: saving path
    :return: 
    """
    save_path = get_change_suffix(save_path, '.json')
    temp_args = copy.deepcopy(args)
    if not isinstance(temp_args, dict):
        temp_args = vars(temp_args)
    for key in temp_args:
        if isinstance(temp_args[key], list):
            temp_args[key] = np.array(temp_args[key])
        if isinstance(temp_args[key], np.ndarray):
            temp_args[key] = np.array2string(temp_args[key]).replace("\n", ";")
    with open(save_path, 'w') as f:
        json.dump(temp_args, f, sort_keys=True, ensure_ascii=False, indent=4, cls=NpEncoder)
    f.close()
    print("Json file has been saved in %s" % save_path)

def save_args_as_pkl(args, save_path):
    """
    save 'args' to a local json file
    :param args: argparse.Namespace or dict,
    :param save_path: saving path
    :return:
    """
    save_path = get_change_suffix(save_path, '.pkl')
    temp_args = copy.deepcopy(args)
    if not isinstance(temp_args, dict):
        temp_args = vars(temp_args)
    for key in temp_args:
        if isinstance(temp_args[key], list):
            temp_args[key] = np.array(temp_args[key])
        if isinstance(temp_args[key], np.ndarray):
            temp_args[key] = np.array2string(temp_args[key]).replace("\n", ";")
    with open(save_path, 'wb+') as f:
        pkl.dump(str(temp_args),f)
    f.close()
    print("pkl file has been saved in %s" % save_path)

def save_dict_as_yaml(data_dict, save_path):
    """dict保存为yaml"""
    assert isinstance(data_dict, dict)
    data_dict = list2string_in_dict(data_dict)
    with open(save_path, 'w') as file:
        file.write(yaml.dump(data_dict, allow_unicode=True))
    print("Yaml file has been saved in %s" % save_path)


def list2string_in_dict(tmp_dict: dict):
    for key in tmp_dict:
        if isinstance(tmp_dict[key], list):
            tmp_dict[key] = np.array(tmp_dict[key])
        if isinstance(tmp_dict[key], np.ndarray):
            tmp_dict[key] = np.array2string(tmp_dict[key]).replace("\n", ";")
        if isinstance(tmp_dict[key], dict):
            tmp_dict[key] = list2string_in_dict(tmp_dict[key])
    return tmp_dict


def update_dict(source_dict: dict, target_dict: dict, keys: list = None) -> dict:
    if keys is None:
        keys = target_dict.keys()
    for key in keys:
        if key in source_dict and key in target_dict:
            source_dict[key] = target_dict[key]
    return source_dict


def get_change_suffix(path, target='.pkl'):
    """
    Check whether the file suffix is 'target', change it to 'target' if not.
    :param path:
    :param target:
    :return:
    """
    path_suffix = os.path.splitext(path)[-1]
    if not path_suffix == target:
        path = path.replace(path_suffix, target)
    return path


def iterate_file(base_path: str, suffix: str, is_include_child=False, contain_str: list = [],
                 contain_str_in_path: list = [],
                 not_contain_str_in_name: list = [], not_contain_str_in_path: list = []) -> list:
    """
    iterate all files of suffix
    :param base_path: root path
    :param suffix: suffix of files that want to find, such as '.py'
    :param is_include_child: whether to iterate through all child folders
    :param conatain_str: list, file_name has to contain contain_str
    :param contain_str_in_path:
    :param not_contain_str_in_name:
    :param not_contain_str_in_path:
    :return: list of filenames
    """
    if not suffix[0] == '.':
        suffix = '.' + suffix
    filepath_result = []
    files = os.listdir(base_path)
    for file in files:
        file_path = os.path.join(base_path, file)
        if os.path.isdir(file_path) and is_include_child:
            filepath_result.extend(iterate_file(file_path, suffix, is_include_child, contain_str))
        elif os.path.isfile(file_path):
            if os.path.splitext(file_path)[-1] == suffix:
                filepath_result.append(file_path)
    if len(contain_str) > 0 or len(not_contain_str_in_name) > 0 or len(not_contain_str_in_path) > 0 or len(contain_str_in_path) > 0:
        filepath = []
        for file in filepath_result:
            file_ok = True
            for k in np.arange(len(contain_str)):
                if not contain_str[k] in os.path.split(file)[-1]:
                    file_ok = False
            for k in range(len(not_contain_str_in_name)):
                if not_contain_str_in_name[k] in os.path.split(file)[-1]:
                    file_ok = False
                    continue
            for k in range(len(not_contain_str_in_path)):
                if not_contain_str_in_path[k] in file:
                    file_ok = False
                    continue
            for k in range(len(contain_str_in_path)):
                if contain_str_in_path[k] not in os.path.dirname(file):
                    file_ok = False
                    continue
            if file_ok:
                filepath.append(file)
        return filepath
    return filepath_result


def delete_files(file_paths: list) -> None:
    """
    :param file_paths: 
    :return: 
    """
    for path in file_paths:
        if os.path.exists(path) and os.path.isfile(path):
            os.remove(path)


def list2zip(file_path: list, zip_path: str, is_preserve_dir=True):
    """
    zip all files in file_path to a zip file
    :param file_path: a list of files
    :param zip_path: path to save the zip file
    :param is_perserve_dir: whether preserve the dir structure
    :return:
    """
    with zipfile.ZipFile(zip_path, 'w') as zipobj:
        for file in file_path:
            if is_preserve_dir:
                # preserve the original dir structure
                zipobj.write(file, file)
            else:
                # save all file in a dir
                zipobj.write(file, os.path.split(file)[-1])


def copy_file(path, target_path=None):
    assert os.path.exists(path)
    if target_path is None:
        file, suffix = os.path.splitext(path)
        target_path = file + '_copy' + suffix
    shutil.copy2(path, target_path)
    return target_path


def getMD5(file_path):
    hasher = hashlib.md5()
    file = open(file_path, 'rb')
    buf = file.read()
    a = hasher.update(buf)
    return str(hasher.hexdigest())


def compareTwoFiles(file_path1, file_path2):

    md5_1 = getMD5(file_path1)
    md5_2 = getMD5(file_path2)
    return md5_1 == md5_2


def compareFilesInTwoDir(dir_path1, dir_path2, suffix, is_include_child=False, contain_str=[]):

    same_files = []
    file_path1 = iterate_file(dir_path1, '.pkl', is_include_child=True, contain_str=['HQEHS3'])
    file_path2 = iterate_file(dir_path2, '.pkl', is_include_child=True, contain_str=['HQEHS3'])
    for file1 in file_path1:
        for file2 in file_path2:
            if os.path.split(file1)[-1] == os.path.split(file2)[-1]:
                is_same = compareTwoFiles(file1, file2)
                if is_same:
                    same_files.append(file1)
                    print("%s ---- has the same file" % (os.path.split(file1)[-1]))


# ------------------- sqlite3 database operator end ----------

def delete_line(array, lines, axis, former=False):
    """
    delete rows or columns in array
        former: if former is True, then delete former 0:lines in axis-dim directly
    """
    if not isinstance(array, np.ndarray):
        raise Exception("'array' should be a np.ndarray")
    if former and isinstance(lines, int):
        lines = range(0, lines)
    array = np.delete(array, lines, axis=axis)
    return array


def rmse(prediction, label, device=None):
    if not torch.is_tensor(prediction):
        prediction = torch.from_numpy(prediction).to(device, dtype=torch.float32)
    else:
        prediction = prediction.to(device)
    if not torch.is_tensor(label):
        label = torch.from_numpy(label).to(device, dtype=torch.float32)
    else:
        label = label.to(device)
    loss = torch.sqrt(2 * torch.nn.MSELoss(reduction='mean')(prediction, label))
    # loss = torch.nn.MSELoss(reduction='sum')(prediction, label)
    return loss


def mse(prediction, label):
    return torch.nn.MSELoss(reduction='mean')(prediction, label)


# ------------------- array operator ---------------------
def list2array(data, dim=-1, add_dim=False):
    """
    Concatenate a list of arrays to a new array in the dimension of 'dim'
    :param data: list
    :param dim: default = -1 -- in a new dimension, the dim to concatenate.
    :return:
    """
    if isinstance(data, np.ndarray):
        return data
    assert isinstance(data, list), "'data' must be a list"
    assert isinstance(data[0], np.ndarray) or torch.is_tensor(data[0]), \
        "type of arrays in 'data' must be ndarray or torch.Tensor instead of %s" % type(data[0])
    length = len(data)
    for i in np.arange(length):
        if i == 0:
            y = data[0]
            if torch.is_tensor(data[0]):
                y = y.data.cpu().numpy()
            if add_dim:
                y = np.expand_dims(y, dim)
        else:
            temp = data[i]
            if torch.is_tensor(temp):
                temp = temp.data.cpu().numpy()
            if add_dim:
                temp = np.expand_dims(temp, dim)
            y = np.concatenate((y, temp), axis=dim)
    y = np.squeeze(y) # eliminate unncessary dimensions in our array
    return y


def array2list(array, dim=0):
    """
    transform an array to a list
    :param array: 
    :param dim: the dim for trans array to list. start from 0
    :return: 
    """
    assert isinstance(array, np.ndarray) or isinstance(array, torch.Tensor), "'data' must be an array or Tensor"
    if isinstance(array, torch.Tensor):
        array = array.data.cpu().numpy()
    shape = array.shape
    dim = dim if dim != -1 else len(shape) - 1
    dims = np.ndim(array)
    t = [i for i in range(dims)]
    t.remove(t[dim])
    t.insert(0, dim)
    tu = tuple(t)
    array = array.transpose(tu)
    size = array.shape[0]
    l = [array[i] for i in range(size)]
    return l


def remove_ros_path():
    import sys
    ros_path = '/opt/ros/kinetic/lib/python2.7/dist-packages'
    if ros_path in sys.path:
        print("ros path has been removed from the system's path")
        sys.path.remove(ros_path)


# ------------------- system information ---------------
def get_current_time_str(split: str = "", include_second: bool = False) -> str:
    if not include_second:
        format_str = "%%Y%s%%m%s%%d%s%%H%s%%M" % (split, split, split, split)
    else:
        format_str = "%%Y%s%%m%s%%d%s%%H%s%%M%s%%S" % (split, split, split, split, split)

    date = time.strftime(format_str, time.localtime())
    return str(date)


def get_os_type():
    """
    :return: windows system return 'Windows' while linux system return 'Linux' string.
    """
    import platform
    return platform.system()


def string_to_ascii_array(string):
    """
    trans string to ascii array
    :param string:
    :return:
    """
    array = []
    if isinstance(string, list):
        for s in string:
            array.append(string_to_ascii_array(s))
    elif isinstance(string, str):
        if string == "":
            array.append(ord(' '))
        for ss in string:
            array.append(ord(ss))
    if isinstance(string, list):
        max_len = 0
        for a in array:
            max_len = max(len(a), max_len)
        for i in np.arange(len(array)):
            if (max_len - len(array[i]) > 0):
                for j in np.arange(max_len - len(array[i])):
                    a = np.concatenate([a, np.array([32])], axis=0)
                array[i] = a
        array = list2array(array, dim=0, add_dim=True)
    else:
        array = np.array(array)
    return array


def extract_num_from_int(num):
    """
    return each scaler of a number
    :param num:
    :return:
    i.e. num = 10103, return --> [1, 0, 1, 0, 3]
    """
    assert np.mod(num, 1) == 0, "The input must be an integer!!!"
    nums = []
    t = 10
    temp = np.floor(num / 1)
    while temp > 0:
        temp_num = np.mod(temp, t).astype(int)
        nums.append(temp_num)
        temp = np.floor(temp / t)
    nums.reverse()
    return nums


def getValueIfExistElseDefault(data_dict, key, default):
    """
    get value if 'key' exists in data_dict else return default
    :param data_dict: dict()
    :param key: the key to get value in data_dict
    :param default: default value if not exist
    :return: 
    """
    if key in data_dict:
        return data_dict[key]
    else:
        return default


# ------------------ vehicle ------------------
def GlobalCoor2LocalCoor(transVec, rotateMat, gbCoor):
    """
    translate global coor to local coor
    :param transVec: translation matrix -- (2, 1)
    :param rotateMat: rotation  matrix -- (2, 2)
    :param gbCoor: the global coor -- (2, None) --> ( x1, y1; x2, y2; ...)
    :return:
    """
    lcCoor = np.matmul(rotateMat, gbCoor - transVec)
    return lcCoor


def LocalCoor2GlobalCoor(transVec, rotateMat, loCoor):
    """
    transform local to global coor. Note that the transVec and rotetaMat are the same for GlobalCoor2LocalCoor.
    :param transVec: translation matrix -- (2, 1)
    :param rotateMat: rotation  matrix -- (2, 2)
    :param loCoor: the local coor -- (2, None) --> ( x1, y1; x2, y2; ...)
    :return:
    """
    rotateMat1 = copy.copy(rotateMat)
    rotateMat1[0, 1] = -1 * rotateMat1[0, 1]  # sin -> -sin
    rotateMat1[1, 0] = -1 * rotateMat1[1, 0]  # -sin -> sin
    glbCoor = np.matmul(rotateMat1, loCoor) + transVec
    return glbCoor


def ComputeMat(x0, y0, heading0):
    """
    calculate the translation and rotating matrices
    :param x: the origin of local coordinates in the global coordinate
    :param y:
    :param heading:
    :return:
    """
    x, y = copy.deepcopy(x0), copy.deepcopy(y0)
    heading = copy.deepcopy(heading0)
    transVec = np.zeros([2, 1])
    rotateMat = np.zeros([2, 2])
    transVec[0, 0] = x
    transVec[1, 0] = y
    rotateMat[0, 0] = np.cos(heading)
    rotateMat[0, 1] = np.sin(heading)
    rotateMat[1, 0] = -np.sin(heading)
    rotateMat[1, 1] = np.cos(heading)
    return transVec, rotateMat


def global2local(x: np.ndarray, original: np.ndarray = None) -> np.ndarray:
    """
    using the above three funcitons to transform x to local
    :param x: (steps, 3) -- [X, Y, Yaw]
    :param original: original point for transformation, (1, 3) -- [X0, Y0, Yaw0]
    :return:
    """
    x = copy.deepcopy(x)
    if original is None:
        original = x[0, :]
    transVec, rotateMat = ComputeMat(original[0], original[1], original[2])
    x[:, 0:2] = GlobalCoor2LocalCoor(transVec, rotateMat, x[:, :2].T).T
    x[:, 2] -= original[2]
    return x


def cartesian2ImageCoor(original_x, original_y, cartCoor):

    cartCoor[0, :] = original_x + cartCoor[0, :]
    cartCoor[1, :] = original_y + cartCoor[1, :]
    return cartCoor


def imageCorr2Cartesian(original_x, original_y, imageCoor):

    imageCoor[0, :] = original_x + imageCoor[0, :]
    imageCoor[1, :] = original_y - imageCoor[1, :]
    return imageCoor


def findNearestPoint(path: np.ndarray, point: np.ndarray) -> int:
    """
    find the index of nearest point in path to `point`
    :param path: (bs, N, 2)
    :param point: (bs, 2)
    :return: idx, and the distance
    """
    if torch.is_tensor(path):
        path = path.data.cpu().numpy()
    assert path.shape[-1] == 2 and point.shape[-1] == 2, ""
    if np.ndim(path) == 3:
        assert path.shape[0] == point.shape[0]
        if np.ndim(point) == 2:
            point = point[:, np.newaxis, :]
    if np.ndim(path) == 2:
        path = path[np.newaxis, :]
    if np.ndim(point) == 2:
        point = point[np.newaxis, :]
    batch_size = path.shape[0]
    coor = path - point
    a_index = [i for i in range(batch_size)]
    dis = np.sqrt(np.square(coor[:, :, 0]) + np.square(coor[:, :, 1]))
    idx = np.argmin(dis, 1)
    min_dis = dis[a_index, idx]
    return idx, min_dis


def calPathLength(path: np.ndarray, is_cumsum: bool = False) -> float:

    x1, y1 = path[0:-1, 0], path[0:-1, 1]
    x2, y2 = path[1:, 0], path[1:, 1]
    dis = np.sqrt(np.power(x1 - x2, 2) + np.power(y1 - y2, 2))
    return np.cumsum(dis, 0) if is_cumsum else sum(dis)


def dis_points_to_points(ps1: np.ndarray, ps2: np.ndarray) -> np.ndarray:

    return scipy.spatial.distance.cdist(ps1, ps2, 'euclidean')


def minmax_dis_points_to_points(ps1: np.ndarray, ps2: np.ndarray, is_min: bool = True) -> np.ndarray:

    diss = dis_points_to_points(ps1, ps2)
    if is_min:
        return np.min(diss, axis=1)
    else:
        return np.max(diss, axis=1)


def dis_point_to_points(p: np.ndarray, path: np.ndarray):
    """
    calc the distaces between one point to points
    @param p: (1, 2)
    @param path: (num_p, 2)
    @return: dis
    """
    tmp = path - p
    dis = np.sqrt(np.square(tmp[:, 0]) + np.square(tmp[:, 1]))
    return dis


def min_dis_of_point_to_points(p: np.ndarray, path: np.ndarray, min_max: int = 1):
    """

    @param p: p: (1, 2)
    @param path: path: (num_p, 2)
    @param min_max: 1: min; 2: max
    @return: the minimum or maximum value and corresponding index
    """
    dis = dis_point_to_points(p, path)
    if min_max == 1:
        idx = np.argmin(dis)
    else:
        idx = np.argmax(dis)
    return dis[idx], idx


def path_dis(path: np.ndarray):

    if path.shape[0] < path.shape[1] and not path.shape[1] == 2:
        path = path.transpose()
    tmp = np.square(path[0:-1, :] - path[1:, :])
    dis = np.sum(np.sqrt(tmp[:, 0] + tmp[:, 1]))
    return dis


def point_to_segment_distance(px, py, x1, y1, x2, y2):

    line_dis = line_magnitude(x1, y1, x2, y2)
    if line_dis < 0.00000001:
        return 9999
    else:
        u1 = (((px - x1) * (x2 - x1)) + ((py - y1) * (y2 - y1)))
        u = u1 / (line_dis * line_dis)
        if (u < 0.00001) or (u > 1):
            ix = line_magnitude(px, py, x1, y1)
            iy = line_magnitude(px, py, x2, y2)
            if ix > iy:
                distance = iy
            else:
                distance = ix
        else:
            ix = x1 + u * (x2 - x1)
            iy = y1 + u * (y2 - y1)
            distance = line_magnitude(px, py, ix, iy)
        return distance


def exportPLModelLog(event_path, excelPath=None, matPath=None):
    from tensorboard.backend.event_processing import event_accumulator
    def search_event(path):
        dir_name = []
        file_name = []
        file_size = []
        event_num = 0
        for filename in os.listdir(path):
            temp_path = os.path.join(path, filename)
            if os.path.isdir(temp_path):
                temp_file_name = search_event(temp_path)
                file_name.extend(temp_file_name)
            elif os.path.isfile(temp_path):
                if 'tfevents' in temp_path:
                    event_num += 1
                    file_name.append(temp_path)
                    file_size.append(os.path.getsize(temp_path))
        if event_num > 1:
            index = file_size.index(max(file_size))
            temp_file_path = file_name[index]
            if isinstance(temp_file_path, str):
                temp_file_path = [temp_file_path]
            return temp_file_path
        return file_name

    def readEvent(event_path):
        event = event_accumulator.EventAccumulator(event_path)
        event.Reload()
        print("\033[1;34m data label：\033[0m")
        print(event.Tags())
        print("\033[1;34m：\033[0m")
        # print(event.scalars.Keys())
        scalar_name = []
        scalar_data = []
        for name in event.scalars.Keys():
            print(name)
            if 'hp_metric' not in name:
                scalar_name.append(name)
                scalar_data.append(event.scalars.Items(name))
        return scalar_name, scalar_data

    def exportToexcel(file_name, excelName):
        writer = pd.ExcelWriter(excelName)
        for i in range(len(file_name)):
            event_path = file_name[i]
            scalar_name, scalar_data = readEvent(event_path)
            for i in np.arange(len(scalar_name)):
                scalarValue = scalar_data[i]
                scalarName = scalar_name[i]
                if "/" in scalarName:
                    temp_names = scalar_name[i].split("/")
                    temp_paths = os.path.split(event_path)
                    scalarName = os.path.split(temp_paths[0])[1]
                data = pd.DataFrame(scalarValue)
                data.to_excel(writer, sheet_name=scalarName)
        writer.save()

# ~~~~~~~~~~~~~~~~~~~~ 判断 ~~~~~~~~~~~~~~~~~~~~
def is_equal(a, b=0):
    if abs(a - b < 0.00001):
        return True
    else:
        return False


# =============== RMSE and MSE ================
def get_RMSE(true, pred, dim=0):
    """
    calc RMSE
    :param true and pred: (batch_size, s_dim) 
    :param dim: 
    :return: 
    """
    error = true - pred
    MSE = np.mean(np.square(error), axis=dim)
    RMSE = np.sqrt(MSE)
    return RMSE, MSE


# =============== modified the suffix of files =======
def modify_suffix_files(paths: list, target_suffix: str, delete_old: bool = False) -> None:
    """
    modify the suffix of files in paths to target_suffix
    :param paths: list -- files needed to modify the suffix
    :param target_suffix -- the target suffix
    """
    pbar = ProgressBar()
    for path in pbar(paths):
        path_name, suffix = os.path.splitext(path)
        shutil.copy2(path, path_name + target_suffix)
        if delete_old:
            os.remove(path)
        # print("hehe")
    pbar.finish()


def modify_file_name(paths: list, target_str: str, original_str: str, delete_old: bool = False,
                     replace_in_path: bool = False):

    if isinstance(paths, str):
        paths = [paths]
    pbar = ProgressBar()
    for path in pbar(paths):
        assert os.path.exists(path)
        if replace_in_path:
            target_path = path.replace(original_str, target_str)
        else:
            dir_name, file_name = os.path.split(path)
            file_name = file_name.replace(original_str, target_str)
            target_path = os.path.join(dir_name, file_name)
        if not target_path == path:
            shutil.copy2(path, target_path)
            if delete_old:
                os.remove(path)
    pbar.finish()


def queryExistedFonts():
    from matplotlib.font_manager import FontManager

    mpl_fonts = set(f.name for f in FontManager().ttflist)

    print('all font list get from matplotlib.font_manager:')
    for f in sorted(mpl_fonts):
        print('\t' + f)


def line_magnitude(x1, y1, x2, y2):
    lineMagnitude = math.sqrt(math.pow((x2 - x1), 2) + math.pow((y2 - y1), 2))
    return lineMagnitude


def model_structure(model, is_print: bool = False):
    blank = ' '
    if is_print:
        print('-' * 90)
        print('|' + ' ' * 16 + 'weight name' + ' ' * 15 + '|' \
              + ' ' * 15 + 'weight shape' + ' ' * 15 + '|' \
              + ' ' * 3 + 'number' + ' ' * 3 + '|')
        print('-' * 90)
    num_para = 0
    type_size = 1

    for index, (key, w_variable) in enumerate(model.named_parameters()):
        if len(key) <= 40:
            key = key + (40 - len(key)) * blank
        shape = str(w_variable.shape)
        if len(shape) <= 40:
            shape = shape + (40 - len(shape)) * blank
        each_para = 1
        for k in w_variable.shape:
            each_para *= k
        num_para += each_para
        str_num = str(each_para)
        if len(str_num) <= 10:
            str_num = str_num + (10 - len(str_num)) * blank
        if is_print:
            print('| {} | {} | {} |'.format(key, shape, str_num))
    print('-' * 90)
    print('The total number of parameters: ' + str(num_para))
    print('The parameters of Model {}: {:4f}M'.format(model._get_name(), num_para * type_size / 1000 / 1000))
    print('-' * 90)
    return num_para


def models_structure(models: list, is_print: bool = False):
    num_params = 0
    if isinstance(models, list):
        for model in models:
            num_params += model_structure(model, is_print)
    else:
        num_params += model_structure(models, is_print)
    return num_params



class Logger():
    def __init__(self, terminal_level: int = logging.DEBUG, file_level: int = logging.INFO, is_save: bool = False, save_path: str = None,
                 logger_name: str = None, format: str = None):
        if logger_name is None:
            logger_name = get_current_time_str("_", True)
        if format is None:
            format = '%(asctime)s - %(levelno)s : %(message)s'
        if is_save:
            assert save_path is not None, " if you wanna save the log, save path should be given"
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(level=terminal_level)
        formatter = logging.Formatter(format)

        if is_save:
            file_handler = logging.FileHandler(save_path)
            file_handler.setLevel(level=file_level)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)

        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(level=terminal_level)
        stream_handler.setFormatter(formatter)
        self.logger.addHandler(stream_handler)

        tb_dir = get_upLevel_dir(save_path, 1) + "/tb"
        self.writer = SummaryWriter(tb_dir)

    def log(self, message, level: int = logging.INFO):
        self.logger.log(level=level, msg=message)

    def add_scalar(self, main_tag: str, value, global_step: int):
        """
        add scalar value
        :param main_tag: str, e.g., "train/loss"
        :param value: scalar value, e.g., 2.5
        :param global_step: the current training step
        :return:
        """
        self.writer.add_scalar(main_tag, value, global_step)

    def add_scalars(self, main_tag: str, scalar_dict: dict, global_step: int):
        """
        add multiple scalar value
        :param main_tag: str, e.g., "train/loss"
        :param scalar_dict: e.g., {"a_loss": 1.5, "b_loss": 1.8}
        :param global_step:
        :return:
        """
        self.add_scalars(main_tag, scalar_dict, global_step)


# -------------- Others --------------
def pin_yin_order():

    from xpinyin import Pinyin
    result = []
    for item in lis:
        result.append((pin.get_pinyin(item), item))
    result.sort()
    for i in range(len(result)):
        result[i] = result[i][1]
    result = ' '.join(result)
    return result


def download(url: str, save_path: str):
    """
    download the url file to save_path
    :param url:
    :param save_path:
    :return:
    """
    import urllib
    urllib.request.urlretrieve(url, save_path)
    print("File has been downloaded: %s" % save_path)


def isTwoPolygonOverlap(poly1: np.ndarray, poly2: np.ndarray):
    """
    :param poly1: shape -- (None, 2)
    :param poly2: shape -- (None, 2)
    :return:
    """
    assert poly1.shape[1] == 2 and poly2.shape[1] == 2
    poly_area1 = calcPolygonArea(poly1)
    poly_area2 = calcPolygonArea(poly2)
    vex_num1 = poly1.shape[0]
    vex_num2 = poly2.shape[0]
    for i in range(vex_num1):
        area = 0
        point = poly1[i, :]
        for j in range(vex_num2):
            area = area + triangleArea(point, poly2[j, :], poly2[(j + 1) % vex_num2, :])
        if area <= poly_area2:
            return True
    return False


def calcPolygonArea(points: np.ndarray):
    """
    :param points: (None, 2)
    :return:
    """
    sizep = points.shape[0]
    assert sizep >= 3
    area = points[-1, 0] * points[0, 1] - points[0, 0] * points[-1, 1]
    for i in range(1, sizep):
        v = i - 1
        area += (points[v, 0] * points[i, 1])
        area -= (points[i, 0] * points[v, 1])
    return 0.5 * abs(area)


def triangleArea(p1: np.ndarray, p2: np.ndarray, p3: np.ndarray) -> float:
    """
    :param p1/p2/p3: shape(1, 2)
    :return:
    """
    a = np.linalg.norm(p1 - p2)
    b = np.linalg.norm(p1 - p3)
    c = np.linalg.norm(p2 - p3)
    half = (a + b + c) / 2
    area = np.sqrt(half * (half - a) * (half - b) * (half - c))
    return area


# ---------------------- 代码保存 --------------------

def commonFilesPath(hostname):
    if 'buduo' in hostname or 't640' in hostname or 'nudt302' in hostname:
        return "/home/leac/CustomizeUtils"
    elif 'shaw-computer' in hostname:  # 技嘉3090 in win11
        return "home/leac/CustomizeUtils"
    elif 'dell' in hostname:
        return "/home/leac/CustomizeUtils"


def save_source_files(expe_name, arg_dict=None, mid_dir =None):
    """
    :param expe_name:
    :param arg_dict:
    :return:
    """
    hostname = socket.gethostname()
    common_path = commonFilesPath(hostname)
    src_path = os.getcwd()
    src_path = src_path.replace("\\", "/")
    cur_path = os.path.split(os.getcwd())[0]
    cur_path = cur_path.replace("\\", "/")
    print("current path:   ", cur_path)
    common_files = iterate_file(common_path, ".py", True)
    src_files = iterate_file(src_path, '.py', True)
    src_files.extend(common_files)
    if mid_dir is None:
        work_dir = cur_path + "/%s" % expe_name
    else:
        work_dir = cur_path + "/%s/%s" % (mid_dir, expe_name)
    make_dirs(work_dir)
    list2zip(src_files, os.path.join(work_dir, 'src_files.zip'))
    if arg_dict is not None:
        if not isinstance(arg_dict, dict):
            arg_dict = vars(arg_dict)
        save_dict_as_yaml(arg_dict, work_dir + "/args.yaml")


def seed_everywhere(seed_value):
    import numpy as np
    import torch
    import random
    import os


    np.random.seed(seed_value)
    random.seed(seed_value)
    os.environ['PYTHONHASHSEED'] = str(seed_value)

    torch.manual_seed(seed_value)
    torch.cuda.manual_seed(seed_value)
    # torch.cuda.manual_seed_all(seed_value)

    torch.backends.cudnn.deterministic = True
