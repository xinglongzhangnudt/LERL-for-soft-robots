"""
Author: Yongqian Xiao (xiaoyongqian18@nudt.edu.cn)
Function: functions for visualization
"""
import copy

import CommonUtils

# matplotlib.use('Agg')
# import matplotlib.pyplot as plt

import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt

import torch
from matplotlib import animation
import numpy as np
import io, os
import sys
import time

ros_path = '/opt/ros/kinetic/lib/python2.7/dist-packages'
if ros_path in sys.path:
    print("ros path has been removed from the system's path")
    sys.path.remove(ros_path)
import cv2
import CommonUtils as CMUtils
from PIL import Image
import torch
import torchvision

# plt.rc('font', family='STKaiti')  # 中文支持，特别注意：不同字体，保存的pdf文档所占空间大小不同，adobe 的字体导出的 pdf 要占10多M空间
# matplotlib.rcParams['axes.unicode_minus'] = False  # 负号不能正常显示


def plot_reward(pred_r, true_r, save_dir=None, is_save=False, is_show=False):
    """
    draw multi-episodes in a figure
    :param pred_r: array -- shape=[ep_num, steps]
    :param true_r: same to pred_r
    :param save_dir: path to save figure
    :param is_save: if save_dir is not None, and is_save is True, then save the figure
    :param is_show: flag to show the figure
    :return: Nothing
    """
    ep_nums = pred_r.shape[0]
    # draw up to 3 episodes
    x = np.arange(1, true_r.shape[1] + 1)
    for i in np.arange(min(ep_nums, 3)):
        plt.subplot(3, 1, i + 1)
        plt.plot(x, true_r[i, :], label='true')
        plt.plot(x, pred_r[i, :], label='pred')
    plt.legend()
    if is_show:
        plt.ion()
        plt.show()
    if save_dir is not None and is_save:
        plt.savefig(save_dir)
        time.sleep(0.1)
    plt.close()


def make_grid(seq_img, num_row=10):
    """
    将图像用 torchvision 中的 make_grid 函数套个边框返回
    @param seq_img: 真实图像，尺寸为: list -- steps, shape = height x width (x 3 or 1), 或者: array, shape= height x width (x 3 or 1) x steps
    @param num_row: 单行的图像数
    @return:
    """
    is_gray = False
    if isinstance(seq_img, np.ndarray):
        if np.ndim(seq_img) == 3:
            is_gray = True
        if is_gray:
            seq_img = seq_img.transpose(2, 0, 1)
        else:
            seq_img = seq_img.transpose(3, 2, 0, 1)
        seq_img = torch.as_tensor(seq_img)
    elif isinstance(seq_img, torch.Tensor):
        is_gray = len(list(seq_img.size())) == 3
    else:
        raise Exception("data error")
    # make_grid() 输入: 4D mini-batch Tensor of shape (B x C x H x W) or a list of images all of the same size.
    if is_gray:
        seq_img = seq_img.unsqueeze(1)
        seq_img = torch.cat((seq_img, seq_img), dim=1)  # 当 channel == 1 时好像有问题
    seq_img = torchvision.utils.make_grid(seq_img, nrow=num_row)
    seq_img = seq_img.data.cpu().numpy()
    seq_img = seq_img.transpose(1, 2, 0)
    if is_gray:
        seq_img = seq_img[:, :, 0:1]
    return seq_img


def visualize_image_sequence_new(x0, y0=None, save_dir=None, save_num=8, is_show=False, is_save=False,
                                 num_row=None) -> np.ndarray:
    """ 替换plot_Predicted_Images函数
    将真实的图像和预测的图像串起来变为一个更大的图像(上面一行为原图，下面一行为预测图)，并保存。第一张，第二张和最后一张必保存，中间的等间隔保存
    :param args:
    :param x: 真实图像，尺寸为: list -- steps, shape = height x width (x 3 or 1), 或者: array, shape= height x width (x 3 or 1) x steps
    :param y: same to x
    :param save_num: 总共保存predicted_step中的save_num步
    :return: 保存图像到本地
    """
    x = copy.deepcopy(x0)
    y = copy.deepcopy(y0)
    is_list = isinstance(x, list)
    is_gray = False
    if is_list:
        x = CMUtils.list2array(x, add_dim=True, dim=-1)
        if y is not None:
            y = CMUtils.list2array(y, add_dim=True, dim=-1)
    is_gray = np.ndim(x) == 3 or (np.ndim(x) == 4 and x.shape[2] == 1)
    im_h, im_w = x.shape[0], x.shape[1]
    steps = x.shape[-1]
    # 第一张，第二张和最后一张必保存，中间的等间隔保存
    idxs = np.linspace(0, steps - 1, save_num, endpoint=True).astype(int)
    if is_gray:
        x = x[:, :, idxs]
        if y is not None:
            y = y[:, :, idxs]
    else:
        x = x[:, :, :, idxs]
        if y is not None:
            y = y[:, :, :, idxs]
    if num_row is None:
        num_row = save_num if save_num <= 10 else 10
    save_im = make_grid(x, num_row)
    if y is not None:
        y = make_grid(y, num_row)
        save_im = np.concatenate([save_im, y], axis=0)
    if is_save and save_dir is not None:
        if is_gray:
            plt.imsave(save_dir, np.squeeze(save_im), cmap=plt.get_cmap('gray'))
        else:
            plt.imsave(save_dir, save_im)
    if is_show:
        if is_gray:
            plt.imshow(np.squeeze(save_im), cmap=plt.get_cmap('gray'))
        else:
            plt.imshow(save_im)
        # plt.ion()
        plt.axis('off')  # 去掉坐标轴
        plt.show()
    time.sleep(0.1)
    plt.close()
    return save_im


def visualize_image_sequence(x, y=None, save_dir=None, save_num=8, is_show=False, is_save=False):
    """ 替换plot_Predicted_Images函数
        将真实的图像和预测的图像串起来变为一个更大的图像(上面一行为原图，下面一行为预测
        图)，并保存。第一张，第二张和最后一张必保存，中间的等间隔保存
        :param args:
        :param x: 真实图像，尺寸为: list -- steps, shape = height x width (x 3 or 1), 或者: array, shape= height x width (x 3 or 1) x steps
        :param y: same to x
        :param save_num: 总共保存predicted_step中的save_num步
        :return: 保存图像到本地
        """
    is_list = False
    x = make_grid(x)
    if y is not None:
        y = make_grid(y)
    if isinstance(x, list):
        is_list = True
        steps = len(x)
        im_h, im_w = x[0].shape[0], x[0].shape[1]
        if np.ndim(x[0]) == 2:
            is_gray = True
            for i in np.arange(steps):
                x[i] = x[i][:, :, np.newaxis]
                if y is not None:
                    y[i] = y[i][:, :, np.newaxis]
        elif np.ndim(x[0]) == 3:
            assert x[0].shape[2] == 1 or x[0].shape[2] == 3, "The num of channel has to be 1 or 3"
            is_gray = True if x[0].shape[2] == 1 else False
        else:
            raise Exception("Image dim error")
    elif isinstance(x, np.ndarray):
        im_h, im_w = x.shape[0], x.shape[1]
        if np.ndim(x) == 3:
            is_gray = True
            steps = x.shape[2]
            # for i in np.arange(steps):
            x = x[:, :, np.newaxis, :]
            if y is not None:
                y = y[:, :, np.newaxis, :]
        elif np.ndim(x) == 4:
            assert x.shape[2] == 1 or x.shape[2] == 3, "The num of channel has to be 1 or 3"
            is_gray = True if x[0].shape[2] == 1 else False
            steps = x.shape[3]
    if y is not None:
        save_im = np.zeros([2 * im_h, save_num * im_w, 1]) if is_gray else np.zeros([2 * im_h, save_num * im_w, 3])
    else:
        save_im = np.zeros([im_h, save_num * im_w, 1]) if is_gray else np.zeros([im_h, save_num * im_w, 3])
    interval = np.int(np.floor((steps - 3) / (save_num - 2)))
    for i in np.arange(save_num):
        # 第一张，第二张和最后一张必保存，中间的等间隔保存
        if y is not None:
            temp_im = np.zeros([2 * im_h, im_w, 1]) if is_gray else np.zeros([2 * im_h, im_w, 3])
        else:
            temp_im = np.zeros([im_h, im_w, 1]) if is_gray else np.zeros([im_h, im_w, 3])
        if i == 0 or i == 1:
            index = i
        elif i == save_num - 1:
            index = steps - 1
        else:
            index = (i - 1) * interval + 1
        temp_im[:im_h, :, :] = x[index] if is_list else x[:, :, :, index]
        if y is not None:
            temp_im[im_h:, :, :] = y[index] if is_list else y[:, :, :, index]
        save_im[:, (i * im_w):((i + 1) * im_w), :] = temp_im
        if is_show:
            if is_gray:
                plt.imshow(temp_im, cmap=plt.get_cmap('gray'))
            else:
                plt.imshow(temp_im)
            # plt.ion()
            plt.show()
    if is_save and save_dir is not None:
        if is_gray:
            plt.imsave(save_dir, np.squeeze(save_im), cmap=plt.get_cmap('gray'))
        else:
            plt.imsave(save_dir, save_im)
    if is_show:
        if is_gray:
            plt.imshow(np.squeeze(save_im), cmap=plt.get_cmap('gray'))
        else:
            plt.imshow(save_im)
        # plt.ion()
        plt.show()
    time.sleep(0.1)
    plt.close()
    return save_im


def plot_Predicted_Images(args, Im_true, Im_koop, save_dir, U=None, save_num=8):
    """
    将真实的图像和预测的图像串起来变为一个更大的图像(上面一行为原图，下面一行为预测图)，并保存。第一张，第二张和最后一张必保存，中间的等间隔保存
    :param args:
    :param Im_true: 真实图像，尺寸为: height x width x (predicted_step + 1)
    :param Im_koop: 预测的图像，尺寸为: height x width x (predicted_step + 1)
    :param U: 若系统为受力系统(input_mode=*2),则U是有值的
    :param save_num: 总共保存predicted_step中的save_num步
    :return: 保存图像到本地
    """
    max_Im_true, max_Im_koop = Im_true.max(), Im_koop.max()
    assert max_Im_koop <= 1 and max_Im_koop <= 1, 'the maximum of pictures beyond 1,max_Im_ture=%f, max_Im_koop=%f' % (
        max_Im_true, max_Im_koop)
    is_show = False
    if args is not None:
        height, width = args['image_height'], args['image_width']
    else:
        height, width = Im_true.shape[0], Im_true.shape[1]
    save_im = np.zeros([2 * height, save_num * width])
    steps = np.shape(Im_true)[-1]
    # Im_true = np.reshape(Im_true[-height * width:, :], [height, width, steps])
    interval = np.int(np.floor((steps - 3) / (save_num - 2)))
    # 第一张，第二张和最后一张必保存，中间的等间隔保存
    for i in np.arange(save_num):
        if i == 0 or i == 1:
            temp_im = np.zeros([2 * height, width])
            index = i
            temp_im[:height, :] = Im_true[:, :, index]
            temp_im[height:, :] = Im_koop[:, :, index]
            save_im[:, (i * width):((i + 1) * width)] = temp_im
        elif i == save_num - 1:
            temp_im = np.zeros([2 * height, width])
            index = steps - 1
            temp_im[:height, :] = Im_true[:, :, index]
            temp_im[height:, :] = Im_koop[:, :, index]
            save_im[:, (i * width):((i + 1) * width)] = temp_im
        else:
            index = (i - 1) * interval + 1
            temp_im = np.zeros([2 * height, width])
            temp_im[:height, :] = Im_true[:, :, index]
            temp_im[height:, :] = Im_koop[:, :, index]
            save_im[:, (i * width):((i + 1) * width)] = temp_im
        if is_show:
            plt.imshow(temp_im, cmap=plt.get_cmap('gray'))
            plt.show()
    # save_im = 1 - save_im
    # save_im = save_im
    plt.imsave(save_dir, save_im, cmap=plt.get_cmap('gray'))
    if is_show:
        plt.imshow(save_im, cmap=plt.get_cmap('gray'))
        plt.show()
    return save_im


def plot_multi_X_and_Y(args, X_true, X_koop, U, state_name: list, action_name: list, title: str = None,
                       label: list = None,
                       color: list = None, is_save=False, save_dir=None, is_show=False, ulabel=None, ucolor=None,
                       draw_path=False,
                       figsize=None):
    '''
    来自于 plot_X_and_Y 函数,这个函数是有多个 X_koop 同时绘图,比较模型
    @param X_true: the real states data, shape=(s_dim, steps)
    @param X_koop: List, the approximate data with Koopman, shape=(s_dim, steps)
    @param U: List, the control, shape=(u_dim, steps), None for ignoring
    @param label: List, model's name corresponding to models in X_koop. e.g., ["DEDMD"]
    @param color: List, model's line color and style, e.g., ["r-"]
    @param ulabel: List, model's name corresponding to models in X_koop. e.g., ["DEDMD"]
    @param ucolor: List, model's line color and style, e.g., ["c-", "r-"]
    @return: no return
    '''
    try:
        assert X_true.shape == X_koop[0].shape, "Please make sure that X_true.shape equals X_koop.shape"
    except Exception as e:
        return
    if args is None:
        args = dict()
        args['domain_name'] = ""
        s_dim = X_true.shape[0]
        is_predict = False
    else:
        s_dim = args['s_dim']
        is_predict = args['is_predict']

    if np.ndim(X_true) > 2:
        X_true = np.squeeze(X_true)
    if not isinstance(X_koop, list):
        X_koop = [X_koop]
    model_num = len(X_koop)
    for i in np.arange(model_num):
        if np.ndim(X_koop[i]) > 2:
            X_koop[i] = np.squeeze(X_koop[i])
    if X_true.shape[0] > X_true.shape[1]:
        X_true = np.transpose(X_true)
        for i in np.arange(model_num):
            X_koop[i] = X_koop[i].T
    if label is None:
        label = []
        for i in np.arange(model_num):
            label.append("model_%d" % i)
    if color is None:
        color = ["r--", "b--", "c:", "k-.", "m--", "y--", "g-.", ]
    if ucolor is None:
        ucolor = ["c-", "r--", "b--", "k-.", "m--", "y--", "g-."]
    X_input = X_true
    if not "VXVY" in args['domain_name'] or args is None:
        # print(X_true.shape[0]) # 82
        X_true = X_true[-s_dim:, :] # print(X_true.shape[0]) # 18
        # print('X_true',X_true)
        # print('X_true',X_true.shape) # (18, 82)
        # print('X_true',type(X_true))
        X_true = X_true[:6, :] ### add addtionally  compared with the original code. This is due to the concated state
        # print('X_true[6, :]',X_true[:6, :])
        # print('X_true',X_true.shape) # 
        # X_true = X_true[6, :]
        # X_true = X_true[6,:] # just extract out the current. 
        # print(X_true.shape[-1]) # 82
    index = np.arange(X_true.shape[0])
    if U is not None:
        if not isinstance(U, list):
            U = [U]
            ulen = 1
        else:
            ulen = len(U)
        U0 = np.squeeze(U[0])
        if np.ndim(U0) == 1:
            u_dim = 1
            for ui in np.arange(ulen):
                U[ui] = U[ui][np.newaxis, :]
        else:
            if U0.shape[0] > U0.shape[1]:
                for ui in np.arange(ulen):
                    U[ui] = np.transpose(U[ui])
            u_dim = np.min(U0.shape)
    else:
        u_dim = 0
    if ulabel is None and u_dim > 0:
        ulabel = []
        for k in np.arange(ulen):
            if k == 0:
                ulabel.append("True")
            else:
                ulabel.append('model_%d', k - 1)
    figure_num = len(index) + u_dim
    col_num = 1 if figure_num == 1 else 2
    row_num = int(np.ceil(figure_num / col_num)) + (1 if draw_path else 0)
    if figsize is not None:
        fig = plt.figure(figsize=figsize)
    else:
        fig = plt.figure(figsize=(10, 5))
    plt.subplots_adjust(wspace=0.2, hspace=1.2)
    if title is None:
        fig.suptitle("the result of Testing")
    else:
        fig.suptitle(title)
    # plot the states
    for i in range(len(index)):
        if draw_path and i == 0:
            ax = plt.subplot(row_num, col_num, i + 1)
            ax.plot(X_true[0, :], X_true[1, :], 'c', label=True)
            for k in np.arange(model_num):
                ax.plot(X_koop[k][0, :], X_koop[k][1, :], color[k], label=label[k])
        if draw_path:
            ax = plt.subplot(row_num, col_num, i + 3)
        else:
            ax = plt.subplot(row_num, col_num, i + 1)
        ax.plot(X_true[index[i], :], 'c', label='True')
        for k in np.arange(model_num):
            ax.plot(X_koop[k][index[i], :], color[k], label=label[k])
        ax.set_title('state: %s' % (state_name[i]))
        if i == 0:
            ax.legend()
    # plot the action
    for i in range(u_dim):
        ax = plt.subplot(row_num, col_num, len(index) + i + (3 if draw_path else 1))
        # print(U.shape)
        for k in np.arange(ulen):
            ax.plot(np.squeeze(U[k][i, :]), ucolor[k], label=ulabel[k])
        ax.set_title("action_%d: %s" % (i, action_name[i]))
        if i == 0:
            ax.legend()
    if is_save is True:
        if save_dir is None:
            raise Exception("you should give the saving path")
        plt.savefig(save_dir)
    if is_predict is True:
        if save_dir is None:
            raise Exception("The saving path should be given!!!")
        CMUtils.save_dict_as_mat({'true': X_input, 'predict': X_koop, 'action': U if U is not None else []},
                                 save_dir.replace('png', 'mat'))
    if is_show is True:
        plt.show()
    img = get_img_from_fig(fig, dpi=300)
    # image = Image.fromarray(img)
    # image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    # cv2.imshow('image', image)
    # cv2.waitKey(0)
    plt.close()
    return img


def plot_X_and_Y(args, X_true, X_koop, U, state_name, action_name, title=None, index=None,
                 is_save=False, save_dir=None, is_show=False, draw_path=False):
    '''
    如果index＝None，则plot出X和Y的各个维度的数据，如果index!=0，则plot出index指定的X、Y的维度
    :param X_true: the real states data, shape=(s_dim, steps)
    :param X_koop: the approximate data with Koopman, shape=(s_dim, steps)
    :param U: the control, shape=(u_dim, steps)
    :param index: List, denotes the indexes of X and Y needed to plot
    :param draw_path: bool, True: 将X_true和X_koop的第一二维作为XY画出迪卡尔坐标下的路径(多一个子图)
    :return: no return
    '''
    assert X_true.shape == X_true.shape, "Please make sure that X_true.shape equals X_koop.shape"
    X_true, X_koop, U = np.squeeze(X_true), np.squeeze(X_koop), np.squeeze(U)
    if X_true.shape[0] > X_true.shape[1]:
        X_true = np.transpose(X_true)
        X_koop = np.transpose(X_koop)

    X_input = X_true
    X_true = X_true[-args['s_dim']:, :]
    if index is None:
        index = np.arange(X_true.shape[0])
    if U is not None:
        if np.ndim(U) == 1:
            u_dim = 1
            U = U[np.newaxis, :]
        else:
            if U.shape[0] > U.shape[1]:
                U = np.transpose(U)
            u_dim = np.min(U.shape)
    else:
        u_dim = 0
    figure_num = len(index) + u_dim
    col_num = 2
    row_num = int(np.ceil(figure_num / col_num))
    if draw_path:
        row_num += 1
    fig = plt.figure()
    plt.subplots_adjust(wspace=0.2, hspace=1.2)
    if title is None:
        fig.suptitle("the result of Testing")
    else:
        fig.suptitle(title)
    # plot the states
    for i in range(len(index)):
        if draw_path and i == 0:
            ax = plt.subplot(row_num, col_num, i + 1)
            ax.plot(X_true[index[i], :], X_true[index[i + 1], :], 'c', label='True')
            ax.plot(X_koop[index[i], :], X_koop[index[i + 1], :], 'r--', label='DEDMD')
        if draw_path:
            ax = plt.subplot(row_num, col_num, i + 3)
        else:
            ax = plt.subplot(row_num, col_num, i + 1)
        ax.plot(X_true[index[i], :], 'c', label='True')
        ax.plot(X_koop[index[i], :], 'r--', label='DEDMD')
        ax.set_title('state: %s' % (state_name[i]))
        if i == 0:
            ax.legend()
        # plot the action
    if U is not None:
        for i in range(u_dim):
            ax = plt.subplot(row_num, col_num, len(index) + i + (3 if draw_path else 1))
            # print(U.shape)
            ax.plot(np.squeeze(U[i, :]))
            ax.set_title("action_%d: %s" % (i, action_name[i]))
    if is_save is True:
        if save_dir is None:
            raise Exception("you should give the saving path")
        plt.savefig(save_dir)
    if args['is_predict'] is True:
        if save_dir is None:
            raise Exception("The saving path should be given!!!")
        CMUtils.save_dict_as_mat({'true': X_input, 'predict': X_koop, 'action': U if U is not None else []},
                                 save_dir.replace('png', 'mat'))
    if is_show is True:
        plt.show()
    img = get_img_from_fig(fig, dpi=100)
    # image = Image.fromarray(img)
    # image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    # cv2.imshow('image', image)
    # cv2.waitKey(0)
    plt.close()
    return img


def get_img_from_fig(fig, dpi=180, is_rgb=True):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi)
    buf.seek(0)
    img_arr = np.frombuffer(buf.getvalue(), dtype=np.uint8)
    buf.close()
    img = cv2.imdecode(img_arr, 1)
    if is_rgb:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    else:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    return img


def save_img_from_fig(fig, save_dir, dpi=180, height=None, width=None):
    """
    从 fig 保存图像到本地
    @param fig: matplotlib 对象
    @param save_dir: 保存图像的路径
    @param dpi:
    @param height:
    @param width:
    @return:
    """
    img = get_img_from_fig(fig, dpi)
    if height is not None and width is not None:
        img = cv2.resize(img, dsize=(int(width), int(height)), interpolation=cv2.INTER_LINEAR)
    cv2.imwrite(save_dir, img)


def draw_latent_error(true: np.ndarray, pred: list, label: list, is_show: bool = False, is_save: bool = False,
                      save_dir: str = None, title=None, figsize=None, is_abs=False) -> None:
    """
    @param true: [batch_size, steps, latent_dim]; None: the input of pred is error;
    @param pred: list --> list of [batch, steps, latent_dim]
    @param label: list --> list of "label"
    @return:
    """
    font_size = 11
    if isinstance(pred, np.ndarray):
        pred = [pred]
    for i in range(len(pred)):
        assert np.ndim(pred[i]) == 2 or np.ndim(pred[i]) == 3, "the dims of pred's elements must equal 2 or 3"
        if np.ndim(pred[i]) == 2:
            pred[i] = pred[i][np.newaxis, :, :]
    if true is None:
        true = np.zeros_like(pred[0])
    else:
        if np.ndim(true) == 2:
            true = true[np.newaxis, :, :]
    batch_size = pred[0].shape[0]
    steps = pred[0].shape[1]
    s_dim = pred[0].shape[-1]
    preds = len(pred)
    assert len(pred) == len(label), "should give the label of each pred result"
    dis = {'top': 0.958, 'bottom': 0.055, "left": 0.0, "right": 1., "hspace": 0.144, "wspace": 0.015}
    plt.subplots_adjust(hspace=0.5, wspace=0.8)
    if steps > s_dim * 2:
        if figsize is not None:
            fig, ax = plt.subplots(preds, 1, figsize=figsize)
        else:
            fig, ax = plt.subplots(preds, 1)
    else:
        if figsize is not None:
            fig, ax = plt.subplots(1, preds, figsize=figsize)
        else:
            fig, ax = plt.subplots(1, preds)
    if preds == 1:
        ax = [ax]
    for i in range(preds):
        if np.ndim(true) == 3:
            if batch_size > 1 or is_abs:
                show_data = np.mean(np.abs(true - pred[i]), axis=0).T
            else:
                show_data = np.mean(true - pred[i], axis=0).T
        else:
            show_data = (true - pred).T
            if is_abs:
                show_data = np.abs(show_data)

        figure = ax[i].imshow(show_data.astype(np.float64), cmap=plt.cm.Spectral)
        plt.ylabel('state dim', fontsize=font_size)
        plt.xlabel('Step', fontsize=font_size)
        ax[i].set_title(label[i])
        if i == 0:
            fig.colorbar(figure, ax=ax[i], fraction=0.03, pad=0.05, label='Error')
    cbar_label = 'Error'
    if preds > 1:
        fig.colorbar(figure, ax=[ax[i + 1] for i in range(preds - 1)], fraction=0.03, pad=0.05, label=cbar_label)
    if title is not None:
        plt.suptitle(title)
    if is_show:
        plt.show()
    if is_save:
        assert save_dir is not None, "the saving dir should be given"
        plt.savefig(save_dir)
    plt.close()


def draw_AB(a, b=None, is_show=False, is_save=False, save_dir=None, figsize=None, title=None):
    if isinstance(a, torch.Tensor):
        a = a.detach().data.cpu().numpy()
    if isinstance(b, torch.Tensor):
        b = b.detach().data.cpu().numpy()
    if figsize is not None:
        fig, ax = plt.subplots(1, 2, figsize=figsize)
    else:
        fig, ax = plt.subplots(1, 2)
    a = np.squeeze(a.astype(np.float64))
    figure = ax[0].imshow(a, cmap=plt.cm.Spectral)
    fig.colorbar(figure, ax=[ax[0]], fraction=0.03, pad=0.05)
    if b is not None:
        b = b.astype(np.float64)
        figure = ax[1].imshow(b, cmap=plt.cm.Spectral)
        fig.colorbar(figure, ax=[ax[1]], fraction=0.03, pad=0.05)
    if is_show:
        plt.show()
    if is_save:
        assert save_dir is not None
        plt.savefig(save_dir)


def draw_eigenvalues(eigenvalues: list, real: list = None, imag: list = None, is_save: bool = False,
                     save_dir: str = None,
                     label: list = None, fig_size: tuple = None, is_show: bool = False, color_marker_s_idx: int = 0):
    """

    :param eigenvalues: eigenvalues: list,画多个模型的 eigenvalues
    :param real: 实部
    :param imag: 虚部
    :param is_save:
    :param save_dir:
    :param label: 每个模型的 legend 标签
    :param fig_size: 图像尺寸,例如 (10, 10) cm
    :param color_marker_s_idx: 颜色和marker 的起始索引
    :return:
    """
    if not isinstance(eigenvalues[0], list):
        eigenvalues = [eigenvalues]
    font_size = 16
    save_data = False
    dis = {'top': 0.882, 'bottom': 0.194, "left": 0.078, "right": 0.985, "hspace": 0.2, "wspace": 0.276}
    color = ["b", "r", "forestgreen", "m", 'orange', "k", "y", "springgreen", "grey", "purple", "sandybrown"]
    marker = ["o", "v", "3", "s", "P", "+", "*", "D", "p", "x", "8", "d", "h"]
    aera = [150] * len(eigenvalues)  # [40, 40, 40, 40, 40, 40]
    alpha = [0.8, 0.4]
    if real is None:
        real, imag = [], []
        for ev in eigenvalues:
            tmp_real, tmp_imag = [], []
            for i in range(len(ev)):
                tmp_real.append(ev[i].real)
                tmp_imag.append(ev[i].imag)
            real.append(tmp_real)
            imag.append(tmp_imag)
    if fig_size is not None:
        plt.figure(figsize=fig_size)

    # 画本征值
    for i in range(len(eigenvalues)):
        tmp_real = real[i]
        tmp_imag = imag[i]
        plt.scatter(np.array(tmp_real), np.array(tmp_imag), s=aera[i], color=color[i + color_marker_s_idx],
                    alpha=alpha[1],
                    marker=marker[i + color_marker_s_idx], rasterized=True)
    plt.xlabel("实轴", fontsize=font_size)
    plt.ylabel("虚轴", fontsize=font_size)
    # plt.xlabel("Real axis", fontsize=font_size)
    # plt.ylabel("Imageinary axis", fontsize=font_size)
    if label is not None:
        plt.legend(label, loc='upper left', fontsize=font_size - 2)
    ax = plt.gca()
    ax.set_aspect(1)

    # 画圆
    x, y, r = 0, 0, 1
    ra = np.arange(x - r, x + r, 0.001)
    rb = np.sqrt(np.power(r, 2) - np.power((ra - x), 2)) + y
    plt.plot(ra, rb, color='k', linestyle='-')
    plt.plot(ra, -rb, color='k', linestyle='-')
    # x, y, r = 0, 0, 0.1
    # ra = np.arange(x - r, x + r, 0.001)
    # rb = np.sqrt(np.power(r, 2) - np.power((ra - x), 2)) + y
    # plt.plot(ra, rb, color='r', linestyle='-')
    # plt.plot(ra, -rb, color='r', linestyle='-')
    plt.tick_params(labelsize=font_size - 2)
    if is_save and save_dir is not None:
        plt.savefig(save_dir)
    if is_show:
        plt.show()


def save_video_as_gif(frames, save_dir=None, interval=150):
    """
        Function: make video with given frames and save as "video_prediction.gif"
        Args: frames: list of array. Each frame of array are a image.
                Array: gray image -- h x w; RGB image -- h x w x 3
    """
    if isinstance(frames, str) and isinstance(save_dir, list):
        tmp = frames
        frames = save_dir
        save_dir = tmp

    import torch
    for i in range(len(frames)):
        if isinstance(frames[i], torch.Tensor):
            frames[i] = frames[i].data.cpu().numpy()

    plt.figure()
    if np.ndim(frames[0]) == 2:
        patch = plt.imshow(frames[0], cmap=plt.get_cmap('gray'))
    elif np.ndim(frames[0]) == 3:
        patch = plt.imshow(frames[0])
    plt.axis('off')

    def animate(i):
        patch.set_data(frames[i])
        plt.title('Left: Koopman' + ' ' * 20 + 'Right: GT frame \n Step %d' % (i))

    anim = animation.FuncAnimation(plt.gcf(), animate, frames=len(frames), interval=interval, save_count=len(frames))
    # anim.save('video_prediction.gif', writer='imagemagick')
    if save_dir is None:
        save_dir = 'video_prediction.gif'
    anim.save(save_dir, writer='pillow')
    time.sleep(0.1)
    plt.close()


def pil2array(img: Image) -> np.ndarray:
    """
     Convert an HxW pixels RGB Image into an HxWx3 numpy ndarray
    """
    np_array = np.asarray(img)
    return np_array


def array2pil(image) -> Image:
    """
        Convert an HxWx3/HxW/HxWx1 numpy array or a list into an RGB or a list of Image
    """
    if isinstance(image, np.ndarray):
        if (np.max(image) < 1.1):
            image = image * 255
        if np.ndim(image) == 3 and image.shape[2] == 3:
            img = Image.fromarray(image.astype(np.uint8), 'RGB')
        elif np.ndim(image) == 2 or image.shape[2] == 1:
            img = Image.fromarray(image.astype(np.uint8), 'gray')
    elif isinstance(image, list):
        img = []
        for i in range(len(image)):
            img.append(array2pil(image[i]))
    return img


def get_image_data(name, image, im_h, im_w, is_show=False, return_im=False, img_format=0, is_gray=True):
    """
    针对gym中classic的图像几个图像，进行剪裁,缩放和增强
    :param name: 当前env的名字
    :param image: 图像数据，可由env.render(mode='rgb_array')获得
    :param im_h: 图像高
    :param im_w: 图像宽
    :param is_show: 是否显示当前图像
    :param return_im: True时返回im_h*im_w的图像，False时返回微量
    :return:
    """

    image_width, image_height = im_w, im_h
    if 'CartPole' in name:
        image = image
        image = image[200:310, :, :]
        # image = image[140:310, 50:550, :]
    elif 'Acrobot' in name:
        image = image[40:460, 40:460, :]
    elif 'MountainCar' in name:
        image = image
        # image = image[20:380, :580, :]
    elif 'Pendulum' in name:
        image = image[120:380, 120:380, :]
        # plt.imshow(image)
        # plt.show()
    else:
        raise Exception("Env's name error")
    if is_gray:
        image = Image.fromarray(image)
        image = image.convert('L')
        image = np.array(image)
    if img_format == 1:
        im_size = (image_height, image_width)
    else:
        im_size = (image_width, image_height)
    image = cv2.resize(image, im_size, interpolation=cv2.INTER_CUBIC)

    # if 'MountainCar' in self.name:
    result = image
    if is_gray:
        result = result / 255
        # index = result == 1.
        result[result <= 0.8] = 0.
        result[result > 0.8] = 1.
        result = 1 - result
    if is_show:
        if 'CartPole' in name:
            save_dir = '/home/leac/DCK_data/CartPole_a/'
        elif 'MountainCar' in name:
            save_dir = '/home/leac/DCK_data/MountainCar_ai_h90_w90/'
        if is_gray:
            result1 = 1 - result
            plt.imshow(result1, cmap=plt.get_cmap('gray'))
            monochrome_image_show_and_save(result1, is_save=False, save_dir=save_dir + 'ref_0.jpg', is_show=False)
        else:
            plt.imshow(result)
        plt.show()

    if return_im is False:
        result = np.reshape(result, (1, image_width * image_height))
    elif return_im and not is_gray:
        result = result.transpose(2, 0, 1)
    return result


def monochrome_image_show_and_save(image0, is_show=False, is_save=False, save_dir=None):
    '''
    显示和保存黑白图像,将多帧图像并排成一张图像显示
    :param image: images matrix, shape = [height, width, image_num]
    :param is_show: the flag to display the image
    :param is_save: the flag to save the image
    :param save_dir: the dir to save the image. If is_save is True, save_dir should be given.
    :return: Nothing
    '''
    image = copy.deepcopy(image0)
    shape = np.shape(image)
    assert len(shape) == 2 or len(shape) == 3, 'the dim of the image should equal 2 or 3'
    if len(shape) == 2:
        image = image[:, :, np.newaxis]
    shape = np.shape(image)
    height, width, num = shape[0], shape[1], shape[2]
    im = np.zeros([height, width * num])
    for i in np.arange(num):
        im[:, i * width:(i + 1) * width] = image[:, :, i]
    if is_save:
        assert is_save is not None, 'If you want to save the image, the saving dir should be given.'
        plt.imsave(save_dir, im, cmap=plt.get_cmap('gray'))
    if is_show:
        plt.imshow(im, cmap=plt.get_cmap('gray'))
        plt.show()
    return im


def save_video(path: str, frame_list: list, fps: int = 30, is_print: bool = True):  # error
    """
    save the list of frames to a video
    :param path: path for saving the video
    :param frame_list: list of images, Gray or RGB images.
    :param fps: frames per second
    :return:
    """
    if False:
        from PIL import Image
        assert isinstance(frame_list, list), "the input must be list of image frame"
        suffix = os.path.splitext(path)[-1]
        if not "mp4" in suffix:
            path = os.path.join(path, '.mp4')
        width, height = frame_list[0].shape[0], frame_list[0].shape[1]
        video = cv2.VideoWriter(path, cv2.VideoWriter_fourcc('m', 'p', '4', 'v'), fps, (width, height))
        for i in range(len(frame_list)):
            image = np.array(frame_list[i], dtype=np.uint8)
            if np.ndim(image) == 2:
                image = gray2rgb(image).astype(np.uint8)
            video.write(image)
        video.release()
    else:
        import imageio
        if not frame_list[0].dtype == "uint8":
            for i in range(len(frame_list)):
                frame_list[i] = frame_list[i].astype(np.uint8)
        imageio.mimsave(path, frame_list, fps=fps, macro_block_size=None)
    if is_print:
        print("video has been saved to %s" % path)


def plot3_latent_state_sequence(sequence_list, label=None, is_show=False, save_path=None):
    """
    可视化潜在状态的evolution
    :param sequence_list: matrix list, each matrix denotes one episode of eovlution process
    :param label:
    :return:
    """
    if isinstance(sequence_list, np.ndarray):
        l_s = sequence_list
        l_s1 = None
    elif isinstance(sequence_list, list):
        num = len(sequence_list)
        assert num == 1 or num == 2
        l_s = sequence_list[0]
        if isinstance(l_s, torch.Tensor):
            l_s = l_s.data.cpu().numpy()
        l_s1 = None
        if num == 2:
            l_s1 = sequence_list[1]
        if isinstance(l_s1, torch.Tensor):
            l_s = l_s.data.cpu().numpy()

    font_size = 12
    dims = l_s.shape[1]
    steps = l_s.shape[0]
    dim = np.linspace(1, dims, dims)
    step = np.linspace(1, steps, steps)
    x_dim, y_step = np.meshgrid(dim, step)
    # plot
    fig = plt.figure(figsize=(10, 5))
    ax = fig.add_subplot(1, 3, 1, projection='3d')
    surf1 = ax.plot_surface(x_dim, y_step, l_s, rstride=1, cstride=1, cmap=plt.cm.Spectral, linewidth=0,
                            antialiased=False)
    ax.set_xlabel(label['mode'], fontsize=font_size)
    ax.set_ylabel('Step', fontsize=font_size)
    plt.title(label['title1'], fontsize=font_size)
    # fig.colorbar(surf1, shrink=0.8, aspect=20)
    cax1 = adjust_colorbar(fig, ax, width=0.01, pad=0.03, shrink=0.8)
    fig.colorbar(surf1, cax=cax1, ax=ax)

    if num == 2:
        ax2 = fig.add_subplot(1, 3, 2, projection='3d')
        surf2 = ax2.plot_surface(x_dim, y_step, l_s1, rstride=1, cstride=1, cmap=plt.cm.Spectral, linewidth=0,
                                 antialiased=False)
        plt.xlabel(label['mode'], fontsize=font_size)
        plt.ylabel('Step', fontsize=font_size)
        plt.title(label['title2'], fontsize=font_size)
        cax2 = adjust_colorbar(fig, ax2, width=0.01, pad=0.03, shrink=0.8)
        fig.colorbar(surf2, cax=cax2, ax=ax2)
        # cb = plt.colorbar(surf2, shrink=0.8, aspect=20)
        # cb.ax.tick_params(labelsize=10)

        ax3 = fig.add_subplot(1, 3, 3, projection='3d')
        surf3 = ax3.plot_surface(x_dim, y_step, l_s - l_s1, rstride=1, cstride=1, cmap=plt.cm.Spectral, linewidth=0,
                                 antialiased=False)
        plt.xlabel("Latent States", fontsize=font_size)
        plt.ylabel('Step', fontsize=font_size)
        plt.title("Error", fontsize=font_size)
        cax3 = adjust_colorbar(fig, ax3, width=0.01, pad=0.05, shrink=0.8)
        fig.colorbar(surf3, cax=cax3, ax=ax3)
        # cb = plt.colorbar(surf2, shrink=0.8, aspect=20)
        # cb.ax.tick_params(labelsize=10)

    plt.subplots_adjust(wspace=0.5, hspace=0.01)
    if is_show:
        plt.ion()
        plt.show()
    if save_path is not None:
        img_array = get_img_from_fig(fig)
        img = Image.fromarray(img_array)
        img.save(save_path)


def adjust_colorbar(fig, ax, width=0.01, pad=0.02, shrink=1.0):
    """
    用于调整图中colorbar 与图之间的间隔
    :param fig: 大图对象. e.g., `fig = plt.figure(figsize=(10, 5))` or `fig, ax = plt.subplots(figsize=(9, 9))`
    :param ax: 小图对象? ax = fig.add_subplot(1, 3, 1, projection='3d')
    :param width: colorbar 的宽度
    :param pad: colorbar 与图之间的间隔
    :param shrink: colorbar 的缩放尺度
    :return:
    """

    from mpl_toolkits.axes_grid1 import make_axes_locatable

    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad="5%")

    fig.canvas.draw()
    pos = ax.get_position()
    ydf = (1 - shrink) * (pos.ymax - pos.ymin) / 2
    cax.remove()

    return fig.add_axes([pos.xmax + pad, pos.ymin + ydf, width, (pos.ymax - pos.ymin) - 2 * ydf])


def rgb2gray(rgb: np.ndarray):
    """
    # convert rgb (224,224,3 ) to gray (224,224) image
    @param rgb: images array, the last dim is the images channel
    @return:
    """
    assert rgb.shape[-1] == 3
    return np.dot(rgb[..., :3], [0.299, 0.587, 0.114])  # 分别对应通道 R G B


# convert gray to rgb image
def gray2rgb(imggray: np.ndarray):
    """
    
    :param imggray:  (height, width)
    :return: 
    """
    if np.ndim(imggray) == 2:
        imggray = imggray[..., np.newaxis]
    rgb = np.concatenate((imggray, imggray, imggray), axis=2)
    # 原图 R G 通道不变，B 转换回彩图格式
    R = rgb[:, :, 0][..., np.newaxis]
    G = rgb[:, :, 1][..., np.newaxis]
    B = ((imggray) - 0.299 * R - 0.587 * G) / 0.114

    grayRgb = np.zeros((rgb.shape))
    grayRgb[:, :, 2] = B[:, :, 0]
    grayRgb[:, :, 0] = R[:, :, 0]
    grayRgb[:, :, 1] = G[:, :, 0]

    return grayRgb
