import pytorch_lightning as pl
from torch.utils.data import DataLoader
from Dataset import SoftRobotDataset


class SoftRobotDataModule(pl.LightningDataModule):

    def __init__(self, args, shuffle=True, num_workers=0): # the original is 0, I revise it as 4
        super().__init__()
        self.args = args
        self.train_file_num = args['train_file_num']
        self.train_file_path = args['train_data_path']
        self.val_file_num = args['val_file_num']
        self.val_file_path = args['val_data_path']
        self.test_file_num = args['test_file_num']
        self.test_file_path = args['test_data_path']
        self.conca, self.interval = args['conca_num'], args['interval']
        self.predicted_step = args['predicted_step']
        self.num_shifts = args['num_shifts']
        self.input_mode = args['input_mode']
        self.batch_size = args['batch_size']
        self.shuffle = shuffle
        self.num_works = num_workers

    def setup(self, stage: [str] = None):

        if stage == 'fit' or stage is None:
            self.train_dataset = SoftRobotDataset(self.args, self.train_file_path, self.train_file_num, self.num_shifts,
                                                        self.conca, self.interval, which_data='train', input_mode=self.input_mode)
            self.val_dataset = SoftRobotDataset(self.args, self.val_file_path, self.val_file_num, self.predicted_step, self.conca,
                                                      self.interval, which_data='val', input_mode=self.input_mode)

        if stage == 'test' or stage is None: 
            test_args = self.args
            test_args['interval'] = self.args['predicted_step']
            if "Xms" not in self.args['domain_name']:
                test_args['middle_interval'] = self.args['predicted_step'] - 1
            self.test_dataset = SoftRobotDataset(test_args, self.test_file_path, self.test_file_num, self.predicted_step,
                                                       self.conca, self.interval, which_data='test', input_mode=self.input_mode)

    def train_dataloader(self) -> DataLoader:
        return DataLoader(dataset=self.train_dataset, batch_size=self.batch_size, shuffle=self.shuffle, num_workers=self.num_works)

    def val_dataloader(self) -> DataLoader:
        return DataLoader(dataset=self.val_dataset, batch_size=self.batch_size, shuffle=False, num_workers=self.num_works)

    def test_dataloader(self) -> DataLoader:
        return DataLoader(dataset=self.test_dataset, batch_size=self.batch_size, shuffle=False, num_workers=self.num_works)
