#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import socket

hostname = socket.gethostname()
GPUS = '0'
if 'buduo' in hostname.lower() or 'shaw' in hostname:
    GPUS = '0'
elif 'nudt302' in hostname.lower():
    GPUS = '3'
elif 't640' in hostname.lower():
    GPUS = '2'
import os

os.environ['CUDA_VISIBLE_DEVICES'] = GPUS
print("---------------- GPUS: ", GPUS)
import argparse
import numpy as np
import os
import time
import sys
import torch
from torch import nn
import pytorch_lightning as pl

np.set_printoptions(suppress=True)
code_name = os.path.basename(sys.argv[0])


def loss_weight(a, b, c, steps):
    reced_w = [(1 + np.tanh(a * w) * b) * c for w in np.arange(steps + 1)]
    return reced_w


def get_softrobot_args(is_debug=False, is_mkdir=True):
    '''
    This function is used to define parameters including data path, setting of encorder and decoder NN, 
    '''
    parser = argparse.ArgumentParser()  # args = parser.parse_args()

    # ------------------------------ environment --------------------
    sys_interval = 50
    version = 'soft_robot'
    domain_name = version + '_%d' % sys_interval  # SoftRobot_50
    parser.add_argument('--domain_name', type=str, default=domain_name, help='the name of the system')  # SoftRobot_50
    s_dim, u_dim = 12, 4
    conca_num = 0
    state_name = ['x', 'y', 'z', 'theta1', 'theta2', 'theta3', 'vx', 'vy', 'vz', 'dtheta1', 'dtheta2', 'dtheta3']
    parser.add_argument('--s_dim', type=int, default=s_dim, help='the dim of the state of the forced dynamics')
    parser.add_argument('--u_dim', type=int, default=u_dim, help='the dim of the action of the forced dynamics')
    parser.add_argument('--state_name', type=list, default=state_name, help='the name of each state')
    action_name = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8']
    parser.add_argument('--action_name', type=list, default=action_name, help='the name of each action')
    # -------------- for data process -------------------------------------------
    parser.add_argument('--conca_num', type=int, default=conca_num,
                        help='concatenate conca_num states to one input') 
    parser.add_argument('--interval', type=int, default=4,
                        help='sample intervals when sampling data from train dataset')  # TODO
    parser.add_argument('--train_file_num', type=int, default=561, help='the num of train dataset file')  # TODO
    parser.add_argument('--test_file_num', type=int, default=0, help='the num of test dataset file')  # # TODO
    parser.add_argument('--val_file_num', type=int, default=39, help='the num of val dataset file')  # # TODO
    state_bound = np.array([[-0.00879201412200928,	0.170363464355469,	0.0225633468627930,	-0.738277655808186,	-0.302795423829557,	-1.07303653877796,	-0.298369483947754,	-0.0687980651855469,	-0.234121589660645,	-2.57014003570657,	-0.923538284898784,	-3.65200378836516],
                            [0.124927337646484,	0.237662933349609,	0.141864334106445,	0.995231288845882,	0.279599889946212,	0.761269591026194,	0.334707660675049,	0.103577575683594,	0.263511123657227,	3.19393175849312,	0.960900063114750,	3.14161512401149]])
    parser.add_argument('--state_bound', type=list, default=state_bound, help='the bound of each    states')
    parser.add_argument('--data_len', type=int, default=100, help='param for sampling data from dataset')
    parser.add_argument('--middle_interval', type=int, default=13, help='interval of episodes')

    # ---------------------- construction ------------------------
    input_mode = 22
    parser.add_argument('--input_mode', type=int, default=input_mode,
                        help='the mode decide whether to use image as input')
    lift_dim = 12
    koopman_mode = 1  #
    latent_mode = 2  #
    BMatrix_mode = 1  #
    koopman_lam = 10  # 1.5  10
    T_eig_lam = 0.0  #
    A_eig_lam = 0.003  # 0.003  0.01
    svd_lam = 0.003  # 0.003
    recon_lam_C = 1  # 1.0
    pred_lam_C = 1  #
    num_shifts = 50  #
    num_koopman_shifts = num_shifts
    predicted_step = num_shifts
    parser.add_argument('--latent_mode', type=int, default=latent_mode, help='1:only encoder, 2: resNet style')
    ## three hidden layer the original setting
    if latent_mode == 2:
        encoder_widths = [(conca_num + 1) * s_dim, 64, 128, 64,
                          lift_dim]  # this kind of setting make sure that either latend_mode = 1 or 2, the dimension of lifted state is always as lift_dim + s_dim
    else:
        encoder_widths = [(conca_num + 1) * s_dim, 64, 128, 64, lift_dim + s_dim]  # only encoder case
    eact_type = ['relu', 'relu', 'relu', '']
    parser.add_argument('--encoder_widths', default=encoder_widths, help='the fc layers info')
    ## three hidden layer # the original setting
    decoder_widths = [lift_dim + s_dim, 128, 64, 64, s_dim]
    dact_type = ['relu', 'relu', 'relu', '']
    parser.add_argument('--decoder_widths', type=list, default=decoder_widths,
                        help='the construction of the auto-encoder')
    is_last_bias = False if len(decoder_widths) == 2 else True
    parser.add_argument('--is_last_bias', type=bool, default=is_last_bias, help='decoder 最后一层是否加 bias')
    parser.add_argument('--lift_dim', type=int, default=lift_dim, help='the lifted dim')
    parser.add_argument('--scale', type=float, default=0.1, help='scale for initializing weights')
    if (not len(eact_type) == len(encoder_widths) - 1) or (not len(dact_type) == len(decoder_widths) - 1):
        raise Exception('the length of eact_type or dact_type is wrong')
    parser.add_argument('--eact_type', type=list, default=eact_type, help='the type of activation')
    parser.add_argument('--dact_type', type=list, default=dact_type, help='the type of activation')

    # ------------------------ loss function ------------
    is_predict = False  # True # True : Testing  #False: Training
    parser.add_argument('--is_predict', type=bool, default=is_predict, help='the flag of running model')
    parser.add_argument('--num_shifts', type=int, default=num_shifts,
                        help='the steps for calculating the predicted loss')
    parser.add_argument('--num_koopman_shifts', type=int, default=num_koopman_shifts,
                        help='the steps for koopman operator')
    # The weight of the loss is calculated for each state, which is set according to the training situation
    state_weight = np.ones([1, s_dim]) * 1
    # state_weight = np.array([[5, 5, 1, 1, 1, 1]])
    parser.add_argument('--state_weight', type=list, default=state_weight,
                        help='the weight of each state to calculate reconstruction loss and multi-steps prediction loss')
    c_linear = [1, 1, 1]
    reced_linear = loss_weight(c_linear[0], c_linear[1], c_linear[2], num_shifts)
    parser.add_argument('--c_linear', type=float, default=c_linear, help='weight for multi-step prediction loss')
    parser.add_argument('--reced_linear', type=float, default=reced_linear,
                        help='coefficients of loss weight for multi-step loss')
    parser.add_argument('--predicted_step', type=int, default=predicted_step, help='the num of the predicted step')
    parser.add_argument('--koopman_lam', type=float, default=koopman_lam,
                        help='the coefficient of koopman linear loss')  # improtant hyperparameter for the cost function
    parser.add_argument('--T_eig_lam', type=float, default=T_eig_lam,
                        help='weight of eigenvalues of T matrix')  # improtant hyperparameter for the cost function
    parser.add_argument('--A_eig_lam', type=float, default=A_eig_lam,
                        help='weight of eigenvalues of A matrix')  # improtant hyperparameter for the cost function
    parser.add_argument('--svd_lam', type=float, default=svd_lam,
                        help='weight of singular value of controllability matrix')  # improtant hyperparameter for the cost function
    parser.add_argument('--opt_alg', type=str, default='adam', help='optimizer')
    parser.add_argument('--batch_size', type=int, default=4096, help='the size of each batch')  # 2048
    parser.add_argument('--learning_rate', type=float, default=0.0003, help='learning rate')
    parser.add_argument('--dropout_rate', type=float, default=1., help='keep prob')
    parser.add_argument('--recon_lam_C', type=float, default=recon_lam_C,
                        help='the coefficient of reconstruction loss')  # improtant hyperparameter for the cost function
    parser.add_argument('--pred_lam_C', type=float, default=pred_lam_C,
                        help='weight of multi-step reconstruction')  # improtant hyperparameter for the cost function

    parser.add_argument('--koopman_mode', type=int, default=koopman_mode,
                        help="1: time-invariant-eigenvalues, 2: transition matrix, "
                             "3: time-variant-eigenvalues(each complex conjugate pair has a NN), "
                             "4: time-variant-eigenvalues based on whole NN, ")
    parser.add_argument('--num_real', type=int, default=int(np.mod(lift_dim + s_dim, 2)),
                        help='num of real eigenvalues')
    parser.add_argument('--num_complex_pair', type=int, default=int((lift_dim + s_dim) / 2),
                        help='num of complex conjugate pairs')

    parser.add_argument('--BMatrix_mode', type=int, default=BMatrix_mode,
                        help='The way to construct the input matrix:'
                             '1: LTI dynamics with a constant B;'
                             '2: Bilinear dynamics with u_dim constant B(space_dim, u_dim x space_dim);')
    parser.add_argument('--code_name', type=str, default=code_name, help='the file name of the main .py')

    #################################### -------------- path ---------------------###########################################
    cur_path = os.path.split(os.getcwd())[0]
    base_path = cur_path
    date = time.strftime("%Y_%m_%d_%H_%M", time.localtime())
    debug_str = "_Debug" if is_debug else ""
    path = base_path + 'SoftRobot_' + str(date) + debug_str
    # # Home/leac/SoftRobot/SoftRobot/1_model_50/SoftRobot_2023_9_20_9_33
    parser.add_argument('--path', type=str, default=path)
    if (not os.path.exists(path)) and (not is_predict) and not is_debug:
        os.makedirs(path)
    parser.add_argument('--log_dir', type=str, default=os.path.join(path, 'logdir'), help='for saving tensorboard log')
    parser.add_argument('--image_path', type=str, default=path + '/logdir/train/%s_%d_psteps_%d_gstep.png',
                        help='the path for saving the predicted picture result')
    """
    This is an important setting for the code.
    """
    data_path = os.path.join(base_path, 'data_dyn/')
    parser.add_argument('--train_data_path', type=str,
                        default=data_path + 'soft_robot' + '_%d.mat', help='the path of the training data')
    parser.add_argument('--test_data_path', type=str,
                        default=data_path + 'soft_robot' + '_test_%d.mat', help='the path of testing data')
    parser.add_argument('--val_data_path', type=str, default=data_path + 'soft_robot' + '_test_%d.mat',
                        help=' use test data for validation')
    parser.add_argument('--host_device', type=str, default=hostname + ":%s" % GPUS, help='host and gpu')

    if is_predict:  # if true, then conduct testing, then load the trained model for testing.
        restore_model_path = base_path + '%d_model_%d/' % (
            koopman_mode, sys_interval) + 'SoftRobot_2024_07_12_13_06/logdir/epoch=1619-train_loss=0.44099.ckpt'
        model_path = path
    else:
        restore_model_path = base_path + '%d_model_%d/' % (
            koopman_mode, sys_interval) + 'SoftRobot_2024_07_12_08_40/logdir/last.ckpt'
        model_path = path

        print(
            'If you want to use the previously trained modle as training starting, please change the restore_model_path')

    args_file_path = model_path + '/args.pkl' 
    test_image_path = model_path + '/logdir/test/'
    matlab_file_path = model_path + '/params_for_matlab.mat'
    if not os.path.exists(test_image_path) and is_mkdir:
        os.makedirs(test_image_path)
    parser.add_argument('--restore_model_path', type=str, default=restore_model_path, help='the path of trained model')
    parser.add_argument('--args_file_path', type=str, default=args_file_path, help='save dict args for restore')
    parser.add_argument('--matlab_file_path', type=str, default=matlab_file_path, help='for matlab prediction')
    parser.add_argument('--test_image_path', type=str, default=test_image_path + str(date) + '_bIdx_%d_%d.png',
                        help='the path for saving the testing images')
    args = parser.parse_args()
    return args

# Initialize Policy weights
def weights_init_(m):
    if isinstance(m,
                  nn.Linear):  # if the module m is an instance of nn.Linear, the weight and bias of this module are initialized.
        # torch.nn.init.xavier_uniform_(m.weight, gain=1)
        torch.nn.init.normal_(m.weight, 0., 0.1)  # a mean of 0 and a standard deviation of 0.1
        if m.bias is True:
            torch.nn.init.constant_(m.bias, 0)

class MLP(pl.LightningModule):
    def __init__(self, widths, act_type, is_variational=False,
                 is_last_bias=True):  # we use a variational NN that includes elements for modeling uncertainity.
        """
        :param widths:
        :param act_type:
        :param is_variational:
        :param is_last_bias:  bias for last layer or not
        """
        super(MLP, self).__init__()
        self.is_variational = is_variational
        if self.is_variational:
            # mean and std
            widths[-1] = widths[
                             -1] * 2  # the last layer's width is doubled, typically to accommodate both mean and standard deviation values.
        self.act_type = act_type
        self.widths = widths
        fc_layers = []  # a list containing the layers that we want to stack in the NN.
        for i in np.arange(len(self.widths) - 1):
            is_bias = True if i < len(self.widths) - 2 else is_last_bias

            # original
            # fc_layers.append(nn.Linear(self.widths[i], self.widths[i + 1], bias=is_bias))
            # new
            linear_layer = nn.Linear(self.widths[i], self.widths[i + 1], bias=is_bias)
            linear_layer.weight.requires_grad = True  # Set requires_grad to False for weight no updata
            linear_layer.bias.requires_grad = True  # Set requires_grad to False for bias no updata
            # fc_layers.append(linear_layer)
            fc_layers.append(nn.utils.spectral_norm(linear_layer))

            act_op = activation(self.act_type[i])
            if act_op is not None:
                fc_layers.append(act_op)
        self.fc_net = nn.Sequential(*fc_layers)  # creating a fully connected NN; * unpack the element of fc_layer
        self.apply(weights_init_)

    def reparameterize(self, mu, std):
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x, use_repa=False):
        x = self.fc_net(x)
        if self.is_variational:
            x, log_std = torch.chunk(x, 2,
                                     dim=-1)  # split a tensor x into two equal parts along a specified dimension (dim=-1).
            std = torch.minimum(log_std.exp(), torch.ones_like(log_std) * 10)
            if use_repa:
                x = self.reparameterize(x, std)
        return x


class KoopmanNet(pl.LightningModule):

    def __init__(self, input_mode, lift_dim, u_dim, s_dim=None, koopman_mode=1, num_real=0, num_complex_pair=0,
                 args=None):
        """

        :param input_mode: first flag, 1: image, 2: vector; second flag, 1: autonomous systems, 2: forced systems
        :param lift_dim:
        :param u_dim:
        :param s_dim:
        :param koopman_mode: 1: learns eigenvalues directly (num_real real eigenvalues, and num_complex_pair complex conjugate pairs);
                             2: learns the latent state transition matrix.
        :param num_real:
        :param num_complex_pair:
        """
        super(KoopmanNet, self).__init__()
        if input_mode > 20 and s_dim is None:
            raise Exception("When the input is not images, the s_dim (dim of the state) should be given !!!")
        self.s_dim = s_dim
        self.input_mode = input_mode
        self.koopman_mode = koopman_mode
        self.lift_dim = lift_dim
        self.u_dim = u_dim
        self.num_real = num_real
        self.num_complex_pair = num_complex_pair
        if input_mode < 20:
            self.space_dim = self.lift_dim
        else:
            self.space_dim = self.lift_dim + self.s_dim
        # matrix A
        if koopman_mode == 1:  # learn time-invariant-eigenvalues, it just has self.space_dim  eigenvalues.
            init_A = torch.squeeze(torch.normal(0., 0.01, size=(1, self.space_dim)))
            self.A = nn.Parameter(init_A,
                                  requires_grad=True)  # initialize the weight matrix self.A as a trainable parameter
        elif koopman_mode == 2:
            w = torch.Tensor(self.space_dim, self.space_dim)
            w = torch.nn.init.normal_(w, 0, 0.01)
            self.A = nn.Parameter(w, requires_grad=True)
        # matrix B
        if np.mod(self.input_mode, 2) == 0 or u_dim is not None:
            wb = torch.Tensor(u_dim, self.space_dim)
            wb = torch.nn.init.normal_(wb, 0, 0.1)
            self.B = nn.Parameter(wb, requires_grad=True)
        # matrix T
        self.T = torch.diag(torch.ones(s_dim))


    def form_A_from_eigenvalues(self):
        """
        for time-invariant systems
        """
        assert self.space_dim == self.num_real + 2 * self.num_complex_pair, "the sum of all eigenvalues must equal the space_dim"
        idx = 0
        temp_A = torch.zeros([self.space_dim, self.space_dim])
        for i in range(self.num_complex_pair):
            idx = 2 * i
            temp_A[idx:idx + 2, idx:idx + 2] = form_complex_conjugate_block(self.A[idx],
                                                                            self.A[idx + 1])  # temp_A[0:2, 0:2]
        for i in range(self.num_real):
            idx = 2 * self.num_complex_pair + i
            temp_A[idx, idx] = self.A[idx]
        return temp_A.to(self.device)  # move the tensor temp_A to a specific device,

    def forward(self, phi: torch.Tensor, u=None, is_restruct_A=False):
        """
        :param phi: (batch_size, space_dim)
        :param u: (batch_size, u_dim)
        :param is_restruct_A: it works only when self.koopman_mode_nums[0] equals 3 or 4.
                True: restructure A; False: use the last saved A (self.A)
        :return:
        """
        batch_size = list(phi.size())[0]
        if self.koopman_mode == 1:
            phi = torch.matmul(phi, self.form_A_from_eigenvalues())
        elif self.koopman_mode == 2:
            phi = torch.mm(phi, self.A)
        if np.mod(self.input_mode, 2) == 0 or u is not None:
            Bu = torch.mm(u, self.B)
            phi = phi + Bu
        return phi


def form_complex_conjugate_block(real, imaginary):
    """
    structure the block for system: x(k+1) = Ax(k)
    :param real:
    :param imaginary:
    :return:
    """
    if real.size() == torch.Size([]):  # for time-invariant cases
        block = torch.zeros([2, 2])
        block[0, 0] = real
        block[0, 1] = imaginary
        block[1, 0] = -imaginary
        block[1, 1] = real
    elif list(real.size())[0] >= 1:  # for time-variant situations
        batch_size = list(real.size())[0]
        block = torch.zeros([batch_size, 2, 2])
        # print(block[:, 0, 0].size())
        block[:, 0, 0] = real
        block[:, 0, 1] = imaginary
        block[:, 1, 0] = -imaginary
        block[:, 1, 1] = real
    return block


def activation(act=''):
    if act.lower() == 'sigmoid':
        return nn.Sigmoid()
    elif act.lower() == 'relu':
        return nn.ReLU()
    elif act.lower() == 'elu':
        return nn.ELU()
    elif act.lower() == 'tanh':
        return nn.Tanh()
    elif act.lower() == 'lrelu' or act.lower() == 'leaky_relu':
        return nn.LeakyReLU()
    elif act.lower() == 'sin':
        return Sin()
    elif act.lower() == 'cos':
        return Cos()
    elif act.lower() == 'softmax':
        return nn.Softmax()
    elif act == '' or act == 'None' or act is None:
        return None


class Sin(nn.Module):
    """
    Customize sin activation
    """

    def forward(self, input):
        return torch.sin(input)


class Cos(nn.Module):
    """
    Customize cos activation
    """

    def forward(self, input):
        return torch.cos(input)
