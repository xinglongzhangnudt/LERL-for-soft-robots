
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.utils.data.dataset import Dataset
from CommonUtils import  read_mat_as_dict
import CommonUtils as comUitls
import os
import time
import copy
import CommonUtils as ComU
# import matplotlib.pyplot as plt
from tqdm import tqdm


class SoftRobotDataset(Dataset):

    def __init__(self, args, file_path, file_num, steps, conca, interval, which_data, input_mode=22):
        self.args = args
        self.cur_file_index = 0
        self.file_path = file_path
        self.file_num = file_num
        self.interval = interval
        self.which_data = which_data
        self.conca = conca
        self.input_mode = input_mode
        self.data_len = args['data_len']
        self.middle_interval = args['middle_interval']

        self.sample_interval = ComU.getValueIfExistElseDefault(args, 'sample_interval', 1) # the default vaue is 1
        self.steps = (steps + 1) * self.sample_interval # steps = 80 according to the hyperparameter setting.
        self.num_shifts = steps + 1
        self.load_dataset()

    def load_dataset(self):
        print("************ loading %s dataset **************" % self.which_data)
        self.state_tensor, self.u_tensor = [], []
        for i in tqdm(range(self.file_num)):
            self.read_file(i)
        self.state_tensor = ComU.list2array(self.state_tensor, 1)
        self.u_tensor = ComU.list2array(self.u_tensor, 1)
        self.length = self.state_tensor.shape[1]
        if True:
            shape = self.state_tensor.shape
            states = np.reshape(self.state_tensor, (shape[0] * shape[1], shape[-1]))
        print("******* loading complete ,  %d sequences ***********" % self.length)

    def get_data(self, index):  
        return self.state_tensor[:, index, :], self.u_tensor[:, index, :] # why not self.u_tensor[:, index] ???


    def read_file(self, file_index): 
        temp_path = self.file_path % file_index # read the file named as "SoftRobot_0.mat" and "SoftRobot_1.mat"
        data_dict = read_mat_as_dict(temp_path)
        state_tensor, u_tensor = self.softrobot_data_process_batch(data_dict, self.steps, self.conca)
        self.state_tensor.append(state_tensor)
        self.u_tensor.append(u_tensor)
    
    
    def __getitem__(self, item):
        return self.get_data(item)

    def __len__(self):
        return self.length

    def softrobot_data_process_batch(self, data, num_shifts, conca):
        states, u = data['X'], data['U']  # states, u denotes velocities and actions(steering and acc)
        start = 0
        end = start + self.data_len # the value of  self.data_len is 100
        state_list = []
        u_list = []
        len_time=len(states) # 50000
        while (end < len_time): # sample 100 data in the internval as 13; e.g., 0-99; 13-112; 26-125; ....,   49901-50000
            temp_state = copy.copy(states[start:end, :])
            state_list.append(temp_state) # add an array to a list
            temp_u = copy.copy(u[start:end, :][conca:, :])
            ''''
            first slices the u array from rows start to end-1 (inclusive) and all columns :. 
            This is similar to what was done with states in the first line.
            Next it further slices the result by excluding the first conca rows and keeping all columns. This effectively skips the first conca rows in the sliced array.
            '''
            u_list.append(temp_u)
            start += self.middle_interval # the value of self.middle_interval is 13
            end = start + self.data_len # the values of start and end changes every loop.
        batch_state = comUitls.list2array(state_list, 0, add_dim=True)
        batch_u = comUitls.list2array(u_list, 0, add_dim=True)
        batch_state = self.stack_data_batch(batch_state, num_shifts, self.data_len, conca, self.interval) ## is this setp necessary for the first version?
        batch_u = self.stack_data_batch(batch_u, num_shifts - 1, self.data_len - conca - 1, 0, self.interval)
        batch_state = batch_state.transpose(1, 0, 2, 3)  # transpose [bs, len_each_train, num_data_each_traj, s_dim * (conca + 1)] as [len_each_train, bs, num_data_each_traj, s_dim * (conca + 1)]
        batch_u = batch_u.transpose(1, 0, 2, 3)
        batch_state = np.reshape(batch_state, (batch_state.shape[0], batch_state.shape[2] * batch_state.shape[1], batch_state.shape[-1]))
        batch_u = np.reshape(batch_u, (batch_u.shape[0], batch_u.shape[2] * batch_u.shape[1], batch_u.shape[-1]))
        return batch_state, batch_u 

    def stack_data_batch(self, data, num_shifts, len_time, conca, interval=1): # if the value of interval is not provided, its value is 1; we set its value as 4.
        bs = data.shape[0] # batch size
        n = data.shape[-1] # number of feature
        len_each_train = num_shifts + 1
        num_data_each_traj = int(np.floor((len_time - conca - len_each_train) / interval)) + 1
        spare_num = int(np.mod(len_time - conca - len_each_train, interval))
        try:
            data_tensor = np.zeros([bs, len_each_train, num_data_each_traj, n * (conca + 1)])
        except:                                                                               
            print(len_each_train)
        if conca > 0:
            temp_tensor = np.zeros([bs, len_time - conca, n * (conca + 1)]) # #  a 3D array with dimensions [bs, len_time - conca, n * (conca + 1)]
            for k in np.arange(len_time - conca):
                for h in np.arange(conca + 1): # for conca =1,  np.arange(conca + 1) is  array([0, 1])
                    temp_tensor[:, k, n * h:n*(h + 1)] = data[:, k + h, :]
        else:
            temp_tensor = data
        if spare_num > 0:
            init_index = np.random.randint(0, spare_num)
        else:
            init_index = 0
        for j in np.arange(num_data_each_traj):
            data_tensor_range = np.arange(j * interval + init_index, j * interval + init_index + len_each_train)
            data_tensor[:, :, j, :] = temp_tensor[:, data_tensor_range, :]
        return data_tensor