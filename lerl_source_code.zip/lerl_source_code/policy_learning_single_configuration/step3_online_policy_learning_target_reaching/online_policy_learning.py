"""
The learned A is contructed from eigenvalues
"""
import argparse
from pprint import pprint
import numpy as np
# from scipy.linalg import matrix_rank
import scipy.io as scio
import control
import torch
import sys
sys.path.append("code/E_s_2/step1_koopman_embedding_training")
sys.path.append("code/E_s_2/step2_feedforward_policy_training")
from koopman_embedding_training import DeepEDMD
from feedforward_policy_training import Network as U_net
import pickle
import matplotlib

matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import math
import os
import numpy as np
import scipy.io
import time
import LuMoSDKClient
import serial
import struct


class LQR:
    def __init__(self, A, B, Q, R, space_dim):
        self.A = A  # 12*1 # just eigenvalue
        self.B = B  # 24*8
        self.Q = Q
        self.R = R

    def lqr(self):
        K, S, E = control.dlqr(self.A, self.B, self.Q,
                               self.R)  # K (2D array (or matrix)) – State feedback gains;K (2D array (or matrix)) – State feedback gains;E (1D array) – Eigenvalues of the closed loop system
        print('K', K.shape)
        return K


def form_A_from_eigenvalues(space_dim, num_real, num_complex_pair, A):
    idx = 0
    temp_A = np.zeros([space_dim, space_dim])
    for i in range(num_complex_pair):
        idx = 2 * i
        temp_A[idx:idx + 2, idx:idx + 2] = form_complex_conjugate_block(A[idx], A[idx + 1])
    for i in range(num_real):
        idx = 2 * num_complex_pair + i
        temp_A[idx, idx] = A[idx]
    return temp_A


def form_complex_conjugate_block(real, imaginary):
    block = np.zeros([2, 2])
    block[0, 0] = real
    block[0, 1] = imaginary
    block[1, 0] = -imaginary
    block[1, 1] = real
    return block


def is_controllable(A, B):
    n = A.shape[0]
    m = B.shape[1]
    controllability_matrix = np.zeros((n, n * m))
    for i in range(n):
        temp = np.linalg.matrix_power(A, i) @ B
        controllability_matrix[:, i * m:(i + 1) * m] = np.linalg.matrix_power(A, i + 1) @ B
    rank = np.linalg.matrix_rank(controllability_matrix)
    if rank == n:
        return True
    else:
        return False


def normalization_state(original_data, min_vals, max_vals):
    num_rows = original_data.shape[0]
    normalized_data = np.zeros_like(original_data)
    for i in range(num_rows):
        normalized_data[i, :] = 2 * (original_data[i, :] - min_vals[i]) / (max_vals[i] - min_vals[i]) - 1
    return normalized_data


def vec_z(a):  # vectorize vector for iteration
    size_a = a.shape[0]
    newsize = int(size_a * (size_a + 1) / 2)
    v = np.zeros(newsize)
    n = 0
    for i in range(size_a):
        for j in range(size_a):
            if j >= i:
                v[n] = a[i] * a[j]
                n = n + 1
    return v.reshape(-1, 1)


def vec_H(A):  # vectorize H matrix for iteration
    size_A = A.shape[0]
    newsize = int(size_A * (size_A + 1) / 2)
    a = np.zeros(newsize)
    # print(a.shape)
    n = 0
    for i in range(size_A):
        for j in range(size_A):
            if j >= i:
                if i == j:
                    a[n] = A[i, j]
                else:
                    a[n] = 2 * A[i, j]
                n = n + 1
    return a.reshape(-1, 1)


def vec_H_inv(a):  # recover H matrix
    a_size = a.shape[0]
    p = np.poly1d([0.5, 0.5, -a_size])
    r = np.roots(p)
    X = np.max(r)
    if X - int(X) > 0.5:
        A_size = math.ceil(X)
    else:
        A_size = int(X)
    A = np.zeros((A_size, A_size))
    n = 0
    for i in range(A_size):
        for j in range(A_size):
            if j >= i:
                if i == j:
                    A[i, j] = a[n]
                else:
                    A[i, j] = a[n] / 2
                n = n + 1
    A = A + A.T - np.diag(np.diag(A))
    return A


def value_iteration(Z, n, m, N, L, H_vec, Q, R, Kn, K):  # in lifted space
    # Z data matrix
    # n number of states
    # m number of inputs
    # N number of measurements
    # L size of z-vector
    # K policy at current update step
    # Q state cost matrix
    # R input cost matrix
    phi = np.zeros((L, N - 1))
    upsilon = np.zeros((N - 1, 1))
    for k in range(N - 1):
        z_k = vec_z(Z[:, k])
        phi[:, k] = z_k
        e_k_1 = Z[0:n, k + 1]
        delta_u_k_1 = -np.dot(K, e_k_1)
        z_k_1 = vec_z(np.concatenate((e_k_1, delta_u_k_1)))
        e_k = Z[0:n, k]
        delta_u_k = Z[n + 1:n + m, k]
        upsilon[k] = np.dot(np.dot(e_k.T, Q), e_k) + np.dot(np.dot(delta_u_k.T, R), delta_u_k) + np.dot(H_vec.T, z_k_1)
    return phi, upsilon


def estimate_policy(phi, upsilon, nr, mr, L, Pk, H_vec):
    Y_vec = phi[:, -1].reshape(-1, 1)
    d = upsilon[-1]
    denomi = 1 + np.dot(Y_vec.T, np.dot(Pk, Y_vec))
    Hnume = np.dot(Pk, np.dot(Y_vec, (d - np.dot(Y_vec.T, H_vec))))
    Pnume = np.dot(Pk, np.dot(Y_vec, np.dot(Y_vec.T, Pk)))
    H_vec = H_vec + Hnume / float(denomi)
    Pk = Pk - Pnume / float(denomi)
    H = vec_H_inv(H_vec)
    return H, H_vec, Pk


def plot_unit_circle(A):
    eigenvalues, _ = np.linalg.eig(A)
    unit_circle = plt.Circle((0, 0), 1, color='k', fill=False)
    plt.gca().add_patch(unit_circle)
    for eigenvalue in eigenvalues:
        plt.plot(np.real(eigenvalue), np.imag(eigenvalue), 'ro')
    plt.xlim(-1.5, 1.5)
    plt.ylim(-1.5, 1.5)
    plt.grid(True)
    plt.show()


def predict_u(state_des, net_control, u_dim):
    state_des = state_des[:3, :]
    min_vals = np.array([-1., -1., -1., -1.,  -0.09018456,  0.19415233, -0.04809676])
    max_vals = np.array([1., 1., 1., 1., 0.18222795, 0.32334036, 0.20486685])
    state_des_normalized = normalization_state(state_des, min_vals[u_dim:], max_vals[u_dim:]).T
    control0_hat = net_control.encode_net(torch.from_numpy(state_des_normalized).float()).detach().numpy()
    return control0_hat

# load feedforward_network
model_path = "policy_learning_single_configuration/step2_feedforward_policy_training/feedforward_policy_es1.pth"
dicts_control = torch.load(model_path, map_location=torch.device('cpu'))
state_dict_control = dicts_control["model"]
Elayer_control = dicts_control["layer"]
net_control = U_net(Elayer_control)
net_control.load_state_dict(state_dict_control)
print(net_control)

with open('policy_learning_single_configuration/step1_koopman_embedding_training/pretrained_koopman_embedding/args.pkl', 'rb') as f:
    args_dict = pickle.load(f)
args = argparse.Namespace(**args_dict)
args = vars(args)
dck = DeepEDMD.load_from_checkpoint(checkpoint_path='policy_learning_single_configuration/step1_koopman_embedding_training/pretrained_koopman_embedding/epoch=1759-train_loss=0.08255.ckpt', save_params=False, args=args)
koopman_net = dck.koopman_net
koopman_net.eval()
encoder = dck.encoder_net
encoder.eval()
A = koopman_net.A.detach().numpy()
B = koopman_net.B.detach().numpy()
T = koopman_net.T.detach().numpy().T  # 12*12

n_x = 12
n_u = 4
n_lift = 12
space_dim = n_x + n_lift
m = n_u
ny = 6
nr = space_dim + ny
mr = m
t_s = 0.02  # 0.01 0.03
sim_step = 1500  # 3000
n_learning_step = 1500
n_explore_step = 0 # 1000
learning_rate = 0.003  # 0.0005
z_size = nr + m  # Number of states in z-vector
L = int(z_size * (z_size + 1) / 2)  # /Size of vectorized z
N = L + 5  # 1* L  Number of measurements before evaluation % 10* L;
# K =  zeros(m, n) # the starting point of the learning process
beta = 0.1  # parameter for RLS
Pk = beta * np.eye(L)  # parameter for RLS
gamma = 0.98  # 0.95

Q_temp_1 = 1 * np.array([[1, 1, 1]])  # 2.5
Q_temp_2 = 1 * np.ones((1, 3))  # 2.5
Q_temp_3 = 1 * np.ones((1, 6)) # 2.5
Q_temp_4 = 1 * np.ones((1, 12)) # 2.5
Q_temp_5 = 2 * np.array([[2, 2, 2, 1, 1, 1]]) # 0.2
# Q_temp = np.concatenate((Q_temp_1, Q_temp_2, Q_temp_3, Q_temp_4), axis=1)
Q_temp = np.concatenate((Q_temp_1, Q_temp_2, Q_temp_3, Q_temp_4, Q_temp_5), axis=1)
# print('Q_temp',Q_temp)
Q = np.diag(Q_temp.flatten())
R = (3 * np.eye(4, 4))  # 20

num_real = int(np.mod(space_dim, 2))
num_complex_pair = int(space_dim / 2)
temp_A = form_A_from_eigenvalues(space_dim, num_real, num_complex_pair, A)
C_f = np.concatenate((np.linalg.inv(T), np.zeros((12, 12))), axis=1)
C = C_f[0:ny, :]
print(C.shape)
print(temp_A.shape)
At = np.block([
    [temp_A.T, np.zeros((temp_A.shape[0], ny))],
    [t_s * C, np.eye(ny)]
])
tb = B.T
Bt = np.concatenate((B.T, np.zeros((ny, n_u))))
controller = LQR(At, Bt, Q, R, space_dim=space_dim)
q = np.zeros((ny, 1))
Gm = np.block([
    [Q, np.zeros((Q.shape[0], R.shape[0]))],
    [np.zeros((R.shape[0], Q.shape[0])), R]
])  # 29*29
H1 = 10 * np.eye(nr + m)  # 29*29
H1yy = H1[nr:nr + mr, nr:nr + mr]  # 2*2
H1yx = H1[nr:nr + mr, 0:nr]  # 2*27
L1 = -np.dot(np.linalg.inv(H1yy), H1yx)  # 2*27
for i in range(8000):
    T12 = np.concatenate((At, Bt), axis=1)  # 27*29
    T34 = np.concatenate((np.dot(L1, At), np.dot(L1, Bt)), axis=1)  # 2*29
    Trans = np.concatenate((T12, T34))  # 29*29
    H1 = Gm + gamma * np.dot(np.dot(Trans.T, H1), Trans)
    H1yy = H1[nr:nr + mr, nr:nr + mr]
    H1yx = H1[nr:nr + mr, 0:nr]
    L1 = -np.dot(np.linalg.inv(H1yy), H1yx)  # 2*27
Kn = -L1  # offline solution
H = H1
K = Kn
H_vec = vec_H(H)  # Vectorized value function matrix
Hyy1 = H[nr:nr + m, nr:nr + m]  # 2*2
Hyx1 = H[nr:nr + m, 0:nr]  # 2*27
Lf = -np.dot(np.linalg.inv(Hyy1), Hyx1)  # 2*27
K = -Lf

# initial state
ser = serial.Serial("COM3", 115200)
if ser.isOpen():
    print("The serial port was opened successfully.")
    print(ser.name)
else:
    print("Failed to open the serial.")
ip = "192.168.140.1"
LuMoSDKClient.Init()
LuMoSDKClient.Connnect(ip)

x_d = np.array([[5.77784042e-02,  2.44867798e-01,  1.66887283e-01, 8.83878798e-01, -8.02943734e-02, -2.46267982e-01, 0, 0,0, 0, 0, 0]]).reshape(-1, 1)
min_vals = np.array(
    [-0.00879201412200928,	0.170363464355469,	0.0225633468627930,	-0.738277655808186,	-0.302795423829557,	-1.07303653877796,	-0.298369483947754,	-0.0687980651855469,	-0.234121589660645,	-2.57014003570657,	-0.923538284898784,	-3.65200378836516])
max_vals = np.array(
    [0.124927337646484,	0.237662933349609,	0.141864334106445,	0.995231288845882,	0.279599889946212,	0.761269591026194,	0.334707660675049,	0.103577575683594,	0.263511123657227,	3.19393175849312,	0.960900063114750,	3.14161512401149])

# save data
data = {
    'delta_u': np.zeros((sim_step, n_u)),
    'static_u': np.zeros((sim_step, n_u)),
    'x_lift': np.zeros((sim_step, space_dim)),
    'e_extend': np.zeros((sim_step, nr)),
    'e': np.zeros((sim_step, n_x)),
    'state': np.zeros((sim_step, n_x)),
    'action': np.zeros((sim_step, n_u)),
    'K0': np.zeros((K.shape[0], K.shape[1])),
    'K': np.zeros((K.shape[0], K.shape[1])),
    'H': np.zeros((H.shape[0], H.shape[1])),
    'Q':Q,
    'R':R,
    'max_vals':max_vals,
    'min_vals':min_vals,
    'e_lift':np.zeros((sim_step, space_dim)),
    'LQR_cost':0,
    'LQR_error':0,
    'sim_step':sim_step,
    'learning_rate' : learning_rate,
    'n_learning_step' : n_learning_step,
    'n_explore_step' : n_explore_step,
    'update_j' : 20,  # 5
    'alpha' : 10 , # 50
    'Kerroriter' : 0,
    'batch_size' : 50 , # 5
    'epsilon' : 1e-8,
    'beta1' : 0.9 , # 0.9
    'beta2' : 0.999  ,# 0.999
}

x_d_normlization = normalization_state(x_d, min_vals, max_vals)
x_d_normlization = torch.tensor(x_d_normlization.T, dtype=torch.float32)
T = dck.koopman_net.T
x_d_temp = torch.mm(x_d_normlization, T)
x_d_lift_temp = dck.encoder_net(torch.mm(x_d_normlization, T))
x_d_lift = torch.hstack((x_d_temp, x_d_lift_temp)).T
# print('x_d_lift',x_d_lift.shape)
x_d_lift = x_d_lift.detach().numpy()
# print(x_d_lift.shape)


x_pos_list = np.zeros((3, 1))  # x_0[:3,]
x_ang_radian_list = np.zeros((3, 1))  # quaternion_to_euler(x_0[4:7,], 'sxyz').reshape(3,1)
phi = np.zeros((L, N - 1))
upsilon = np.zeros(N - 1)
Z = np.zeros((nr + m, sim_step))
update_j = 20  # 5
data['update_j'] = update_j
alpha = 50  # 50
data['alpha'] = alpha
K_error = np.zeros(int((sim_step - alpha) / update_j))
Kerroriter = 0
data['Kerroriter'] = Kerroriter
batch_size = 50  # 5
data['batch_size']=batch_size
learning_rate = 1 * learning_rate
epsilon = 1e-8
data['epsilon'] =epsilon
beta1 = 0.9  # 0.9
beta2 = 0.999  # 0.999
data['beta1'] = beta1
data['beta2'] = beta2
m_hat = np.zeros(H_vec.shape[0]).reshape(-1, 1)
v_hat = np.zeros(H_vec.shape[0]).reshape(-1, 1)
sensor_data = []

#
frame = LuMoSDKClient.ReceiveData(0)
for rigid in frame.rigidBodys:
    if rigid.Id == 1:
        sensor_data = [0.001 * rigid.X, 0.001 * rigid.Y, 0.001 * rigid.Z, rigid.speeds.XfSpeed,
                       rigid.speeds.YfSpeed,
                       rigid.speeds.ZfSpeed,
                       np.pi * rigid.eulerAngle.X / 180.00, np.pi * rigid.eulerAngle.Y / 180.00,
                       np.pi * rigid.eulerAngle.Z / 180.00,
                       rigid.palstance.fXPalstance, rigid.palstance.fYPalstance, rigid.palstance.fZPalstance]
sensor_data = np.array(sensor_data)
x_pos = sensor_data[0:3].reshape(3, 1)
x_ang_radian = sensor_data[6:9].reshape(3, 1)
x_pos_list = np.concatenate((x_pos_list, x_pos), axis=1)
x_ang_radian_list = np.concatenate((x_ang_radian_list, x_ang_radian), axis=1)
x_pos_vel = sensor_data[3:6].reshape(3, 1)
x_ang_radian_vel = sensor_data[9:12].reshape(3, 1)
x0 = np.concatenate(
    (x_pos.reshape(1, 3), x_ang_radian.reshape(1, 3), x_pos_vel.reshape(1, 3), x_ang_radian_vel.reshape(1, 3)),
    axis=1).T
e_extend = np.zeros((nr,1))
delta_u = np.zeros((m,1))
e_temp = np.zeros((24,1))

x_normlization = normalization_state(x0, min_vals, max_vals)
x_normlization = torch.tensor(x_normlization.T, dtype=torch.float32)
x_temp = torch.mm(x_normlization, T)
x_lift_temp = dck.encoder_net(torch.mm(x_normlization, T))
# print('x_d_lift_temp.shape',x_d_lift_temp.shape) # torch.Size([1, 12])
x_lift = torch.hstack((x_temp, x_lift_temp)).T
x_lift = x_lift.detach().numpy()

e_lift = x_lift - x_d_lift
e_temp = np.array(e_lift).reshape(-1, 1)
e_extend = np.concatenate((e_temp, q))

e_extend_former = e_extend
u_former = delta_u
# If you want to transfer and run online learning,implement this code and set the n_learning_step:
mat = scipy.io.loadmat(r"policy_learning_single_configuration/step3_online_policy_learning_target_reaching/policy/preset_policy.mat")
K = mat['K']
H = mat['H']
H_vec = vec_H(H)

K0 = K
data['K0'] = K0
for iter in range(sim_step):

    tic = time.time()

    frame = LuMoSDKClient.ReceiveData(0)
    for rigid in frame.rigidBodys:
        if rigid.Id == 1:
            sensor_data = [0.001 * rigid.X, 0.001 * rigid.Y, 0.001 * rigid.Z, rigid.speeds.XfSpeed,
                           rigid.speeds.YfSpeed,
                           rigid.speeds.ZfSpeed,
                           np.pi * rigid.eulerAngle.X / 180.00, np.pi * rigid.eulerAngle.Y / 180.00,
                           np.pi * rigid.eulerAngle.Z / 180.00,
                           rigid.palstance.fXPalstance, rigid.palstance.fYPalstance, rigid.palstance.fZPalstance]
    sensor_data = np.array(sensor_data)
    x_pos = sensor_data[0:3].reshape(3, 1)

    x_ang_radian = sensor_data[6:9].reshape(3, 1)
    x_pos_list = np.concatenate((x_pos_list, x_pos), axis=1)
    x_ang_radian_list = np.concatenate((x_ang_radian_list, x_ang_radian), axis=1)
    x_pos_vel = sensor_data[3:6].reshape(3, 1)
    x_ang_radian_vel = sensor_data[9:12].reshape(3, 1)
    x = np.concatenate(
        (x_pos.reshape(1, 3), x_ang_radian.reshape(1, 3), x_pos_vel.reshape(1, 3), x_ang_radian_vel.reshape(1, 3)),
        axis=1).T

    x_normlization = normalization_state(x, min_vals, max_vals)
    x_normlization = torch.tensor(x_normlization.T, dtype=torch.float32)
    x_temp = torch.mm(x_normlization, T)
    x_lift_temp = dck.encoder_net(torch.mm(x_normlization, T))
    x_lift = torch.hstack((x_temp, x_lift_temp)).T
    x_lift = x_lift.detach().numpy()

    e_lift = x_lift - x_d_lift
    e_temp = np.array(e_lift).reshape(-1, 1)
    e_extend = np.concatenate((e_temp, q))

    # enforce control limit
    a1 = 0.001 * np.ones((m, 1))
    a2 = 0.001 * np.ones((m, 1))
    sim_noise = 0.0001 * np.random.normal(loc=0, scale=1000, size=(m, 1))
    n_explor = sim_noise + a1 * (
            0.5 * np.sin(2.0 * iter) ** 2 * np.cos(10.1 * iter) + 0.9 * np.sin(1.102 * iter) ** 2 * np.cos(
        4.001 * iter) + 0.3 * np.sin(1.99 * iter) ** 2 * np.cos(7 * iter) +
            0.3 * np.sin(10.0 * iter) ** 3 + 0.7 * np.sin(3.0 * iter) ** 2 * np.cos(
        4.0 * iter) + 0.3 * np.sin(3.00 * iter) * np.cos(1.2 * iter) ** 2 +
            0.4 * np.sin(1.12 * iter) ** 2 + 0.5 * np.cos(2.4 * iter) * np.sin(
        8 * iter) ** 2 + 0.3 * np.sin(1.000 * iter) * np.cos(0.799999 * iter) ** 2 +
            0.3 * np.sin(4 * iter) ** 3 + 0.4 * np.cos(2 * iter) * np.sin(5 * iter) ** 4 + 0.3 * np.sin(
        10.00 * iter) ** 3) + a2 * (0.1 * np.sin(2 * iter) ** 3 * np.cos(9 * iter) +
                                    0.37 * np.sin(1.1 * iter) ** 2 * np.cos(4.00 * iter) + 0.3 * np.sin(
                2.2 * iter) ** 4 * np.cos(7. * iter) + 0.3 * np.sin(10.3 * iter) ** 2 +
                                    0.7 * np.sin(3 * iter) ** 2 * np.cos(4 * iter) + 0.3 * np.sin(
                3 * iter) * np.cos(
                1.2 * iter) ** 2 + 0.4 * np.sin(1.12 * iter) ** 3 + 0.5 * np.cos(2.4 * iter) * np.sin(8 * iter) ** 2 +
                                    0.3 * np.sin(1 * iter) * np.cos(0.8 * iter) ** 2 + 0.3 * np.sin(
                4 * iter) ** 3 + 0.4 * np.cos(2 * iter) * np.sin(5 * iter) ** 4 + 0.3 * np.sin(5 * iter) ** 5)
    u_nominal = -np.dot(Kn, e_extend)
    u_nominal_use = np.array([u_nominal[0, :], u_nominal[0, :], u_nominal[0, :], u_nominal[0, :],
                              u_nominal[1, :], u_nominal[1, :], u_nominal[1, :], u_nominal[1, :]]).flatten()
    # if iter % 2:
    if iter < n_explore_step:
        delta_u = -np.dot(K, e_extend) + 0.7 * n_explor
    else:
        delta_u = -np.dot(K, e_extend)

    u_pred = predict_u(x_d, net_control, n_u)
    u = 1 * u_pred + 1 * delta_u.flatten()
    static_u = u - delta_u.flatten()
    u = np.clip(u, 0, 1).flatten()

    u_input = np.clip(3.0 * u, 0, 3)
    buffer = struct.pack("dddd", u_input[0], u_input[1], u_input[2], u_input[3])
    write_len = ser.write(buffer)

    q = q + t_s * np.dot(C, e_temp)

    Z[0:nr, iter] = e_extend_former.flatten()
    Z[nr:nr + m, iter] = u_former.flatten()
    e_extend_next = e_extend

    for iteration in range(N - 2):
        upsilon[iteration] = upsilon[iteration + 1]
        phi[:, iteration] = phi[:, iteration + 1]
    z_j = vec_z(Z[:, iter])
    phi[:, -1] = z_j[:, 0]
    xa_k_1 = e_extend_next
    delta_u_k_1 = -np.dot(K, xa_k_1)  # 2*1
    z_k_1 = vec_z(np.concatenate((xa_k_1, delta_u_k_1)))  # xxx*1

    reward = (np.dot(np.dot(Z[0:nr, iter].T, Q), Z[0:nr, iter]) +
              np.dot(np.dot(Z[nr:nr + m, iter].T, R), Z[nr:nr + m, iter]))
    upsilon[-1] = reward + gamma * np.dot(H_vec.T, z_k_1)
    #
    if (iter > alpha) & (np.mod(iter, update_j) == 0) & (iter < n_learning_step):  # 40
        X_batch = upsilon[-batch_size:].reshape(-1, 1)
        U_batch = phi[:, -batch_size:]
        U_pred_batch = np.dot(U_batch.T, H_vec)  # batch_size*1
        loss = (1 / (2 * batch_size)) * np.linalg.norm(U_pred_batch - X_batch)
        gradiant = (1 / batch_size) * np.dot(U_batch, U_pred_batch - X_batch)  # size(H_vec)*1
        m_hat = beta1 * m_hat + (1 - beta1) * gradiant
        v_hat = beta2 * v_hat + (1 - beta2) * np.square(gradiant)
        m_hat_bias_corrected = m_hat / (1 - beta1 ** (iter - alpha))
        v_hat_bias_corrected = v_hat / (1 - beta2 ** (iter - alpha))
        H_vec = H_vec - learning_rate * m_hat_bias_corrected / (np.sqrt(v_hat_bias_corrected) + epsilon)
        H = vec_H_inv(H_vec)
        H_uu = H[nr:mr + nr, nr:mr + nr]
        H_ux = H[nr:mr + nr, 0:nr]
        K_new = np.dot(np.linalg.inv(H_uu), H_ux)
        print('K_error at', iter, 'step is', np.linalg.norm(K - K_new))
        K_error[Kerroriter] = np.linalg.norm(K - K_new)
        Kerroriter = Kerroriter + 1
        K = K_new

    e_extend_former = e_extend
    u_former = delta_u.reshape(-1, 1)
    e = x - x_d

    data['delta_u'][iter] = delta_u.flatten()
    data['static_u'][iter] = static_u.flatten()
    data['x_lift'][iter] = x_lift.flatten()
    data['e_extend'][iter] = e_extend.flatten()
    data['e'][iter] = e.flatten()
    data['state'][iter] = x.T.flatten()
    data['action'][iter] = u
    data['e_lift'][iter] = e_lift.flatten()

    toc = time.time()
    time.sleep(np.clip(t_s - (toc - tic), 0, t_s))

print('K0',K0)
print('K',K)
data['K'] = K
data['H'] = H
data_model = {'K':K,
              'H':H
}
save_path1 = 'result.mat'
save_model = r'policy_learning_single_configuration/step3_online_policy_learning_target_reaching/policy/lerl_policy.mat'
scipy.io.savemat(save_path1, data)
scipy.io.savemat(save_model, data_model)
# load data and plot
result = scio.loadmat('result.mat')
e = result['e']
u = result['action']
x = result['state']
buffer = struct.pack("dddd", 0, 0, 0, 0)
write_len = ser.write(buffer)
ser.close()
if ser.isOpen():
    print("The serial port is not closed.")
else:
    print("The serial port is closed.")
fig, axs = plt.subplots(1, 3, figsize=(10, 6))
print(x[-1],u[-1])
axs[0].plot(e[:, :3])
axs[0].set_title("ex-ey-ez")
axs[0].set_xlabel("step")
axs[0].set_ylabel("e")
eytick1 = axs[0].get_ylim()
axs[0].text(sim_step/2,0.6*eytick1[0],'e_x:%f'%(e[-1,0]),fontdict={'color':'b','size':'12'})
axs[0].text(sim_step/2,0.8*eytick1[0],'e_y:%f'%(e[-1,1]),fontdict={'color':'b','size':'12'})
axs[0].text(sim_step/2,1*eytick1[0],'e_z:%f'%(e[-1,2]),fontdict={'color':'b','size':'12'})
print('ex', e[-1, 0])
print('ey', e[-1, 1])
print('ez', e[-1, 2])

axs[1].plot(e[:, 3:6])
axs[1].set_title("e-angle")
axs[1].set_xlabel("step")
axs[1].set_ylabel("e")
eytick2 = axs[1].get_ylim()
axs[1].text(sim_step/2,0.6*eytick2[0],'e_anx:%f'%(e[-1,3]),fontdict={'color':'b','size':'12'})
axs[1].text(sim_step/2,0.8*eytick2[0],'e_any:%f'%(e[-1,4]),fontdict={'color':'b','size':'12'})
axs[1].text(sim_step/2,1*eytick2[0],'e_anz:%f'%(e[-1,5]),fontdict={'color':'b','size':'12'})
print('etheta1', e[-1, 3])
print('etheta2', e[-1, 4])
print('etheta3', e[-1, 5])

axs[2].plot(u[:, :])
axs[2].set_title("u1-u4")
axs[2].set_xlabel("step")
axs[2].set_ylabel("u")
eytick3 = axs[2].get_ylim()
axs[2].text(sim_step/2,0.95*eytick3[1],'u1:%f'%(u[-1,0]),fontdict={'color':'b','size':'12'})
axs[2].text(sim_step/2,0.85*eytick3[1],'u2:%f'%(u[-1,1]),fontdict={'color':'b','size':'12'})
axs[2].text(sim_step/2,0.75*eytick3[1],'u3:%f'%(u[-1,2]),fontdict={'color':'b','size':'12'})
axs[2].text(sim_step/2,0.65*eytick3[1],'u4:%f'%(u[-1,3]),fontdict={'color':'b','size':'12'})

plt.tight_layout()
plt.show()
