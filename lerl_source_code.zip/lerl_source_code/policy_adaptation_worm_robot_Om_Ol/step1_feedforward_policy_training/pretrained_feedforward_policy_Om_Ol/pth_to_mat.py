import scipy.io as sio
import torch
def save_model_to_mat(best_state_dict, layers, file_name='feedforward_policy_em_el.mat'):
    weights_and_biases = {k: v.numpy() for k, v in best_state_dict.items()}
    layers_info = {'layers': layers}
    sio.savemat(file_name, {'state_dict': weights_and_biases, 'architecture': layers_info})
model_path = "feedforward_policy_em_el.pth"
dicts_control = torch.load(model_path, map_location=torch.device('cpu'))
state_dict_control = dicts_control["model"]
Elayer_control = dicts_control["layer"]
save_model_to_mat(state_dict_control, Elayer_control)