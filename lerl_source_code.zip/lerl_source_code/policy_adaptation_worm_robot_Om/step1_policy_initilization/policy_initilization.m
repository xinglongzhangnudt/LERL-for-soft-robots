clc;
clear;
% close all;
%% parameter
ts = 0.02; % sampling time
file_nums = 40;
file_col = 248;
n_x = 24;
n_u = 3;
%%
w_path = "\policy_learning_single_configuration\step1_koopman_embedding_training\pretrained_koopman_embedding\Koopman_embedding_for_matlab.mat"; 
dedmd = DeepEDMD(w_path); 
T = dedmd.T; 

min_vals = [-0.139514000000000	0.146197000000000	-0.309248000000000	-1.30746628524175	-0.771566429075393	-1.40209280129712	-1.07062530000000	-0.739390000000000	-0.689250000000000	-7.10574153035199	-6.51643110841611	-11.4401620079248];
max_vals = [0.0834494000000000	0.259432000000000	-0.0823571000000000	1.16888365197489	1.03610074781242	1.45574596783268	0.718414000000000	0.664360000000000	1.13411000000000	8.82305999318107	8.57498063863184	10.8588417033045];
%% load data and process data
XU=zeros(n_x+n_u,file_nums*file_col);
X_PLUS=zeros(n_x,file_nums*file_col);

for i = 1:file_nums
    file_number = i; 
    file_name = sprintf('soft_robot_%d.mat', (file_number-1));
    loaded_data = load(file_name);
    for iter=1:size(loaded_data.X,1)-1
        x_lift = dedmd.encoder(loaded_data.X(iter,:)*T); 
        xu=[x_lift, loaded_data.U(iter,:)]';
        x_lift = dedmd.encoder(loaded_data.X(iter+1,:)*T); 
        xplus=x_lift';
        XU(:,(i-1)*file_col+iter)=xu;
        X_PLUS(:,(i-1)*file_col+iter)=xplus;
    end
end

M=XU*XU';
AB=X_PLUS*pinv(XU);
A=AB(1:n_x,1:n_x);
B=AB(1:n_x,n_x+1:n_x+n_u);
eig(A)
rank(ctrb(A,B))
file_number=0;
XPR=[];
XPP=[];
for i = 1:file_number
file_name = sprintf('soft_robot_test_%d.mat', i-1);
loaded_data = load(file_name);
for iter=1:size(loaded_data.X,1)-1
    x_lift = dedmd.encoder(loaded_data.X(iter,:)*T); 
    xu=[x_lift, loaded_data.U(iter,:)]';
    xplus_pre=AB*xu;
    x_lift = dedmd.encoder(loaded_data.X(iter+1,:)*T); 
    xplus=x_lift';
    XPP=[XPP,xplus_pre];
    XPR=[XPR,xplus];
end    
end
ERROR=XPP-XPR;
plot(1:size(XPP,2),XPP(1,:),'b.',1:size(XPP,2),XPR(1,:),'r-.',1:size(XPP,2),ERROR(1,:),'-g')
%%
T = dedmd.T; 
nx = 12;
lift_dim = 12;
n = nx+lift_dim+6;  % TODO
m = 3;
ny = 6;
nr = nx + lift_dim + ny;
q1 = [1;1;1;1;1;1;1*ones(6,1)];
q2 = 1*ones(lift_dim,1);
q3 = 5*[1; 1; 1; 0; 0; 0];
Q  =  diag([q1;q2;q3]); 
R1 = 80*ones(1,m); 
R =  diag (R1); 
learning_rate = 0.004;
% parameter for simualtion
C_f = [inv(T'),zeros(nx,lift_dim)];
C = C_f(1:6,:);
At = [A,zeros(n-6,6);
     ts*C,eye(6)];
Bt = [B;zeros(6,m)];
mr = m;
H1=100*eye(nr+mr);
G=blkdiag(Q,R);
H1yy=H1(nr+1:nr+mr,nr+1:nr+mr);H1yx=H1(nr+1:nr+mr,1:nr);
K=pinv(H1yy)*H1yx;
for i=1:400
    H1=G+[At Bt;K*At K*Bt]'*0.97*H1*[At Bt;K*At K*Bt];
    H1yy1=H1(nr+1:nr+m,nr+1:nr+m);H1yx1=H1(nr+1:nr+m,1:nr);
    K=pinv(H1yy1)*H1yx1;
end
H = H1; 
H_vec = vec_H(H); 
Hyy1 = H(nr+1:nr+m, nr+1:nr+m);
Hyx1 = H(nr+1:nr+m, 1:nr);
Lf = pinv(Hyy1) * Hyx1;
% Save the origin model 
save('policy_adaptation_heterogeneous_robot_em\step1_policy_initilization\initial_feedback_policy.mat',"K", "H_vec");
%%
function [normalized_data, min_vals, max_vals]= normalize_state(data, min_vals, max_vals)
    [num_rows, num_cols] = size(data);
    normalized_data = zeros(num_rows, num_cols);
    for i = 1:num_cols
        normalized_data(:, i) = 2*(data(:, i) - min_vals(i)) / (max_vals(i) - min_vals(i)) -1;
    end
end
%%
function [normalized_data, min_vals, max_vals]= normalize_control(data)
    [num_rows, num_cols] = size(data);
    normalized_data = zeros(num_rows, num_cols);
    for i = 1:num_cols
        normalized_data(:, i) = 2*(data(:, i) - min_vals(i)) / (max_vals(i) - min_vals(i))-1;
    end
end
