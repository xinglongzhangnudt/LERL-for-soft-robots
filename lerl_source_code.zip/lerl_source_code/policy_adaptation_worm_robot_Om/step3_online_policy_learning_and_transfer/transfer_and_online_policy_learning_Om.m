% general policy iteration
clc;
clear all;
% close all;
global dataAsDouble
%% load pre-trained model
w_path = "policy_learning_single_configuration\step1_koopman_embedding_training\pretrained_koopman_embedding\params_for_matlab.mat"; 
dedmd = DeepEDMD(w_path); 
%%
%if you wangt to transfer or deploy a control result as model, run the code below:
load('policy_adaptation_heterogeneous_robot_em\step1_policy_initilization\initial_feedback_policy.mat', "K", "H_vec");
K0 = K;
T = dedmd.T; 
nx = 12;
lift_dim = 12;
n = nx+lift_dim+6;  % TODO
m = 3;
ny = 6;
nr = nx + lift_dim + ny;
% parameter for simualtion
z_size = n + m; % Number of states in z-vector 
L = z_size * (z_size + 1) / 2;  % Size of vectorized z
% N =  5*L; % Number of measurements before evaluation % 10* L;
N = L + 5;
beta = 0.1;
Pk = beta*eye(L); % parameter for RLS

% parameter for cost function 
q1 = [1;1;1;1;1;1;1*ones(6,1)];
q2 = 1*ones(lift_dim,1);
q3 = 5*[1; 1; 1; 0; 0; 0];
Q  =  diag([q1;q2;q3]); 
R1 = 80*ones(1,m); 
R =  diag (R1); 
learning_rate = 0.004;
% parameter for simualtion
sim_step = 1000; % total simulation steps
n_learning_step = 0;
n_explore_step = 0;
ts = 0.02;
q = zeros(6,1);
gamma= 0.98;
% state bound for normailzation
min_vals = [-0.153378     0.158337    -0.35899     -1.23483964  -0.90475425   -1.47350295  -1.574925    -1.559       -1.32425    -11.174296  -10.61701237 -12.6702177];
max_vals = [0.10742      0.284093    -0.119631     1.22936804   0.99482895    1.56120574   1.307857     1.48675      1.2386      10.97279774   10.47380811  18.29183596];
%% setting for data saving
x_list = zeros(nx,sim_step);
e_list = zeros(nx,sim_step);
u_list = zeros(m,sim_step);
u_list_temp = zeros(m,sim_step);
x_list_lift = zeros(n-6,sim_step);
e_list_lift  =zeros(n-6,sim_step);
u_dy_list_lift = zeros(m,sim_step);
u_steady_list_lift = zeros(m,sim_step);
u_list_lift = zeros(m,sim_step);
u_list_temp_1 = [];
delta_u_lits = [];
e_list_temp = [];
K_error = [];

phi = zeros(L, N - 1);
upsilon = zeros(N - 1, 1);
Z = zeros(nr+m,sim_step);
update_j = 5;
K_error = zeros(1, int16((sim_step-50)/update_j));
Kerroriter = 0;
batch_size = 5;
epsilon = 1e-8; 
beta1 = 0.9; 
beta2 = 0.999; 
alpha = 5; 
m_hat = zeros(size(H_vec, 1), 1);
v_hat = zeros(size(H_vec, 1), 1);

%% setting for target position 
part1=[-0.00869454000000000;0.284409000000000;-0.233625000000000]';
part2=[0.0312063124927334;0.000116576300327233;-0.00516903692587649]';
x_target = [part1, part2,0,0,0,0,0,0]'; 
%%
part1 = [0.0283271000000000;0.244191000000000;-0.177131000000000]';
part2 = [0.488816108935304;-0.0891353611627520;-0.341243284691427]';
x_target = [part1, part2,0, 0,0,0,0,0]'; 
x_target_normalization = normalization_state(x_target,min_vals,max_vals);
x_target_lift = dedmd.encoder(x_target_normalization'*T)'; 
u_steady_lift =  1*[80 15 15]';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Part 2 nominal control input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nr = n;
mr = m;
%% Uref net
control_net = buildNetwork();
u_dim = 3;
u_ref_min_vals = [0.         0.         0.        -0.198065  0.11575  -0.400908];
u_ref_max_vals = [2.50000e+02  2.50000e+02  2.50000e+02  1.10604e-01  3.28534e-01 -7.65731e-02];
%% get the initial position 
t = tcpclient('127.0.0.1', 8888);
while (1) 
    % send the first control input
    input_data = zeros(3,1);
    write(t, typecast(input_data, 'double')); 
   % receive the initial position
   if t.BytesAvailable > 0
        dataReceived = read(t,t.BytesAvailable,"char");
        charArray = strsplit(dataReceived, ' ');
        dataAsDouble = cellfun(@str2double, charArray);
        break;
   end
end
position_data = dataAsDouble(1:3)*0.001;
position_velocity_data = dataAsDouble(5:7);
angle_radian_data = dataAsDouble(12:14)*pi/180;
angle_velocity_data = dataAsDouble(15:17);
x0 = [position_data,angle_radian_data,position_velocity_data,angle_velocity_data]';
x0_normalization = normalization_state(x0,min_vals,max_vals);
x_lift = dedmd.encoder(x0_normalization'*T)'; 
%% state evolution
step_m=2;
for j = 1: sim_step
    u_ref = predictControl(control_net, x_target(1:3), u_ref_min_vals, u_ref_max_vals, u_dim);
    e_lift = x_lift - x_target_lift;
    e_lift_extend = [e_lift;q];
    u_nominal_lift = -Kn*e_lift_extend;
    %% noise setting 
    a1= 0.001*ones(m,1); 
    a2= 0.001*ones(m,1); 
    sim_noise = 0.0001 * normrnd(0, 1000,[m,1]); 
    n_explor=sim_noise+a1*(0.5*sin(2.0*j)^2*cos(10.1*j)+0.9*sin(1.102*j)^2*cos(4.001*j)+0.3*sin(1.99*j)^2*cos(7*j)+0.3*sin(10.0*j)^3+0.7*sin(3.0*j)^2*cos(4.0*j)+0.3*sin(3.00*j)*1*cos(1.2*j)^2+0.400*sin(1.12*j)^2+0.5*cos(2.4*j)*sin(8*j)^2+0.3*sin(1.000*j)^1*cos(0.799999*j)^2+0.3*sin(4*j)^3+0.4*cos(2*j)*1*sin(5*j)^4+0.3*sin(10.00*j)^3)+...
         a2*(0.1*sin(2*j)^3*cos(9*j)+0.37*sin(1.1*j)^2*cos(4.00*j)+0.3*sin(2.2*j)^4*cos(7.*j)+0.3*sin(10.3*j)^2+0.7*sin(3*j)^2*cos(4*j)+0.3*sin(3*j)*cos(1.2*j)^2+0.4*sin(1.12*j)^3+0.5*cos(2.4*j)*sin(8*j)^2+0.3*sin(1*j)*cos(0.8*j)^2+0.3*sin(4*j)^3+0.4*cos(2*j)*sin(5*j)^4+0.3*sin(5*j)^5);
    if j<n_explore_step
        delat_u = -K*e_lift_extend+ 1.0*n_explor;
    else
        delat_u = -K*e_lift_extend;
    end
    delta_u_lits = [delta_u_lits, delat_u];
    u_lift = 0 * u_nominal_lift + 1 * delat_u; 
    Z(1 : n, j) = e_lift_extend;
    Z(n + 1 : n + m, j) = delat_u;
    u = 1 * anti_normalization_input(u_lift)+ 1 * u_steady_lift + 0 * u_ref ;
    u_list_temp(:,j) = u;
    %% enforce control limit
    u(u < 0) = 0;  
    u(u > 255) = 255;  
%% send interger control input
    input_data = round(u); % covert the control input into interger
    write(t, typecast(input_data, 'uint8'));
 %% save data for plotting
    u_list(:,j) =  input_data;
    u_list_temp_1 = [u_list_temp_1,input_data];
    e_list_lift(:,j) = e_lift;
    x_list_lift(:,j) = x_lift;
    u_list_lift(:,j) = u_lift;
    u_dy_list_lift(:,j) =  delat_u;
    u_steady_list_lift(:,j) = u_steady_lift;
    %% receive and process the updated state
    if t.BytesAvailable > 0
%             disp('get measurement')
        dataReceived =read(t,t.BytesAvailable,"char");
        charArray = strsplit(dataReceived, ' '); % TODO
        dataAsDouble = cellfun(@str2double, charArray);
%             disp('Received data :');
%             disp(dataAsDouble);
    end

        % process the receided data
        position_data = dataAsDouble(1:3)*0.001;
        position_velocity_data = dataAsDouble(5:7);       
        angle_radian_data = dataAsDouble(12:14)*pi/180;
        angle_velocity_data = dataAsDouble(15:17);
        x = [position_data,angle_radian_data,position_velocity_data,angle_velocity_data];
        x_normal = normalization_state(x',min_vals,max_vals);
%         x_lift = dedmd.encoder((T*x_normal)')'; 
        x_lift = dedmd.encoder(x_normal'*T)'; 
        e = x'-x_target;
        x_list(:,j) = x';
        e_list(:,j) = e;
        e_list_temp = [e_list_temp,e];
   %% VALUE ITERATION
   for iter=1:N - 2
        upsilon(iter)=upsilon(iter+1);
        phi(:,iter)=phi(:,iter+1);
   end
    z_j = vec_z(Z(:, j));
    phi(:, N-1) = z_j(:, 1);
    e_k_1 = x_lift-x_target_lift;
    q_k_1 = q + ts*C*e_lift; % TODO
    q = q_k_1;
    e_lift_extend_k_1 = [e_k_1;q_k_1]; % TODO 
    delta_u_k_1 = -K * e_lift_extend_k_1;
    z_k_1 = vec_z([e_lift_extend_k_1; delta_u_k_1]);
    reward = e_lift_extend' * Q*  e_lift_extend + delat_u' * R * delat_u; % learning without nonminal control input
    upsilon(N - 1) = reward + gamma*H_vec' * z_k_1;  
%% learning batch
    if (j > alpha) && (mod(j, update_j) == 0) && (j < n_learning_step)
        X_batch = upsilon(end-batch_size+1:end, :);
        U_batch = phi(:, end-batch_size+1:end);
        U_pred_batch = U_batch' * H_vec; % batch_size*1
        loss = (1/(2*batch_size)) * norm(U_pred_batch - X_batch);
        gradient = (1/batch_size) * U_batch * (U_pred_batch - X_batch); % size(H_vec)*1
        m_hat = beta1*m_hat + (1-beta1)*gradient;
        v_hat = beta2*v_hat + (1-beta2)*(gradient.^2);
        m_hat_bias_corrected = m_hat / (1-beta1^(j-alpha));
        v_hat_bias_corrected = v_hat / (1-beta2^(j-alpha));
        H_vec = H_vec - learning_rate * m_hat_bias_corrected ./ (sqrt(v_hat_bias_corrected) + epsilon);
        H = vec_H_inv(H_vec);
        H_uu = H(nr+1:nr+mr, nr+1:nr+mr);
        H_ux = H(nr+1:nr+mr, 1:nr);
        K_new = inv(H_uu) * H_ux;
        disp(['K_error at ', num2str(j), ' step is ', num2str(norm(K-K_new))]);
        K_error(Kerroriter+1) = norm(K-K_new); 
        Kerroriter = Kerroriter + 1;
        K = K_new;
    end
end
delta_u_list = delta_u_lits;
% Save the learned model
save('policy_adaptation_heterogeneous_robot_em\step3_online_policy_learning_and_transfer\policy_em.mat',"K", "H_vec");
%% plot for check
figure(1)
row = 4;
column = 1;
subplot(row,column,1)
plot(e_list_temp(1:3,:)')
title('e-pos')
subplot(row,column,2)
plot(e_list_temp(4:6,:)')
title('e-ang')
subplot(row,column,3)
plot(u_list(1:3,:)')
title('u')
subplot(row,column,4)
plot(delta_u_lits(1:3,:)')
title('delta_u')
disp('pos-error')
disp(e_list_temp(1:3,end)')
disp('ang-error')
disp(e_list_temp(4:6,end)')

%% reset
pause(1);
j = 1;
if j < 100
    % send the first control input
    input_data = zeros(3,1);
    write(t, typecast(input_data, 'double')); 
    j  = j+1;
end
%% state normalizatoin
function   normalized_data = normalization_state(original_data,min_vals,max_vals)
[num_rows, num_cols] = size(original_data);
normalized_data = zeros(num_rows, num_cols);
for i = 1:num_rows
     normalized_data(i,:) = 2*(original_data(i,:) - min_vals(i)) / (max_vals(i) - min_vals(i))-1;
end
end

function   anti_normalized_input_data = anti_normalization_input(original_data)
    min_vals = zeros(1,6);
    max_vals = 255*ones(1,6);
    [num_rows, num_cols] = size(original_data);
    anti_normalized_input_data= zeros(num_rows, num_cols);
    for i = 1:num_rows
         anti_normalized_input_data(i,:) = (original_data(i,:))*(max_vals(i) - min_vals(i)) +min_vals(i);
    end
end
%% subfunctions
function v = vec_z(a) % vectorize vector for iteration
[size_a, ~] = size(a);
newsize = size_a * (size_a + 1) / 2;
v = zeros(newsize, 1);
n = 1;
for i = 1 : size_a
    for j = i : size_a
        v(n) = a(i) * a(j);
        n = n + 1;
    end
end
end

function a = vec_H(A) % vectorize H matrix for iteration
[size_A, ~] = size(A);
newsize = size_A * (size_A + 1) / 2;
a = zeros(newsize, 1);
n = 1;
for i = 1 : size_A
    for j = i : size_A
        if i == j
            a(n) = A(i, j);
        else
            a(n) = 2 * A(i, j);
        end
        n = n + 1;
    end
end
end

function H = vec_H_inv(a) % recover H matrix
[a_size, ~] = size(a);
coeff = [0.5, 0.5, -a_size];
X = roots(coeff);
A_size = int16(X(2));
A = zeros(A_size);
n = 1;
for i = 1 : A_size
    for j = i : A_size
        if i == j
            A(i, j) = a(n);
        else
            A(i, j) = a(n) / 2;
        end
        n = n + 1;
    end
end
tri_low1 = triu(A, 1);
H = A + tri_low1.';
end


function [phi, upsilon] = value_iteration(Z, n, m, N, L, H_vec, Q, R,Kn,K) % lifted space
% Z Data matrix
% n Number of states
% m Number of inputs
% N Number of measurements
% L Size of z-vector
% K Policy at current update step
% Q State cost matrix
% R Input cost matrix
phi = zeros(L, N - 1);
upsilon = zeros(N - 1, 1);
for k = 1 : N - 1
    z_k = vec_z(Z(:, k));
    phi(:, k) = z_k;
    e_k_1 = Z(1 : n, k + 1);
    delta_u_k_1 = -K * e_k_1;
    z_k_1 = vec_z([e_k_1; delta_u_k_1]);
    e_k = Z(1 : n, k);
    delta_u_k = Z(n + 1 : n + m, k);
    upsilon(k) = e_k' * Q * e_k + delta_u_k' * R * delta_u_k + H_vec' * z_k_1;  % learning from starting
end
end

function [H, H_vec, K] = estimate_policy(phi, upsilon, n, m, L, Pk, H_vec)
Y_vec = phi(:,end);
d = upsilon(end);
H_vec = H_vec+(Pk*Y_vec*(d-Y_vec'*H_vec))/(1+Y_vec'*Pk*Y_vec);
Pk = Pk-(Pk*Y_vec*Y_vec'*Pk)/(1+Y_vec'*Pk*Y_vec);
H = vec_H_inv(H_vec);
H_uu = H(n + 1 : m + n, n + 1 : m + n);
H_ux = H(n + 1 : m + n, 1 : n);
K = H_uu \ H_ux;
end

%%
function net = buildNetwork()
    data = load('policy_adaptation_heterogeneous_robot_em\step2_feedforward_policy_training\pretrained_feedforward_policy_em\feedforward_policy_em.mat');
    state_dict = data.state_dict;
    architecture = data.architecture.layers;k
    inputLayer = featureInputLayer(architecture(1), 'Name', 'input', 'Normalization', 'none');
    layers = [inputLayer];
    for i = 1:length(architecture) - 1
        layer_name = sprintf('encode_net.linear_%d', i-1);
        linear_weight = state_dict.([layer_name, '.weight']);
        linear_bias = state_dict.([layer_name, '.bias']).';
        layers = [layers, fullyConnectedLayer(architecture(i+1), 'Name', layer_name, ...
                                              'Weights', linear_weight, 'Bias', linear_bias)];
        if i ~= length(architecture) - 1
            relu_name = sprintf('encode_net.relu_%d', i-1);
            layers = [layers, reluLayer('Name', relu_name)];
        end
    end
    lgraph = layerGraph(layers);
    net = dlnetwork(lgraph);
end

function u_ref = predictControl(net, x_d, min_vals, max_vals, u_dim)
    state_des_normalized = normalization_state(x_d, min_vals(u_dim+1:end), max_vals(u_dim+1:end));
    state_des_dlarray = dlarray(state_des_normalized, 'CB');
    control0_hat_dlarray = predict(net, state_des_dlarray);
    control0_hat = extractdata(control0_hat_dlarray);
    u_ref = denormalization_state(control0_hat, min_vals(1:u_dim), max_vals(1:u_dim));
end

function original_data = denormalization_state(normalized_data, min_vals, max_vals)
    num_rows = size(normalized_data, 1);
    original_data = zeros(size(normalized_data));
    for i = 1:num_rows
        original_data(i, :) = ((normalized_data(i, :) + 1) .* (max_vals(i) - min_vals(i)) / 2) + min_vals(i);
    end
end